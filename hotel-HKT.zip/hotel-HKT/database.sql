-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
-- AUTHOR : HUYTKING
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2025 at 03:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel_huytking`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `GenerateAllRooms` ()   BEGIN
    DECLARE floor_num INT DEFAULT 1;
    DECLARE room_num INT DEFAULT 1;
    DECLARE floor_code CHAR(1);
    DECLARE room_id VARCHAR(10);
    DECLARE room_number VARCHAR(10);
    
    DECLARE room_type VARCHAR(20);
    DECLARE bed_type VARCHAR(30);
    DECLARE bed_count INT;
    DECLARE max_guests INT;
    DECLARE room_price DECIMAL(12,2);
    DECLARE room_size INT;
    DECLARE has_balcony BOOLEAN;
    DECLARE view_type VARCHAR(20);
    
    -- Xóa dữ liệu cũ
    DELETE FROM rooms;
    
    WHILE floor_num <= 7 DO
        -- Mã tầng: A, B, C, D, E, F, G
        SET floor_code = CHAR(64 + floor_num); -- 65 = 'A' trong ASCII
        
        SET room_num = 1;
        WHILE room_num <= 23 DO
            -- Tạo mã phòng: A01, A02, ..., A23
            SET room_number = CONCAT(floor_code, LPAD(room_num, 2, '0'));
            SET room_id = CONCAT(floor_num, LPAD(room_num, 2, '0'));
            
            -- Xác định loại phòng dựa trên số phòng
            -- Phòng 1-5: Budget/Standard (giá rẻ nhất)
            IF room_num BETWEEN 1 AND 5 THEN
                SET room_type = CASE 
                    WHEN floor_num <= 2 THEN 'Budget' 
                    ELSE 'Standard' 
                END;
                SET room_price = 350000 + (floor_num * 50000);
                SET bed_type = CASE (room_num % 3)
                    WHEN 0 THEN 'Single Bed'
                    WHEN 1 THEN 'Double Bed'
                    ELSE 'Twin Beds'
                END;
                SET bed_count = CASE (room_num % 3)
                    WHEN 0 THEN 1
                    WHEN 1 THEN 1
                    ELSE 2
                END;
                SET max_guests = bed_count;
                SET room_size = 18 + (room_num % 5);
                SET has_balcony = FALSE;
                SET view_type = 'Street View';
            
            -- Phòng 6-10: Standard/Superior
            ELSEIF room_num BETWEEN 6 AND 10 THEN
                SET room_type = CASE 
                    WHEN floor_num <= 3 THEN 'Standard' 
                    ELSE 'Superior' 
                END;
                SET room_price = 550000 + (floor_num * 70000);
                SET bed_type = CASE (room_num % 4)
                    WHEN 0 THEN 'Double Bed'
                    WHEN 1 THEN 'Queen Bed'
                    WHEN 2 THEN 'Twin Beds'
                    ELSE 'Double Bed'
                END;
                SET bed_count = CASE (room_num % 4)
                    WHEN 0 THEN 1
                    WHEN 1 THEN 1
                    WHEN 2 THEN 2
                    ELSE 1
                END;
                SET max_guests = CASE (room_num % 4)
                    WHEN 0 THEN 2
                    WHEN 1 THEN 2
                    WHEN 2 THEN 2
                    ELSE 2
                END;
                SET room_size = 22 + (room_num % 6);
                SET has_balcony = (room_num % 3) = 0;
                SET view_type = 'City View';
            
            -- Phòng 11-15: Superior/Deluxe
            ELSEIF room_num BETWEEN 11 AND 15 THEN
                SET room_type = 'Deluxe';
                SET room_price = 850000 + (floor_num * 90000);
                SET bed_type = CASE (room_num % 3)
                    WHEN 0 THEN 'King Bed'
                    WHEN 1 THEN 'Queen Bed'
                    ELSE '2 Double Beds'
                END;
                SET bed_count = CASE (room_num % 3)
                    WHEN 0 THEN 1
                    WHEN 1 THEN 1
                    ELSE 2
                END;
                SET max_guests = CASE (room_num % 3)
                    WHEN 0 THEN 2
                    WHEN 1 THEN 2
                    ELSE 4
                END;
                SET room_size = 28 + (room_num % 8);
                SET has_balcony = TRUE;
                SET view_type = CASE 
                    WHEN floor_num >= 5 THEN 'Sea View'
                    WHEN floor_num >= 3 THEN 'Mountain View'
                    ELSE 'Garden View'
                END;
            
            -- Phòng 16-18: Executive/Family
            ELSEIF room_num BETWEEN 16 AND 18 THEN
                SET room_type = CASE room_num
                    WHEN 16 THEN 'Family'
                    WHEN 17 THEN 'Executive'
                    WHEN 18 THEN 'Business'
                END;
                SET room_price = 1200000 + (floor_num * 120000);
                SET bed_type = CASE room_num
                    WHEN 16 THEN '3 Single Beds'
                    WHEN 17 THEN 'King Bed'
                    WHEN 18 THEN 'Queen Bed'
                END;
                SET bed_count = CASE room_num
                    WHEN 16 THEN 3
                    WHEN 17 THEN 1
                    WHEN 18 THEN 1
                END;
                SET max_guests = CASE room_num
                    WHEN 16 THEN 3
                    WHEN 17 THEN 2
                    WHEN 18 THEN 2
                END;
                SET room_size = 35 + (room_num % 5);
                SET has_balcony = TRUE;
                SET view_type = CASE floor_num
                    WHEN 7 THEN 'Sea View'
                    WHEN 6 THEN 'Pool View'
                    ELSE 'City View'
                END;
            
            -- Phòng 19-21: Suite/Honeymoon
            ELSEIF room_num BETWEEN 19 AND 21 THEN
                SET room_type = CASE room_num
                    WHEN 19 THEN 'Suite'
                    WHEN 20 THEN 'Honeymoon'
                    WHEN 21 THEN 'Suite'
                END;
                SET room_price = 1800000 + (floor_num * 150000);
                SET bed_type = 'King Bed';
                SET bed_count = 1;
                SET max_guests = CASE room_num
                    WHEN 20 THEN 2
                    ELSE 3
                END;
                SET room_size = 45 + (room_num % 7);
                SET has_balcony = TRUE;
                SET view_type = CASE floor_num
                    WHEN 7 THEN 'Sea View'
                    WHEN 6 THEN 'Mountain View'
                    WHEN 5 THEN 'Pool View'
                    ELSE 'Garden View'
                END;
            
            -- Phòng 22-23: Presidential/VIP
            ELSE
                SET room_type = CASE room_num
                    WHEN 22 THEN 'Executive'
                    WHEN 23 THEN 'Presidential'
                END;
                SET room_price = CASE room_num
                    WHEN 22 THEN 2500000 + (floor_num * 180000)
                    WHEN 23 THEN 3500000 + (floor_num * 250000)
                END;
                SET bed_type = CASE room_num
                    WHEN 22 THEN 'King Bed'
                    WHEN 23 THEN '2 Double Beds'
                END;
                SET bed_count = CASE room_num
                    WHEN 22 THEN 1
                    WHEN 23 THEN 2
                END;
                SET max_guests = CASE room_num
                    WHEN 22 THEN 2
                    WHEN 23 THEN 4
                END;
                SET room_size = CASE room_num
                    WHEN 22 THEN 55 + (floor_num * 2)
                    WHEN 23 THEN 70 + (floor_num * 3)
                END;
                SET has_balcony = TRUE;
                SET view_type = CASE floor_num
                    WHEN 7 THEN 'Sea View'
                    WHEN 6 THEN 'Mountain View'
                    WHEN 5 THEN 'Lake View'
                    ELSE 'Garden View'
                END;
            END IF;
            
            -- Trạng thái ngẫu nhiên (80% available, 15% occupied, 5% các trạng thái khác)
            SET @status = CASE FLOOR(RAND() * 100)
                WHEN 0 THEN 'maintenance'
                WHEN 1 THEN 'cleaning'
                WHEN 2 THEN 'out_of_order'
                WHEN 3 THEN 'reserved'
                WHEN 4 THEN 'occupied'
                WHEN 5 THEN 'occupied'
                WHEN 6 THEN 'occupied'
                WHEN 7 THEN 'occupied'
                WHEN 8 THEN 'occupied'
                WHEN 9 THEN 'occupied'
                WHEN 10 THEN 'occupied'
                WHEN 11 THEN 'occupied'
                WHEN 12 THEN 'occupied'
                WHEN 13 THEN 'occupied'
                WHEN 14 THEN 'occupied'
                WHEN 15 THEN 'occupied'
                WHEN 16 THEN 'occupied'
                WHEN 17 THEN 'occupied'
                ELSE 'available'
            END;
            
            -- Chèn phòng vào database
            INSERT INTO rooms (
                room_id, room_number, floor_number, floor_code,
                room_type, bed_type, bed_count, max_guests,
                base_price, room_size, view_type, balcony,
                smoking_allowed, status
            ) VALUES (
                room_id, room_number, floor_num, floor_code,
                room_type, bed_type, bed_count, max_guests,
                room_price, room_size, view_type, has_balcony,
                FALSE, @status
            );
            
            SET room_num = room_num + 1;
        END WHILE;
        
        SET floor_num = floor_num + 1;
    END WHILE;
    
    SELECT CONCAT('Generated ', (SELECT COUNT(*) FROM rooms), ' rooms (7 floors × 23 rooms)') as message;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `bank_transactions`
--

CREATE TABLE `bank_transactions` (
  `transaction_id` int(11) NOT NULL,
  `qr_id` varchar(50) DEFAULT NULL,
  `reference_id` varchar(100) DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'VND',
  `transaction_type` enum('deposit','withdrawal','transfer','refund') DEFAULT 'deposit',
  `transaction_date` date NOT NULL,
  `transaction_time` time NOT NULL,
  `bank_code` varchar(10) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `account_number` varchar(20) DEFAULT NULL,
  `account_name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `sender_name` varchar(100) DEFAULT NULL,
  `sender_account` varchar(20) DEFAULT NULL,
  `status` enum('pending','completed','failed','cancelled') DEFAULT 'pending',
  `verification_status` enum('unverified','verified','suspicious') DEFAULT 'unverified',
  `verified_by` int(11) DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `verification_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `guest_id` int(11) DEFAULT NULL,
  `room_id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `check_in_date` date NOT NULL,
  `check_in` date DEFAULT NULL,
  `check_out_date` date NOT NULL,
  `check_out` date DEFAULT NULL,
  `status` enum('confirmed','checked_in','checked_out','cancelled') DEFAULT 'confirmed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `guest_id`, `room_id`, `customer_name`, `customer_email`, `customer_phone`, `check_in_date`, `check_in`, `check_out_date`, `check_out`, `status`, `created_at`) VALUES
(11, 3, 102, 'kokokokoko', 'dinhtanuy547@gmail.com', '0911 111 111', '2025-12-05', NULL, '2121-11-13', NULL, 'checked_out', '2025-12-05 02:26:32'),
(12, 3, 102, 'kokofw', 'dinhtanuy547@gmail.com', '0911 111 111', '2025-12-05', NULL, '2025-12-06', NULL, 'checked_out', '2025-12-05 02:28:32');

-- --------------------------------------------------------

--
-- Stand-in structure for view `full_menu_view`
-- (See below for the actual view)
--
CREATE TABLE `full_menu_view` (
`category_name` varchar(50)
,`category_type` enum('drink','food','dessert','service','laundry','transport','tour','spa')
,`icon` varchar(50)
,`color_code` varchar(7)
,`item_id` int(11)
,`item_name` varchar(100)
,`description` text
,`price` decimal(10,2)
,`unit` varchar(20)
,`is_available` tinyint(1)
);

-- --------------------------------------------------------

--
-- Table structure for table `guests`
--

CREATE TABLE `guests` (
  `guest_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `id_card` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `guests`
--

INSERT INTO `guests` (`guest_id`, `name`, `full_name`, `email`, `phone`, `address`, `id_card`, `created_at`) VALUES
(3, 'kokofw', 'kokofw', 'dinhtanuy547@gmail.com', '0911 111 111', '', '111111111111', '2025-12-04 12:15:25');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_bank_accounts`
--

CREATE TABLE `hotel_bank_accounts` (
  `account_id` int(11) NOT NULL,
  `bank_code` varchar(10) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `account_number` varchar(20) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `account_type` enum('savings','checking','business','investment') DEFAULT 'business',
  `branch` varchar(100) DEFAULT NULL,
  `currency` varchar(3) DEFAULT 'VND',
  `is_active` tinyint(1) DEFAULT 1,
  `is_default` tinyint(1) DEFAULT 0,
  `daily_limit` decimal(15,2) DEFAULT 1000000000.00,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `amount` decimal(20,0) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_date` datetime DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'completed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `booking_id`, `amount`, `payment_method`, `payment_date`, `status`, `created_at`) VALUES
(8, 11, 14016400000, 'qr_code', '2025-12-05 09:27:49', 'completed', '2025-12-05 02:27:49'),
(9, 12, 400000, 'qr_code', '2025-12-05 09:28:43', 'completed', '2025-12-05 02:28:43');

-- --------------------------------------------------------

--
-- Table structure for table `qr_codes`
--

CREATE TABLE `qr_codes` (
  `qr_id` varchar(50) NOT NULL,
  `reference_id` varchar(100) DEFAULT NULL,
  `account_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'VND',
  `description` text DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `bank_code` varchar(10) DEFAULT NULL,
  `bank_account` varchar(20) DEFAULT NULL,
  `qr_data` text DEFAULT NULL,
  `qr_image_url` varchar(500) DEFAULT NULL,
  `qr_image_base64` longtext DEFAULT NULL,
  `expiry_time` datetime DEFAULT NULL,
  `created_time` datetime DEFAULT current_timestamp(),
  `status` enum('pending','paid','expired','cancelled') DEFAULT 'pending',
  `payment_status` enum('waiting','processing','completed','failed') DEFAULT 'waiting',
  `transaction_id` varchar(100) DEFAULT NULL,
  `transaction_time` datetime DEFAULT NULL,
  `transaction_amount` decimal(15,2) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `room_id` varchar(10) NOT NULL,
  `room_number` varchar(10) NOT NULL,
  `floor_number` int(11) NOT NULL,
  `floor_code` char(1) NOT NULL,
  `room_type` enum('Budget','Standard','Superior','Deluxe','Executive','Suite','Presidential','Family','Honeymoon','Business') DEFAULT 'Standard',
  `bed_type` enum('Single Bed','Twin Beds','Double Bed','Queen Bed','King Bed','2 Double Beds','3 Single Beds','Bunk Bed') DEFAULT 'Double Bed',
  `bed_count` int(11) DEFAULT 1,
  `max_guests` int(11) DEFAULT 2,
  `base_price` decimal(12,2) NOT NULL,
  `room_size` int(11) DEFAULT NULL,
  `view_type` enum('City View','Garden View','Pool View','Sea View','Mountain View','Lake View','Street View') DEFAULT 'City View',
  `balcony` tinyint(1) DEFAULT 0,
  `smoking_allowed` tinyint(1) DEFAULT 0,
  `status` enum('available','occupied','reserved','maintenance','cleaning','out_of_order') DEFAULT 'available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`room_id`, `room_number`, `floor_number`, `floor_code`, `room_type`, `bed_type`, `bed_count`, `max_guests`, `base_price`, `room_size`, `view_type`, `balcony`, `smoking_allowed`, `status`, `created_at`) VALUES
('101', 'A01', 1, 'A', 'Budget', 'Double Bed', 1, 1, 400000.00, 19, 'Street View', 0, 0, 'occupied', '2025-12-03 06:23:21'),
('102', 'A02', 1, 'A', 'Budget', 'Twin Beds', 2, 2, 400000.00, 20, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('103', 'A03', 1, 'A', 'Budget', 'Single Bed', 1, 1, 400000.00, 21, 'Street View', 0, 0, 'occupied', '2025-12-03 06:23:21'),
('104', 'A04', 1, 'A', 'Budget', 'Double Bed', 1, 1, 400000.00, 22, 'Street View', 0, 0, 'cleaning', '2025-12-03 06:23:21'),
('105', 'A05', 1, 'A', 'Budget', 'Twin Beds', 2, 2, 400000.00, 18, 'Street View', 0, 0, 'occupied', '2025-12-03 06:23:21'),
('106', 'A06', 1, 'A', 'Standard', 'Twin Beds', 2, 2, 620000.00, 22, 'City View', 1, 0, 'occupied', '2025-12-03 06:23:21'),
('107', 'A07', 1, 'A', 'Standard', 'Double Bed', 1, 2, 620000.00, 23, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('108', 'A08', 1, 'A', 'Standard', 'Double Bed', 1, 2, 620000.00, 24, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('109', 'A09', 1, 'A', 'Standard', 'Queen Bed', 1, 2, 620000.00, 25, 'City View', 1, 0, 'reserved', '2025-12-03 06:23:21'),
('110', 'A10', 1, 'A', 'Standard', 'Twin Beds', 2, 2, 620000.00, 26, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('111', 'A11', 1, 'A', 'Deluxe', '2 Double Beds', 2, 4, 940000.00, 31, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('112', 'A12', 1, 'A', 'Deluxe', 'King Bed', 1, 2, 940000.00, 32, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('113', 'A13', 1, 'A', 'Deluxe', 'Queen Bed', 1, 2, 940000.00, 33, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('114', 'A14', 1, 'A', 'Deluxe', '2 Double Beds', 2, 4, 940000.00, 34, 'Garden View', 1, 0, 'occupied', '2025-12-03 06:23:21'),
('115', 'A15', 1, 'A', 'Deluxe', 'King Bed', 1, 2, 940000.00, 35, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('116', 'A16', 1, 'A', 'Family', '3 Single Beds', 3, 3, 1320000.00, 36, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('117', 'A17', 1, 'A', 'Executive', 'King Bed', 1, 2, 1320000.00, 37, 'City View', 1, 0, 'occupied', '2025-12-03 06:23:21'),
('118', 'A18', 1, 'A', 'Business', 'Queen Bed', 1, 2, 1320000.00, 38, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('119', 'A19', 1, 'A', 'Suite', 'King Bed', 1, 3, 1950000.00, 50, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('120', 'A20', 1, 'A', 'Honeymoon', 'King Bed', 1, 2, 1950000.00, 51, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('121', 'A21', 1, 'A', 'Suite', 'King Bed', 1, 3, 1950000.00, 45, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('122', 'A22', 1, 'A', 'Executive', 'King Bed', 1, 2, 2680000.00, 57, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('123', 'A23', 1, 'A', 'Presidential', '2 Double Beds', 2, 4, 3750000.00, 73, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('201', 'B01', 2, 'B', 'Budget', 'Double Bed', 1, 1, 450000.00, 19, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('202', 'B02', 2, 'B', 'Budget', 'Twin Beds', 2, 2, 450000.00, 20, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('203', 'B03', 2, 'B', 'Budget', 'Single Bed', 1, 1, 450000.00, 21, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('204', 'B04', 2, 'B', 'Budget', 'Double Bed', 1, 1, 450000.00, 22, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('205', 'B05', 2, 'B', 'Budget', 'Twin Beds', 2, 2, 450000.00, 18, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('206', 'B06', 2, 'B', 'Standard', 'Twin Beds', 2, 2, 690000.00, 22, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('207', 'B07', 2, 'B', 'Standard', 'Double Bed', 1, 2, 690000.00, 23, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('208', 'B08', 2, 'B', 'Standard', 'Double Bed', 1, 2, 690000.00, 24, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('209', 'B09', 2, 'B', 'Standard', 'Queen Bed', 1, 2, 690000.00, 25, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('210', 'B10', 2, 'B', 'Standard', 'Twin Beds', 2, 2, 690000.00, 26, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('211', 'B11', 2, 'B', 'Deluxe', '2 Double Beds', 2, 4, 1030000.00, 31, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('212', 'B12', 2, 'B', 'Deluxe', 'King Bed', 1, 2, 1030000.00, 32, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('213', 'B13', 2, 'B', 'Deluxe', 'Queen Bed', 1, 2, 1030000.00, 33, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('214', 'B14', 2, 'B', 'Deluxe', '2 Double Beds', 2, 4, 1030000.00, 34, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('215', 'B15', 2, 'B', 'Deluxe', 'King Bed', 1, 2, 1030000.00, 35, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('216', 'B16', 2, 'B', 'Family', '3 Single Beds', 3, 3, 1440000.00, 36, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('217', 'B17', 2, 'B', 'Executive', 'King Bed', 1, 2, 1440000.00, 37, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('218', 'B18', 2, 'B', 'Business', 'Queen Bed', 1, 2, 1440000.00, 38, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('219', 'B19', 2, 'B', 'Suite', 'King Bed', 1, 3, 2100000.00, 50, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('220', 'B20', 2, 'B', 'Honeymoon', 'King Bed', 1, 2, 2100000.00, 51, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('221', 'B21', 2, 'B', 'Suite', 'King Bed', 1, 3, 2100000.00, 45, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('222', 'B22', 2, 'B', 'Executive', 'King Bed', 1, 2, 2860000.00, 59, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('223', 'B23', 2, 'B', 'Presidential', '2 Double Beds', 2, 4, 4000000.00, 76, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('301', 'C01', 3, 'C', 'Standard', 'Double Bed', 1, 1, 500000.00, 19, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('302', 'C02', 3, 'C', 'Standard', 'Twin Beds', 2, 2, 500000.00, 20, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('303', 'C03', 3, 'C', 'Standard', 'Single Bed', 1, 1, 500000.00, 21, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('304', 'C04', 3, 'C', 'Standard', 'Double Bed', 1, 1, 500000.00, 22, 'Street View', 0, 0, 'maintenance', '2025-12-03 06:23:21'),
('305', 'C05', 3, 'C', 'Standard', 'Twin Beds', 2, 2, 500000.00, 18, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('306', 'C06', 3, 'C', 'Standard', 'Twin Beds', 2, 2, 760000.00, 22, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('307', 'C07', 3, 'C', 'Standard', 'Double Bed', 1, 2, 760000.00, 23, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('308', 'C08', 3, 'C', 'Standard', 'Double Bed', 1, 2, 760000.00, 24, 'City View', 0, 0, 'cleaning', '2025-12-03 06:23:21'),
('309', 'C09', 3, 'C', 'Standard', 'Queen Bed', 1, 2, 760000.00, 25, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('310', 'C10', 3, 'C', 'Standard', 'Twin Beds', 2, 2, 760000.00, 26, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('311', 'C11', 3, 'C', 'Deluxe', '2 Double Beds', 2, 4, 1120000.00, 31, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('312', 'C12', 3, 'C', 'Deluxe', 'King Bed', 1, 2, 1120000.00, 32, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('313', 'C13', 3, 'C', 'Deluxe', 'Queen Bed', 1, 2, 1120000.00, 33, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('314', 'C14', 3, 'C', 'Deluxe', '2 Double Beds', 2, 4, 1120000.00, 34, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('315', 'C15', 3, 'C', 'Deluxe', 'King Bed', 1, 2, 1120000.00, 35, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('316', 'C16', 3, 'C', 'Family', '3 Single Beds', 3, 3, 1560000.00, 36, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('317', 'C17', 3, 'C', 'Executive', 'King Bed', 1, 2, 1560000.00, 37, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('318', 'C18', 3, 'C', 'Business', 'Queen Bed', 1, 2, 1560000.00, 38, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('319', 'C19', 3, 'C', 'Suite', 'King Bed', 1, 3, 2250000.00, 50, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('320', 'C20', 3, 'C', 'Honeymoon', 'King Bed', 1, 2, 2250000.00, 51, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('321', 'C21', 3, 'C', 'Suite', 'King Bed', 1, 3, 2250000.00, 45, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('322', 'C22', 3, 'C', 'Executive', 'King Bed', 1, 2, 3040000.00, 61, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('323', 'C23', 3, 'C', 'Presidential', '2 Double Beds', 2, 4, 4250000.00, 79, 'Garden View', 1, 0, 'occupied', '2025-12-03 06:23:21'),
('401', 'D01', 4, 'D', 'Standard', 'Double Bed', 1, 1, 550000.00, 19, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('402', 'D02', 4, 'D', 'Standard', 'Twin Beds', 2, 2, 550000.00, 20, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('403', 'D03', 4, 'D', 'Standard', 'Single Bed', 1, 1, 550000.00, 21, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('404', 'D04', 4, 'D', 'Standard', 'Double Bed', 1, 1, 550000.00, 22, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('405', 'D05', 4, 'D', 'Standard', 'Twin Beds', 2, 2, 550000.00, 18, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('406', 'D06', 4, 'D', 'Superior', 'Twin Beds', 2, 2, 830000.00, 22, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('407', 'D07', 4, 'D', 'Superior', 'Double Bed', 1, 2, 830000.00, 23, 'City View', 0, 0, 'out_of_order', '2025-12-03 06:23:21'),
('408', 'D08', 4, 'D', 'Superior', 'Double Bed', 1, 2, 830000.00, 24, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('409', 'D09', 4, 'D', 'Superior', 'Queen Bed', 1, 2, 830000.00, 25, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('410', 'D10', 4, 'D', 'Superior', 'Twin Beds', 2, 2, 830000.00, 26, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('411', 'D11', 4, 'D', 'Deluxe', '2 Double Beds', 2, 4, 1210000.00, 31, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('412', 'D12', 4, 'D', 'Deluxe', 'King Bed', 1, 2, 1210000.00, 32, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('413', 'D13', 4, 'D', 'Deluxe', 'Queen Bed', 1, 2, 1210000.00, 33, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('414', 'D14', 4, 'D', 'Deluxe', '2 Double Beds', 2, 4, 1210000.00, 34, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('415', 'D15', 4, 'D', 'Deluxe', 'King Bed', 1, 2, 1210000.00, 35, 'Mountain View', 1, 0, 'occupied', '2025-12-03 06:23:21'),
('416', 'D16', 4, 'D', 'Family', '3 Single Beds', 3, 3, 1680000.00, 36, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('417', 'D17', 4, 'D', 'Executive', 'King Bed', 1, 2, 1680000.00, 37, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('418', 'D18', 4, 'D', 'Business', 'Queen Bed', 1, 2, 1680000.00, 38, 'City View', 1, 0, 'cleaning', '2025-12-03 06:23:21'),
('419', 'D19', 4, 'D', 'Suite', 'King Bed', 1, 3, 2400000.00, 50, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('420', 'D20', 4, 'D', 'Honeymoon', 'King Bed', 1, 2, 2400000.00, 51, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('421', 'D21', 4, 'D', 'Suite', 'King Bed', 1, 3, 2400000.00, 45, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('422', 'D22', 4, 'D', 'Executive', 'King Bed', 1, 2, 3220000.00, 63, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('423', 'D23', 4, 'D', 'Presidential', '2 Double Beds', 2, 4, 4500000.00, 82, 'Garden View', 1, 0, 'available', '2025-12-03 06:23:21'),
('501', 'E01', 5, 'E', 'Standard', 'Double Bed', 1, 1, 600000.00, 19, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('502', 'E02', 5, 'E', 'Standard', 'Twin Beds', 2, 2, 600000.00, 20, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('503', 'E03', 5, 'E', 'Standard', 'Single Bed', 1, 1, 600000.00, 21, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('504', 'E04', 5, 'E', 'Standard', 'Double Bed', 1, 1, 600000.00, 22, 'Street View', 0, 0, 'occupied', '2025-12-03 06:23:21'),
('505', 'E05', 5, 'E', 'Standard', 'Twin Beds', 2, 2, 600000.00, 18, 'Street View', 0, 0, 'occupied', '2025-12-03 06:23:21'),
('506', 'E06', 5, 'E', 'Superior', 'Twin Beds', 2, 2, 900000.00, 22, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('507', 'E07', 5, 'E', 'Superior', 'Double Bed', 1, 2, 900000.00, 23, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('508', 'E08', 5, 'E', 'Superior', 'Double Bed', 1, 2, 900000.00, 24, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('509', 'E09', 5, 'E', 'Superior', 'Queen Bed', 1, 2, 900000.00, 25, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('510', 'E10', 5, 'E', 'Superior', 'Twin Beds', 2, 2, 900000.00, 26, 'City View', 0, 0, 'occupied', '2025-12-03 06:23:21'),
('511', 'E11', 5, 'E', 'Deluxe', '2 Double Beds', 2, 4, 1300000.00, 31, 'Sea View', 1, 0, 'cleaning', '2025-12-03 06:23:21'),
('512', 'E12', 5, 'E', 'Deluxe', 'King Bed', 1, 2, 1300000.00, 32, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('513', 'E13', 5, 'E', 'Deluxe', 'Queen Bed', 1, 2, 1300000.00, 33, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('514', 'E14', 5, 'E', 'Deluxe', '2 Double Beds', 2, 4, 1300000.00, 34, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('515', 'E15', 5, 'E', 'Deluxe', 'King Bed', 1, 2, 1300000.00, 35, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('516', 'E16', 5, 'E', 'Family', '3 Single Beds', 3, 3, 1800000.00, 36, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('517', 'E17', 5, 'E', 'Executive', 'King Bed', 1, 2, 1800000.00, 37, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('518', 'E18', 5, 'E', 'Business', 'Queen Bed', 1, 2, 1800000.00, 38, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('519', 'E19', 5, 'E', 'Suite', 'King Bed', 1, 3, 2550000.00, 50, 'Pool View', 1, 0, 'available', '2025-12-03 06:23:21'),
('520', 'E20', 5, 'E', 'Honeymoon', 'King Bed', 1, 2, 2550000.00, 51, 'Pool View', 1, 0, 'occupied', '2025-12-03 06:23:21'),
('521', 'E21', 5, 'E', 'Suite', 'King Bed', 1, 3, 2550000.00, 45, 'Pool View', 1, 0, 'available', '2025-12-03 06:23:21'),
('522', 'E22', 5, 'E', 'Executive', 'King Bed', 1, 2, 3400000.00, 65, 'Lake View', 1, 0, 'available', '2025-12-03 06:23:21'),
('523', 'E23', 5, 'E', 'Presidential', '2 Double Beds', 2, 4, 4750000.00, 85, 'Lake View', 1, 0, 'occupied', '2025-12-03 06:23:21'),
('601', 'F01', 6, 'F', 'Standard', 'Double Bed', 1, 1, 650000.00, 19, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('602', 'F02', 6, 'F', 'Standard', 'Twin Beds', 2, 2, 650000.00, 20, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('603', 'F03', 6, 'F', 'Standard', 'Single Bed', 1, 1, 650000.00, 21, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('604', 'F04', 6, 'F', 'Standard', 'Double Bed', 1, 1, 650000.00, 22, 'Street View', 0, 0, 'maintenance', '2025-12-03 06:23:21'),
('605', 'F05', 6, 'F', 'Standard', 'Twin Beds', 2, 2, 650000.00, 18, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('606', 'F06', 6, 'F', 'Superior', 'Twin Beds', 2, 2, 970000.00, 22, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('607', 'F07', 6, 'F', 'Superior', 'Double Bed', 1, 2, 970000.00, 23, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('608', 'F08', 6, 'F', 'Superior', 'Double Bed', 1, 2, 970000.00, 24, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('609', 'F09', 6, 'F', 'Superior', 'Queen Bed', 1, 2, 970000.00, 25, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('610', 'F10', 6, 'F', 'Superior', 'Twin Beds', 2, 2, 970000.00, 26, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('611', 'F11', 6, 'F', 'Deluxe', '2 Double Beds', 2, 4, 1390000.00, 31, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('612', 'F12', 6, 'F', 'Deluxe', 'King Bed', 1, 2, 1390000.00, 32, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('613', 'F13', 6, 'F', 'Deluxe', 'Queen Bed', 1, 2, 1390000.00, 33, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('614', 'F14', 6, 'F', 'Deluxe', '2 Double Beds', 2, 4, 1390000.00, 34, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('615', 'F15', 6, 'F', 'Deluxe', 'King Bed', 1, 2, 1390000.00, 35, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('616', 'F16', 6, 'F', 'Family', '3 Single Beds', 3, 3, 1920000.00, 36, 'Pool View', 1, 0, 'available', '2025-12-03 06:23:21'),
('617', 'F17', 6, 'F', 'Executive', 'King Bed', 1, 2, 1920000.00, 37, 'Pool View', 1, 0, 'available', '2025-12-03 06:23:21'),
('618', 'F18', 6, 'F', 'Business', 'Queen Bed', 1, 2, 1920000.00, 38, 'Pool View', 1, 0, 'available', '2025-12-03 06:23:21'),
('619', 'F19', 6, 'F', 'Suite', 'King Bed', 1, 3, 2700000.00, 50, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('620', 'F20', 6, 'F', 'Honeymoon', 'King Bed', 1, 2, 2700000.00, 51, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('621', 'F21', 6, 'F', 'Suite', 'King Bed', 1, 3, 2700000.00, 45, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('622', 'F22', 6, 'F', 'Executive', 'King Bed', 1, 2, 3580000.00, 67, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('623', 'F23', 6, 'F', 'Presidential', '2 Double Beds', 2, 4, 5000000.00, 88, 'Mountain View', 1, 0, 'available', '2025-12-03 06:23:21'),
('701', 'G01', 7, 'G', 'Standard', 'Double Bed', 1, 1, 700000.00, 19, 'Street View', 0, 0, 'occupied', '2025-12-03 06:23:21'),
('702', 'G02', 7, 'G', 'Standard', 'Twin Beds', 2, 2, 700000.00, 20, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('703', 'G03', 7, 'G', 'Standard', 'Single Bed', 1, 1, 700000.00, 21, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('704', 'G04', 7, 'G', 'Standard', 'Double Bed', 1, 1, 700000.00, 22, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('705', 'G05', 7, 'G', 'Standard', 'Twin Beds', 2, 2, 700000.00, 18, 'Street View', 0, 0, 'available', '2025-12-03 06:23:21'),
('706', 'G06', 7, 'G', 'Superior', 'Twin Beds', 2, 2, 1040000.00, 22, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('707', 'G07', 7, 'G', 'Superior', 'Double Bed', 1, 2, 1040000.00, 23, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('708', 'G08', 7, 'G', 'Superior', 'Double Bed', 1, 2, 1040000.00, 24, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('709', 'G09', 7, 'G', 'Superior', 'Queen Bed', 1, 2, 1040000.00, 25, 'City View', 1, 0, 'available', '2025-12-03 06:23:21'),
('710', 'G10', 7, 'G', 'Superior', 'Twin Beds', 2, 2, 1040000.00, 26, 'City View', 0, 0, 'available', '2025-12-03 06:23:21'),
('711', 'G11', 7, 'G', 'Deluxe', '2 Double Beds', 2, 4, 1480000.00, 31, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('712', 'G12', 7, 'G', 'Deluxe', 'King Bed', 1, 2, 1480000.00, 32, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('713', 'G13', 7, 'G', 'Deluxe', 'Queen Bed', 1, 2, 1480000.00, 33, 'Sea View', 1, 0, 'occupied', '2025-12-03 06:23:21'),
('714', 'G14', 7, 'G', 'Deluxe', '2 Double Beds', 2, 4, 1480000.00, 34, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('715', 'G15', 7, 'G', 'Deluxe', 'King Bed', 1, 2, 1480000.00, 35, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('716', 'G16', 7, 'G', 'Family', '3 Single Beds', 3, 3, 2040000.00, 36, 'Sea View', 1, 0, 'maintenance', '2025-12-03 06:23:21'),
('717', 'G17', 7, 'G', 'Executive', 'King Bed', 1, 2, 2040000.00, 37, 'Sea View', 1, 0, 'occupied', '2025-12-03 06:23:21'),
('718', 'G18', 7, 'G', 'Business', 'Queen Bed', 1, 2, 2040000.00, 38, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('719', 'G19', 7, 'G', 'Suite', 'King Bed', 1, 3, 2850000.00, 50, 'Sea View', 1, 0, 'occupied', '2025-12-03 06:23:21'),
('720', 'G20', 7, 'G', 'Honeymoon', 'King Bed', 1, 2, 2850000.00, 51, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('721', 'G21', 7, 'G', 'Suite', 'King Bed', 1, 3, 2850000.00, 45, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('722', 'G22', 7, 'G', 'Executive', 'King Bed', 1, 2, 3760000.00, 69, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21'),
('723', 'G23', 7, 'G', 'Presidential', '2 Double Beds', 2, 4, 5250000.00, 91, 'Sea View', 1, 0, 'available', '2025-12-03 06:23:21');

-- --------------------------------------------------------

--
-- Stand-in structure for view `room_overview`
-- (See below for the actual view)
--
CREATE TABLE `room_overview` (
`floor_code` char(1)
,`floor_number` int(11)
,`total_rooms` bigint(21)
,`available_rooms` decimal(22,0)
,`occupied_rooms` decimal(22,0)
,`reserved_rooms` decimal(22,0)
,`min_price` decimal(12,2)
,`max_price` decimal(12,2)
,`avg_price` decimal(16,6)
);

-- --------------------------------------------------------

--
-- Table structure for table `room_services`
--

CREATE TABLE `room_services` (
  `service_id` int(11) NOT NULL,
  `room_id` varchar(10) NOT NULL,
  `guest_name` varchar(100) DEFAULT NULL,
  `service_date` date NOT NULL,
  `service_time` time NOT NULL,
  `status` enum('pending','preparing','delivering','completed','cancelled') DEFAULT 'pending',
  `total_amount` decimal(12,2) DEFAULT 0.00,
  `payment_status` enum('unpaid','paid') DEFAULT 'unpaid',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `room_services`
--

INSERT INTO `room_services` (`service_id`, `room_id`, `guest_name`, `service_date`, `service_time`, `status`, `total_amount`, `payment_status`, `created_at`) VALUES
(1, '101', 'Nguyễn Văn An', '2024-12-03', '08:30:00', 'completed', 115000.00, 'paid', '2025-12-03 06:23:21'),
(2, '105', 'Trần Thị Bình', '2024-12-03', '14:15:00', 'delivering', 55000.00, 'unpaid', '2025-12-03 06:23:21'),
(3, '208', 'Lê Văn Cường', '2024-12-03', '20:00:00', 'preparing', 70000.00, 'unpaid', '2025-12-03 06:23:21'),
(4, '212', 'Phạm Thị Dung', '2024-12-03', '10:00:00', 'pending', 150000.00, 'unpaid', '2025-12-03 06:23:21'),
(5, '315', 'Hoàng Minh Đức', '2024-12-04', '09:45:00', 'completed', 85000.00, 'paid', '2025-12-03 06:23:21'),
(6, '419', 'Vũ Thị Hương', '2024-12-04', '16:20:00', 'completed', 45000.00, 'paid', '2025-12-03 06:23:21'),
(7, '522', 'Đặng Văn Khải', '2024-12-04', '19:30:00', 'preparing', 120000.00, 'unpaid', '2025-12-03 06:23:21'),
(8, '623', 'Bùi Thị Lan', '2024-12-05', '07:15:00', 'pending', 300000.00, 'unpaid', '2025-12-03 06:23:21'),
(9, '717', 'Ngô Văn Minh', '2024-12-05', '12:00:00', 'completed', 65000.00, 'paid', '2025-12-03 06:23:21');

-- --------------------------------------------------------

--
-- Table structure for table `services_menu`
--

CREATE TABLE `services_menu` (
  `item_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `is_available` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services_menu`
--

INSERT INTO `services_menu` (`item_id`, `category_id`, `item_name`, `description`, `price`, `unit`, `is_available`) VALUES
(1, 1, 'Cà phê đen', 'Cà phê đen truyền thống', 25000.00, 'ly', 1),
(2, 1, 'Cà phê sữa', 'Cà phê sữa đặc biệt', 30000.00, 'ly', 1),
(3, 1, 'Nước suối', 'Nước suối 500ml', 15000.00, 'chai', 1),
(4, 1, 'Coca Cola', 'Coca/Pepsi/7Up 330ml', 20000.00, 'lon', 1),
(5, 1, 'Nước cam ép', 'Cam tươi ép', 35000.00, 'ly', 1),
(6, 1, 'Trà đá', 'Trà đá truyền thống', 10000.00, 'ly', 1),
(7, 2, 'Mì tôm trứng', 'Mì tôm + 2 trứng', 40000.00, 'tô', 1),
(8, 2, 'Bánh mì pate', 'Bánh mì pate đặc biệt', 25000.00, 'ổ', 1),
(9, 2, 'Trái cây dĩa', 'Dĩa trái cây theo mùa', 50000.00, 'dĩa', 1),
(10, 2, 'Bánh ngọt', 'Bánh ngọt các loại', 30000.00, 'cái', 1),
(11, 2, 'Xúc xích nướng', 'Xúc xích Đức', 45000.00, 'phần', 1),
(12, 2, 'Bánh bao', 'Bánh bao nhân thịt', 20000.00, 'cái', 1),
(13, 3, 'Kem vani', 'Kem vani Ý', 35000.00, 'ly', 1),
(14, 3, 'Kem socola', 'Kem socola Bỉ', 35000.00, 'ly', 1),
(15, 3, 'Chè đậu đen', 'Chè đậu đen truyền thống', 25000.00, 'chén', 1),
(16, 3, 'Sữa chua', 'Sữa chua hoa quả', 20000.00, 'hũ', 1),
(17, 3, 'Bánh flan', 'Bánh flan caramel', 30000.00, 'cái', 1),
(18, 3, 'Trái cây mix', 'Mix 3 loại trái cây', 40000.00, 'dĩa', 1),
(19, 4, 'Giặt ủi', 'Giặt 1kg đồ', 50000.00, 'kg', 1),
(20, 4, 'Thuê xe máy', 'Thuê 24 giờ', 150000.00, 'ngày', 1),
(21, 4, 'Đưa đón sân bay', 'Xe 4-7 chỗ', 300000.00, 'chuyến', 1),
(22, 4, 'Tour du lịch', 'Tour nửa ngày', 500000.00, 'tour', 1);

-- --------------------------------------------------------

--
-- Table structure for table `service_categories`
--

CREATE TABLE `service_categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `category_type` enum('drink','food','dessert','service','laundry','transport','tour','spa') NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `color_code` varchar(7) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_categories`
--

INSERT INTO `service_categories` (`category_id`, `category_name`, `category_type`, `icon`, `color_code`, `display_order`, `created_at`) VALUES
(1, 'Thức uống', 'drink', 'fa-coffee', '#3498db', 1, '2025-12-03 06:23:21'),
(2, 'Đồ ăn nhẹ', 'food', 'fa-hamburger', '#e74c3c', 2, '2025-12-03 06:23:21'),
(3, 'Tráng miệng', 'dessert', 'fa-ice-cream', '#f39c12', 3, '2025-12-03 06:23:21'),
(4, 'Dịch vụ khác', 'service', 'fa-concierge-bell', '#27ae60', 4, '2025-12-03 06:23:21');

-- --------------------------------------------------------

--
-- Stand-in structure for view `service_details_view`
-- (See below for the actual view)
--
CREATE TABLE `service_details_view` (
`service_id` int(11)
,`floor_code` char(1)
,`room_number` varchar(10)
,`guest_name` varchar(100)
,`service_date` date
,`service_time` time
,`order_status` enum('pending','preparing','delivering','completed','cancelled')
,`total_amount` decimal(12,2)
,`payment_status` enum('unpaid','paid')
,`items` mediumtext
);

-- --------------------------------------------------------

--
-- Table structure for table `service_items`
--

CREATE TABLE `service_items` (
  `order_item_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `unit_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_items`
--

INSERT INTO `service_items` (`order_item_id`, `service_id`, `item_id`, `quantity`, `unit_price`) VALUES
(1, 1, 1, 2, 25000.00),
(2, 1, 7, 1, 40000.00),
(3, 1, 10, 1, 30000.00),
(4, 2, 4, 2, 20000.00),
(5, 2, 6, 1, 10000.00),
(6, 3, 17, 2, 35000.00),
(7, 4, 19, 1, 150000.00),
(8, 5, 2, 1, 30000.00),
(9, 5, 8, 1, 25000.00),
(10, 5, 15, 1, 30000.00),
(11, 6, 5, 1, 35000.00),
(12, 6, 9, 1, 50000.00),
(13, 6, 18, 1, 20000.00),
(14, 7, 20, 1, 300000.00),
(15, 8, 3, 1, 15000.00),
(16, 8, 11, 1, 45000.00),
(17, 8, 13, 1, 35000.00);

-- --------------------------------------------------------

--
-- Table structure for table `vietqr_config`
--

CREATE TABLE `vietqr_config` (
  `config_id` int(11) NOT NULL,
  `client_id` varchar(100) DEFAULT NULL,
  `api_key` varchar(255) DEFAULT NULL,
  `api_secret` varchar(255) DEFAULT NULL,
  `merchant_code` varchar(50) DEFAULT NULL,
  `merchant_name` varchar(100) DEFAULT NULL,
  `service_code` varchar(50) DEFAULT NULL,
  `template` varchar(50) DEFAULT 'compact2',
  `callback_url` varchar(255) DEFAULT NULL,
  `webhook_url` varchar(255) DEFAULT NULL,
  `qr_width` int(11) DEFAULT 200,
  `qr_height` int(11) DEFAULT 200,
  `qr_logo_url` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `sandbox_mode` tinyint(1) DEFAULT 1,
  `contact_email` varchar(100) DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure for view `full_menu_view`
--
DROP TABLE IF EXISTS `full_menu_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `full_menu_view`  AS SELECT `c`.`category_name` AS `category_name`, `c`.`category_type` AS `category_type`, `c`.`icon` AS `icon`, `c`.`color_code` AS `color_code`, `m`.`item_id` AS `item_id`, `m`.`item_name` AS `item_name`, `m`.`description` AS `description`, `m`.`price` AS `price`, `m`.`unit` AS `unit`, `m`.`is_available` AS `is_available` FROM (`service_categories` `c` join `services_menu` `m` on(`c`.`category_id` = `m`.`category_id`)) ORDER BY `c`.`display_order` ASC, `m`.`item_name` ASC ;

-- --------------------------------------------------------

--
-- Structure for view `room_overview`
--
DROP TABLE IF EXISTS `room_overview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `room_overview`  AS SELECT `rooms`.`floor_code` AS `floor_code`, `rooms`.`floor_number` AS `floor_number`, count(0) AS `total_rooms`, sum(case when `rooms`.`status` = 'available' then 1 else 0 end) AS `available_rooms`, sum(case when `rooms`.`status` = 'occupied' then 1 else 0 end) AS `occupied_rooms`, sum(case when `rooms`.`status` = 'reserved' then 1 else 0 end) AS `reserved_rooms`, min(`rooms`.`base_price`) AS `min_price`, max(`rooms`.`base_price`) AS `max_price`, avg(`rooms`.`base_price`) AS `avg_price` FROM `rooms` GROUP BY `rooms`.`floor_code`, `rooms`.`floor_number` ORDER BY `rooms`.`floor_number` ASC ;

-- --------------------------------------------------------

--
-- Structure for view `service_details_view`
--
DROP TABLE IF EXISTS `service_details_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `service_details_view`  AS SELECT `rs`.`service_id` AS `service_id`, `r`.`floor_code` AS `floor_code`, `r`.`room_number` AS `room_number`, `rs`.`guest_name` AS `guest_name`, `rs`.`service_date` AS `service_date`, `rs`.`service_time` AS `service_time`, `rs`.`status` AS `order_status`, `rs`.`total_amount` AS `total_amount`, `rs`.`payment_status` AS `payment_status`, group_concat(concat(`si`.`quantity`,'x ',`sm`.`item_name`) separator ', ') AS `items` FROM (((`room_services` `rs` join `rooms` `r` on(`rs`.`room_id` = `r`.`room_id`)) join `service_items` `si` on(`rs`.`service_id` = `si`.`service_id`)) join `services_menu` `sm` on(`si`.`item_id` = `sm`.`item_id`)) GROUP BY `rs`.`service_id`, `r`.`floor_code`, `r`.`room_number`, `rs`.`guest_name`, `rs`.`service_date`, `rs`.`service_time`, `rs`.`status`, `rs`.`total_amount`, `rs`.`payment_status` ORDER BY `rs`.`service_date` DESC, `rs`.`service_time` DESC ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_transactions`
--
ALTER TABLE `bank_transactions`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `qr_id` (`qr_id`),
  ADD KEY `idx_transaction_date` (`transaction_date`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `guest_id` (`guest_id`);

--
-- Indexes for table `guests`
--
ALTER TABLE `guests`
  ADD PRIMARY KEY (`guest_id`);

--
-- Indexes for table `hotel_bank_accounts`
--
ALTER TABLE `hotel_bank_accounts`
  ADD PRIMARY KEY (`account_id`),
  ADD UNIQUE KEY `uk_account_number` (`account_number`),
  ADD KEY `idx_bank_code` (`bank_code`),
  ADD KEY `idx_active` (`is_active`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `qr_codes`
--
ALTER TABLE `qr_codes`
  ADD PRIMARY KEY (`qr_id`),
  ADD UNIQUE KEY `reference_id` (`reference_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `idx_reference` (`reference_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created` (`created_time`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `room_services`
--
ALTER TABLE `room_services`
  ADD PRIMARY KEY (`service_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `services_menu`
--
ALTER TABLE `services_menu`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `service_categories`
--
ALTER TABLE `service_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `service_items`
--
ALTER TABLE `service_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `vietqr_config`
--
ALTER TABLE `vietqr_config`
  ADD PRIMARY KEY (`config_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank_transactions`
--
ALTER TABLE `bank_transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `guests`
--
ALTER TABLE `guests`
  MODIFY `guest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `hotel_bank_accounts`
--
ALTER TABLE `hotel_bank_accounts`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `room_services`
--
ALTER TABLE `room_services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `services_menu`
--
ALTER TABLE `services_menu`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `service_categories`
--
ALTER TABLE `service_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `service_items`
--
ALTER TABLE `service_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `vietqr_config`
--
ALTER TABLE `vietqr_config`
  MODIFY `config_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bank_transactions`
--
ALTER TABLE `bank_transactions`
  ADD CONSTRAINT `bank_transactions_ibfk_1` FOREIGN KEY (`qr_id`) REFERENCES `qr_codes` (`qr_id`) ON DELETE SET NULL;

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`guest_id`) REFERENCES `guests` (`guest_id`);

--
-- Constraints for table `qr_codes`
--
ALTER TABLE `qr_codes`
  ADD CONSTRAINT `qr_codes_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `hotel_bank_accounts` (`account_id`) ON DELETE CASCADE;

--
-- Constraints for table `room_services`
--
ALTER TABLE `room_services`
  ADD CONSTRAINT `room_services_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`room_id`) ON DELETE CASCADE;

--
-- Constraints for table `services_menu`
--
ALTER TABLE `services_menu`
  ADD CONSTRAINT `services_menu_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `service_categories` (`category_id`) ON DELETE CASCADE;

--
-- Constraints for table `service_items`
--
ALTER TABLE `service_items`
  ADD CONSTRAINT `service_items_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `room_services` (`service_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `service_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `services_menu` (`item_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
