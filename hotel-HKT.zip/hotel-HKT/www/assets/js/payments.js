let paymentsData = [];
let currentPaymentId = null;

// =======================================================
// ===== CÁC HÀM PHỤ TRỢ (HELPER FUNCTIONS) =================
// =======================================================

// Format tiền VNĐ
function formatCurrency(amount) {
    if (amount === undefined || amount === null) amount = 0;
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(amount);
}

// Format ngày
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    // Kiểm tra ngày hợp lệ
    if (isNaN(date.getTime())) return dateString; 
    return date.toLocaleString('vi-VN');
}

// Lấy text trạng thái
function getStatusText(status) {
    const statusMap = {
        'pending': 'Chờ thanh toán',
        'completed': 'Đã thanh toán',
        'cancelled': 'Đã hủy'
    };
    return statusMap[status] || status;
}

// 4. Cập nhật thống kê
function updateSummaryStats(payments) {
    // 💡 FIX 1: Đảm bảo payments là một MẢNG trước khi gọi .reduce() (Fix TypeError: payments.reduce is not a function)
    if (!Array.isArray(payments)) {
        payments = [];
    }
    
    const totalPayments = payments.length;
    // Sử dụng parseFloat an toàn
    const totalAmount = payments.reduce((sum, p) => sum + parseFloat(p.amount) || 0, 0); 
    const avgAmount = totalPayments > 0 ? totalAmount / totalPayments : 0;
    const pendingCount = payments.filter(p => p.payment_status === 'pending').length;

    // Kiểm tra sự tồn tại của các phần tử trước khi cập nhật
    const totalPaymentsEl = document.getElementById('totalPayments');
    const totalAmountEl = document.getElementById('totalAmount');
    const avgAmountEl = document.getElementById('avgAmount');
    const pendingCountEl = document.getElementById('pendingCount');

    if (totalPaymentsEl) totalPaymentsEl.textContent = totalPayments;
    if (totalAmountEl) totalAmountEl.textContent = formatCurrency(totalAmount);
    if (avgAmountEl) avgAmountEl.textContent = formatCurrency(avgAmount);
    if (pendingCountEl) pendingCountEl.textContent = pendingCount;
}

// 7. Hiển thị lỗi
function showError(message) {
    const tbody = document.getElementById('paymentsTableBody');
    
    if (!tbody) {
        console.error("❌ Không tìm thấy paymentsTableBody để hiển thị lỗi:", message);
        alert(`Lỗi nghiêm trọng: ${message}`);
        // 💡 FIX 2: Không gọi updateSummaryStats nếu tbody không tồn tại, vì nó không thể hiển thị kết quả đúng
        updateSummaryStats([]); 
        return;
    }
    
    tbody.innerHTML = `
        <tr>
            <td colspan="7" style="text-align: center; color: red; padding: 40px;">
                ⚠️ ${message}
            </td>
        </tr>
    `;
    
    // Xóa thống kê khi có lỗi tải dữ liệu
    updateSummaryStats([]); 
}


// =======================================================
// ===== CÁC HÀM CHÍNH (MAIN FUNCTIONS) ====================
// =======================================================

// 3. Render bảng thanh toán
function renderPaymentsTable(payments) {
    const tbody = document.getElementById('paymentsTableBody');
    if (!tbody) return; // Đảm bảo tbody tồn tại

    if (payments.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="empty-state">
                    <p>Không có dữ liệu thanh toán</p>
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = payments.map(payment => `
        <tr>
            <td>#${payment.payment_id}</td>
            <td>#${payment.booking_id}</td>
            <td>${payment.customer_name || 'N/A'}</td>
            <td><strong>${formatCurrency(payment.amount)}</strong></td>
            <td><span class="status-badge status-${payment.payment_status}">${getStatusText(payment.payment_status)}</span></td>
            <td>${formatDate(payment.created_at)}</td>
            <td>
                <button class="btn btn-primary btn-sm" onclick="viewQRCode(${payment.payment_id})">
                    🔍 Xem QR
                </button>
                ${payment.payment_status === 'pending' ? `
                    <button class="btn btn-success btn-sm" onclick="quickConfirm(${payment.payment_id})">
                        ✓ Xác nhận
                    </button>
                ` : ''}
            </td>
        </tr>
    `).join('');
}

// 6. Đóng modal
function closeModal() {
    const qrModal = document.getElementById('qrModal');
    if (qrModal) {
        qrModal.classList.remove('active');
    }
    currentPaymentId = null;
}

// 5. Lọc thanh toán
function filterPayments() {
    const status = document.getElementById('statusFilter')?.value || '';
    const search = document.getElementById('searchInput')?.value.toLowerCase() || '';
    
    let filtered = paymentsData;
    
    if (status) {
        filtered = filtered.filter(p => p.payment_status === status);
    }
    
    if (search) {
        filtered = filtered.filter(p => 
            p.payment_id.toString().includes(search) ||
            p.booking_id.toString().includes(search) ||
            (p.customer_name && p.customer_name.toLowerCase().includes(search))
        );
    }
    
    renderPaymentsTable(filtered);
}

// 7. API xác nhận thanh toán
async function confirmPaymentAPI(paymentId) {
    try {
        const formData = new FormData();
        formData.append('payment_id', paymentId);
        
        const response = await fetch('api/payment_api.php?action=confirm', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            alert('Lỗi Server: Không thể xác nhận thanh toán.');
            return;
        }

        const result = await response.json();
        
        if (result.success) {
            alert('✓ Xác nhận thanh toán thành công!');
            closeModal();
            loadPayments(); // Tải lại danh sách sau khi xác nhận
        } else {
            alert('Lỗi: ' + (result.message || 'Xác nhận thanh toán thất bại.'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Không thể xác nhận thanh toán (lỗi JSON/kết nối).');
    }
}

// 8. Xác nhận thanh toán nhanh
async function quickConfirm(paymentId) {
    if (!confirm('Xác nhận đã nhận được thanh toán?')) return;
    
    await confirmPaymentAPI(paymentId);
}

// 9. Xác nhận thanh toán từ modal (Hàm này có thể được gán vào nút trong modal)
async function confirmPayment() {
    if (!currentPaymentId) return;
    await confirmPaymentAPI(currentPaymentId);
}

// 10. Xem QR Code
async function viewQRCode(paymentId) {
    try {
        const response = await fetch(`api/payment_api.php?action=get&payment_id=${paymentId}`);
        
        if (!response.ok) {
            alert('Lỗi Server: Không thể tải thông tin chi tiết thanh toán.');
            return;
        }

        // Bắt lỗi JSON parse
        const payment = await response.json();
        
        if (payment && payment.success && payment.data) {
            const data = payment.data;
            currentPaymentId = paymentId;
            
            // Đảm bảo các phần tử modal tồn tại trước khi set
            const qrModal = document.getElementById('qrModal');
            if (!qrModal) return alert('Lỗi: Modal không tồn tại.');
            
            // Kiểm tra và gán giá trị vào các phần tử
            document.getElementById('qrImage').src = data.qr_code_url || 'placeholder.png';
            document.getElementById('modalBookingId').textContent = '#' + (data.booking_id || 'N/A');
            document.getElementById('modalCustomer').textContent = data.customer_name || 'N/A';
            document.getElementById('modalAmount').textContent = formatCurrency(data.amount);
            document.getElementById('modalAccountNumber').textContent = data.account_number || 'N/A';
            document.getElementById('modalDescription').textContent = data.description || 'N/A';
            
            qrModal.classList.add('active'); // Hiển thị modal (Giả định class 'active' dùng để show)
        } else {
             alert('Không thể tải thông tin thanh toán: ' + (payment.message || 'Dữ liệu không hợp lệ.'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Không thể tải thông tin thanh toán (Lỗi kết nối hoặc JSON).');
    }
}


// 1. Load tất cả payments
async function loadPayments() {
    try {
        const response = await fetch('api/payment_api.php?action=list');
        
        // **QUAN TRỌNG: Xử lý lỗi server trả về non-JSON (HTML)**
        if (!response.ok) {
            const errorText = await response.text(); 
            console.error('Lỗi Server HTTP Status:', response.status, errorText);
            showError(`Lỗi Server (${response.status}): Không thể tải dữ liệu thanh toán. Vui lòng kiểm tra payment_api.php.`);
            return;
        }

        // Cố gắng phân tích JSON (đây là nơi lỗi SyntaxError ban đầu xảy ra)
        const result = await response.json(); 
        
        if (result.success) {
            paymentsData = result.data;
            renderPaymentsTable(paymentsData);
            updateSummaryStats(paymentsData);
        } else {
            // Xử lý khi API trả về success=false
            showError(result.message || 'Lỗi không xác định từ API.');
        }
    } catch (error) {
        console.error('Error loading payments (JSON Parse/Fetch):', error);
        // Bắt lỗi khi response.json() thất bại (SyntaxError)
        showError('Lỗi dữ liệu: Dữ liệu nhận được không phải định dạng JSON hợp lệ. Vui lòng kiểm tra file payment_api.php.');
    }
}


// =======================================================
// ===== KHỞI TẠO (INITIALIZATION) =========================
// =======================================================

// 2. Load payments khi trang được tải (DOMContentLoaded)
document.addEventListener('DOMContentLoaded', function() {
    loadPayments();
    
    // Lắng nghe sự kiện filter
    const statusFilter = document.getElementById('statusFilter');
    const searchInput = document.getElementById('searchInput');

    if (statusFilter) {
        statusFilter.addEventListener('change', filterPayments);
    }
    if (searchInput) {
        searchInput.addEventListener('input', filterPayments);
    }
    
    // Kiểm tra và thêm sự kiện cho nút đóng modal
    const closeButton = document.querySelector('#qrModal .close-btn');
    if (closeButton) {
        closeButton.addEventListener('click', closeModal);
    }

    // Đảm bảo hàm confirmPayment có thể được gọi từ HTML của modal
    if (typeof window.confirmPayment === 'undefined') {
        window.confirmPayment = confirmPayment;
    }
    // Đảm bảo các hàm gọi qua onclick trong HTML tồn tại global
    if (typeof window.viewQRCode === 'undefined') {
        window.viewQRCode = viewQRCode;
    }
    if (typeof window.quickConfirm === 'undefined') {
        window.quickConfirm = quickConfirm;
    }
});