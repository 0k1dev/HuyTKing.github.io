// ===== rooms.js - FIXED VERSION =====
(function() {
    'use strict';
    
    const roomsContainer = document.getElementById('roomsContainer');
    if (!roomsContainer) return;
    
    console.log('✅ rooms.js: Khởi tạo trang rooms');
    
    // ===== CÁC HÀM CORE =====
    function formatCurrency(amount) {
        return amount ? new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(amount) : '0 ₫';
    }
    
    function getStatusInfo(status) {
        const map = {
            'available': { text: 'Còn trống', class: 'success', color: '#28a745' },
            'occupied': { text: 'Đã thuê', class: 'danger', color: '#dc3545' },
            'reserved': { text: 'Đã đặt', class: 'warning', color: '#ffc107' },
            'maintenance': { text: 'Bảo trì', class: 'secondary', color: '#6c757d' }
        };
        return map[status] || { text: status, class: 'info', color: '#17a2b8' };
    }
    
    // ===== HÀM CHÍNH =====
    function renderRooms(rooms) {
        if (!rooms || !rooms.length) {
            roomsContainer.innerHTML = `
                <div class="alert alert-info text-center m-3">
                    <i class="fas fa-info-circle"></i> Không có phòng nào
                </div>
            `;
            return;
        }
        
        roomsContainer.innerHTML = rooms.map(room => {
            const status = getStatusInfo(room.status);
            const price = formatCurrency(room.price_per_night);
            
            return `
            <div class="col-md-4 col-sm-6 mb-4">
                <div class="card h-100 border-${status.class}" style="border-left: 4px solid ${status.color}">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title mb-0">
                                <i class="fas fa-door-open text-primary"></i> ${room.room_number}
                            </h5>
                            <span class="badge bg-${status.class}">${status.text}</span>
                        </div>
                        
                        ${room.room_type ? `<p class="text-muted mb-2"><i class="fas fa-star"></i> ${room.room_type}</p>` : ''}
                        ${room.floor_code ? `<p class="text-muted mb-2"><i class="fas fa-building"></i> Tầng ${room.floor_code}</p>` : ''}
                        ${room.bed_type ? `<p class="text-muted mb-2"><i class="fas fa-bed"></i> ${room.bed_type}</p>` : ''}
                        
                        <div class="mt-3 pt-3 border-top">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <small class="text-muted d-block">Giá/đêm</small>
                                    <span class="h5 text-primary">${price}</span>
                                </div>
                                <div class="btn-group">
                                    ${room.status === 'available' ? `
                                    <button class="btn btn-sm btn-success" onclick="window.bookRoom(${room.room_id})">
                                        <i class="fas fa-calendar-check"></i> Đặt
                                    </button>
                                    ` : ''}
                                    <button class="btn btn-sm btn-outline-primary" onclick="window.showRoomDetail(${room.room_id})">
                                        <i class="fas fa-info"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            `;
        }).join('');
    }
    
    // ===== LOAD ROOMS - FIX URL =====
    function loadRooms() {
        // Hiển thị loading
        roomsContainer.innerHTML = `
            <div class="col-12 text-center py-5">
                <div class="spinner-border text-primary"></div>
                <p class="mt-2 text-muted">Đang tải...</p>
            </div>
        `;
        
        // Lấy filter
        const floor = document.getElementById('floorSelect')?.value || '';
        const type = document.getElementById('typeSelect')?.value || '';
        const status = document.getElementById('statusSelect')?.value || '';
        
        // Xây dựng URL - FIX QUAN TRỌNG
        let url = 'api/rooms.php?action=get_rooms';
        
        if (floor) url += `&floor=${encodeURIComponent(floor)}`;
        if (type) url += `&type=${encodeURIComponent(type)}`;
        if (status) url += `&status=${encodeURIComponent(status)}`;
        
        console.log('🌐 Fetch URL:', url);
        console.log('📌 Full path:', window.location.origin + '/hotel-HKT/' + url);
        
        // Thử với timeout ngắn
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        
        fetch(url, { signal: controller.signal })
            .then(response => {
                clearTimeout(timeoutId);
                
                console.log('📥 Response status:', response.status);
                console.log('📥 Response headers:', [...response.headers.entries()]);
                
                return response.text().then(text => {
                    console.log('📄 Raw response (first 500 chars):', text.substring(0, 500));
                    
                    try {
                        return JSON.parse(text);
                    } catch (e) {
                        console.error('❌ JSON parse error:', e);
                        console.error('Problematic text:', text);
                        throw new Error('Invalid JSON response');
                    }
                });
            })
            .then(data => {
                console.log('✅ Parsed data:', data);
                
                if (data && data.success) {
                    renderRooms(data.data || []);
                } else {
                    showError(data?.message || 'Lỗi không xác định từ server');
                }
            })
            .catch(err => {
                clearTimeout(timeoutId);
                console.error('❌ Fetch failed:', err);
                
                if (err.name === 'AbortError') {
                    showError('Timeout: Server không phản hồi sau 5 giây');
                } else {
                    showError('Lỗi kết nối: ' + err.message);
                }
                
                // Hiển thị dữ liệu mẫu
                setTimeout(renderSampleData, 1000);
            });
    }
    
    // ===== HÀM PHỤ =====
    function showError(msg) {
        roomsContainer.innerHTML = `
            <div class="col-12">
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> ${msg}
                    <button class="btn btn-sm btn-outline-danger ms-2" onclick="window.loadRooms()">
                        <i class="fas fa-redo"></i> Thử lại
                    </button>
                </div>
            </div>
        `;
    }
    
    function renderSampleData() {
        console.log('🔄 Loading sample data...');
        const sample = [
            { 
                room_id: 1, 
                room_number: '101', 
                room_type: 'Standard', 
                floor_code: '1', 
                price_per_night: 500000, 
                status: 'available', 
                bed_type: '2 giường đơn',
                max_guests: 2
            },
            { 
                room_id: 2, 
                room_number: '102', 
                room_type: 'Standard', 
                floor_code: '1', 
                price_per_night: 500000, 
                status: 'available', 
                bed_type: '1 giường đôi',
                max_guests: 2 
            }
        ];
        renderRooms(sample);
    }
    
    function showRoomDetail(id) {
        fetch(`api/rooms.php?action=detail&id=${id}`)
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    alert(`Phòng ${data.data.room_number}\nLoại: ${data.data.room_type}\nGiá: ${formatCurrency(data.data.price_per_night)}`);
                } else {
                    alert('Không thể lấy thông tin');
                }
            })
            .catch(() => alert('Lỗi kết nối'));
    }
    
    function bookRoom(id) {
        window.location.href = `?page=booking&room_id=${id}`;
    }
    
    // ===== INIT =====
    function init() {
        console.log('🚀 Starting rooms page...');
        console.log('📍 Current URL:', window.location.href);
        console.log('📍 Base path:', window.location.origin);
        
        loadRooms();
        
        // Auto filter
        ['floorSelect', 'typeSelect', 'statusSelect'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('change', loadRooms);
        });
    }
    
    // ===== START =====
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    // Export functions
    window.loadRooms = loadRooms;
    window.showRoomDetail = showRoomDetail;
    window.bookRoom = bookRoom;
    window.renderSampleData = renderSampleData;
    
})();