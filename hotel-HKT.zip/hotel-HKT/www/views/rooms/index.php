<?php
// views/rooms/index.php

require_once 'models/Room.php';

$roomModel = new Room();
$rooms = $roomModel->getAllRooms();
$roomTypes = $roomModel->getUniqueRoomTypes();
$stats = $roomModel->getRoomStatistics();

// Debug
if (isset($_GET['debug'])) {
    echo "<pre>";
    print_r($rooms);
    echo "</pre>";
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Phòng - Hotel Huytking</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: #f5f7fa;
            padding: 20px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
        }
        
        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .header-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: #4CAF50;
            color: white;
        }
        
        .btn-primary:hover {
            background: #45a049;
        }
        
        .btn-secondary {
            background: #2196F3;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #0b7dda;
        }
        
        .search-box {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .search-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            align-items: end;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #555;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            padding: 20px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.08);
            text-align: center;
            border-left: 5px solid #667eea;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: #333;
            margin: 10px 0;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        
        .rooms-table {
            padding: 20px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #495057;
            border-bottom: 2px solid #e9ecef;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
            color: #666;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        .room-number {
            font-weight: bold;
            color: #2196F3;
        }
        
        .room-type {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
        }
        
        .room-type-budget {
            background: #e8f5e9;
            color: #2e7d32;
        }
        
        .room-type-standard {
            background: #e3f2fd;
            color: #1565c0;
        }
        
        .room-type-deluxe {
            background: #f3e5f5;
            color: #7b1fa2;
        }
        
        .room-type-suite {
            background: #fff3e0;
            color: #ef6c00;
        }
        
        .price {
            font-weight: bold;
            color: #4CAF50;
        }
        
        .actions {
            display: flex;
            gap: 10px;
        }
        
        .btn-action {
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 0.85rem;
            text-decoration: none;
        }
        
        .btn-view {
            background: #2196F3;
            color: white;
        }
        
        .btn-edit {
            background: #FFC107;
            color: #333;
        }
        
        .btn-delete {
            background: #F44336;
            color: white;
        }
        
        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: #666;
        }
        
        .empty-state-icon {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            padding: 20px;
            gap: 10px;
        }
        
        .page-link {
            padding: 8px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-decoration: none;
            color: #333;
        }
        
        .page-link.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>🛏️ Quản lý Phòng</h1>
            <p>Quản lý thông tin phòng khách sạn</p>
            <div class="header-actions">
                <a href="?page=home" class="btn btn-secondary">🏠 Về trang chủ</a>
                <a href="?page=rooms&action=add" class="btn btn-primary">➕ Thêm phòng mới</a>
            </div>
        </div>
        
        <!-- Statistics -->
        <?php if ($stats): ?>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">Tổng số phòng</div>
                <div class="stat-value"><?php echo $stats['total_rooms'] ?? 0; ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Loại phòng</div>
                <div class="stat-value"><?php echo $stats['room_types'] ?? 0; ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Sức chứa</div>
                <div class="stat-value"><?php echo $stats['total_capacity'] ?? 0; ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Giá trung bình</div>
                <div class="stat-value"><?php echo number_format($stats['avg_price'] ?? 0); ?> VND</div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Search Box -->
        <div class="search-box">
            <h3>🔍 Tìm kiếm phòng</h3>
            <form method="GET" class="search-form">
                <input type="hidden" name="page" value="rooms">
                <div class="form-group">
                    <label>Số phòng</label>
                    <input type="text" name="room_number" class="form-control" placeholder="VD: 101">
                </div>
                <div class="form-group">
                    <label>Loại phòng</label>
                    <select name="room_type" class="form-control">
                        <option value="">Tất cả</option>
                        <?php foreach ($roomTypes as $type): ?>
                            <option value="<?php echo htmlspecialchars($type); ?>"><?php echo htmlspecialchars($type); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Giá từ</label>
                    <input type="number" name="min_price" class="form-control" placeholder="0" value="0">
                </div>
                <div class="form-group">
                    <label>Đến</label>
                    <input type="number" name="max_price" class="form-control" placeholder="10000000" value="10000000">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">🔍 Tìm kiếm</button>
                    <a href="?page=rooms" class="btn btn-secondary">🔄 Làm mới</a>
                </div>
            </form>
        </div>
        
        <!-- Rooms Table -->
        <div class="rooms-table">
            <h3>📋 Danh sách phòng</h3>
            
            <?php if (!empty($rooms)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Số phòng</th>
                            <th>Tầng</th>
                            <th>Loại phòng</th>
                            <th>Loại giường</th>
                            <th>Số giường</th>
                            <th>Số khách</th>
                            <th>Giá cơ bản</th>
                            <th>Diện tích</th>
                            <th>View</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rooms as $room): ?>
                        <tr>
                            <td>#<?php echo htmlspecialchars($room['room_id'] ?? ''); ?></td>
                            <td class="room-number"><?php echo htmlspecialchars($room['room_number'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($room['floor_number'] ?? ''); ?> (<?php echo htmlspecialchars($room['floor_code'] ?? ''); ?>)</td>
                            <td>
                                <span class="room-type room-type-<?php echo strtolower(htmlspecialchars($room['room_type'] ?? '')); ?>">
                                    <?php echo htmlspecialchars($room['room_type'] ?? ''); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($room['bed_type'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($room['bed_count'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($room['max_guests'] ?? ''); ?></td>
                            <td class="price"><?php echo number_format($room['base_price'] ?? 0); ?> VND</td>
                            <td><?php echo htmlspecialchars($room['room_size'] ?? ''); ?> m²</td>
                            <td><?php echo htmlspecialchars($room['view_type'] ?? ''); ?></td>
                            <td class="actions">
                                <a href="?page=rooms&action=view&id=<?php echo $room['room_id']; ?>" class="btn-action btn-view">👁️ Xem</a>
                                <a href="?page=rooms&action=edit&id=<?php echo $room['room_id']; ?>" class="btn-action btn-edit">✏️ Sửa</a>
                                <a href="?page=rooms&action=delete&id=<?php echo $room['room_id']; ?>" class="btn-action btn-delete">🗑️ Xóa</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon">🛏️</div>
                    <h3>Không có phòng nào</h3>
                    <p>Chưa có dữ liệu phòng trong hệ thống.</p>
                    <a href="?page=rooms&action=add" class="btn btn-primary">➕ Thêm phòng đầu tiên</a>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <div class="pagination">
            <a href="#" class="page-link">«</a>
            <a href="#" class="page-link active">1</a>
            <a href="#" class="page-link">2</a>
            <a href="#" class="page-link">3</a>
            <a href="#" class="page-link">»</a>
        </div>
    </div>
    
    <script>
        // Xác nhận xóa
        document.querySelectorAll('.btn-delete').forEach(button => {
            button.addEventListener('click', function(e) {
                if (!confirm('Bạn có chắc chắn muốn xóa phòng này?')) {
                    e.preventDefault();
                }
            });
        });
        
        // Tìm kiếm real-time
        const searchForm = document.querySelector('.search-form');
        const inputs = searchForm.querySelectorAll('input, select');
        
        inputs.forEach(input => {
            input.addEventListener('change', function() {
                // Có thể thêm tìm kiếm AJAX ở đây
            });
        });
    </script>
</body>
</html>