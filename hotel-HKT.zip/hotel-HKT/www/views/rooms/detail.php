<?php
// views/rooms/detail.php
$page_title = 'Chi tiết phòng';

// Get room ID from URL
$room_id = $_GET['id'] ?? $_POST['room_id'] ?? '';

if (!$room_id) {
    header('Location: ' . BASE_URL . '/rooms');
    exit;
}

// Load room model
require_once 'models/Room.php';
$roomModel = new Room();
$room = $roomModel->getById($room_id);

if (!$room) {
    echo '<div class="alert alert-danger">Không tìm thấy phòng.</div>';
    echo '<a href="' . BASE_URL . '/rooms" class="btn btn-primary">Quay lại</a>';
    return;
}

// Get status info
function getStatusInfo($status) {
    switch($status) {
        case 'available':
            return ['text' => 'Còn trống', 'class' => 'success', 'color' => '#28a745'];
        case 'occupied':
            return ['text' => 'Đã thuê', 'class' => 'danger', 'color' => '#dc3545'];
        case 'reserved':
            return ['text' => 'Đã đặt', 'class' => 'warning', 'color' => '#ffc107'];
        case 'maintenance':
            return ['text' => 'Bảo trì', 'class' => 'secondary', 'color' => '#6c757d'];
        default:
            return ['text' => $status, 'class' => 'info', 'color' => '#17a2b8'];
    }
}

$status_info = getStatusInfo($room['status']);
?>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">
                        <i class="fas fa-door-open"></i> Phòng <?php echo $room['room_number']; ?>
                    </h4>
                    <span class="badge bg-<?php echo $status_info['class']; ?> fs-6">
                        <?php echo $status_info['text']; ?>
                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h5>Thông tin cơ bản</h5>
                        <table class="table table-sm">
                            <tr>
                                <th width="40%">Mã phòng:</th>
                                <td><?php echo $room['room_id']; ?></td>
                            </tr>
                            <tr>
                                <th>Tầng:</th>
                                <td><?php echo $room['floor_code'] . ' (Tầng ' . $room['floor_number'] . ')'; ?></td>
                            </tr>
                            <tr>
                                <th>Loại phòng:</th>
                                <td><span class="badge bg-info"><?php echo $room['room_type']; ?></span></td>
                            </tr>
                            <tr>
                                <th>Loại giường:</th>
                                <td><i class="fas fa-bed"></i> <?php echo $room['bed_type']; ?></td>
                            </tr>
                            <tr>
                                <th>Sức chứa:</th>
                                <td><i class="fas fa-user-friends"></i> <?php echo $room['max_guests'] ?? 2; ?> người</td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="col-md-6">
                        <h5>Thông tin giá & dịch vụ</h5>
                        <table class="table table-sm">
                            <tr>
                                <th width="40%">Giá/đêm:</th>
                                <td class="text-primary fw-bold">
                                    <?php echo number_format($room['price_per_night'], 0, ',', '.'); ?> VND
                                </td>
                            </tr>
                            <tr>
                                <th>Diện tích:</th>
                                <td><?php echo $room['room_size'] ?? '25'; ?> m²</td>
                            </tr>
                            <tr>
                                <th>View:</th>
                                <td><i class="fas fa-mountain"></i> <?php echo $room['view_type'] ?? 'City View'; ?></td>
                            </tr>
                            <tr>
                                <th>Ban công:</th>
                                <td>
                                    <?php if ($room['balcony'] ?? false): ?>
                                        <span class="badge bg-success">Có</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Không</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Hút thuốc:</th>
                                <td>
                                    <?php if ($room['smoking_allowed'] ?? false): ?>
                                        <span class="badge bg-warning">Cho phép</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Không cho phép</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                
                <?php if (!empty($room['description'])): ?>
                <div class="mt-3">
                    <h5>Mô tả phòng</h5>
                    <div class="alert alert-light">
                        <?php echo nl2br(htmlspecialchars($room['description'])); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="card-footer">
                <div class="d-flex justify-content-between">
                    <a href="<?php echo BASE_URL; ?>/rooms" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Quay lại
                    </a>
                    
                    <?php if ($room['status'] === 'available'): ?>
                    <a href="<?php echo BASE_URL; ?>/bookings/create?room_id=<?php echo $room['room_id']; ?>" 
                       class="btn btn-success">
                        <i class="fas fa-calendar-check"></i> Đặt phòng ngay
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <!-- Status Actions -->
        <div class="card mb-3">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-cogs"></i> Thay đổi trạng thái</h5>
            </div>
            <div class="card-body">
                <form id="statusForm" method="POST" action="<?php echo BASE_URL; ?>/api/rooms.php">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="room_id" value="<?php echo $room['room_id']; ?>">
                    
                    <div class="mb-3">
                        <label class="form-label">Chọn trạng thái mới:</label>
                        <select name="status" class="form-select" required>
                            <option value="available" <?php echo $room['status'] === 'available' ? 'selected' : ''; ?>>Còn trống</option>
                            <option value="occupied" <?php echo $room['status'] === 'occupied' ? 'selected' : ''; ?>>Đã thuê</option>
                            <option value="reserved" <?php echo $room['status'] === 'reserved' ? 'selected' : ''; ?>>Đã đặt</option>
                            <option value="maintenance" <?php echo $room['status'] === 'maintenance' ? 'selected' : ''; ?>>Bảo trì</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Ghi chú (nếu có):</label>
                        <textarea name="notes" class="form-control" rows="2" placeholder="Lý do thay đổi trạng thái..."></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-save"></i> Cập nhật trạng thái
                    </button>
                </form>
            </div>
        </div>
        
        <!-- Quick Stats -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-chart-bar"></i> Thống kê nhanh</h5>
            </div>
            <div class="card-body">
                <div class="list-group">
                    <div class="list-group-item d-flex justify-content-between">
                        <span>Giá trung bình:</span>
                        <strong>800,000 VND</strong>
                    </div>
                    <div class="list-group-item d-flex justify-content-between">
                        <span>Tỷ lệ lấp đầy:</span>
                        <strong>85%</strong>
                    </div>
                    <div class="list-group-item d-flex justify-content-between">
                        <span>Doanh thu tháng:</span>
                        <strong>25,000,000 VND</strong>
                    </div>
                    <div class="list-group-item d-flex justify-content-between">
                        <span>Đánh giá:</span>
                        <strong>4.5/5 <i class="fas fa-star text-warning"></i></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Handle status form submission
document.getElementById('statusForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch(this.action, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Cập nhật trạng thái thành công!');
            location.reload();
        } else {
            alert('Lỗi: ' + (data.message || 'Không thể cập nhật'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Lỗi kết nối server');
    });
});
</script>