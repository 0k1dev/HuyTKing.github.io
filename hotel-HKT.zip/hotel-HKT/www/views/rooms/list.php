<?php
// views/rooms/list.php
if (!defined('BASE_URL')) {
    define('BASE_URL', 'http://' . $_SERVER['HTTP_HOST'] . '/hotel-HKT');
}

// Kết nối database
require_once(__DIR__ . '/../../config/database.php');

try {
    // Lấy tất cả phòng từ database
    $stmt = $pdo->query("SELECT * FROM rooms ORDER BY room_number");
    $rooms = $stmt->fetchAll();
    
    // Debug: kiểm tra dữ liệu
    // echo '<pre>';
    // print_r($rooms);
    // echo '</pre>';
    
} catch (PDOException $e) {
    // Nếu lỗi, hiển thị lỗi và dùng mock data
    echo '<div class="alert alert-danger mb-3">';
    echo '❌ Lỗi database: ' . $e->getMessage();
    echo '<br>Dùng dữ liệu mẫu để tiếp tục.';
    echo '</div>';
    
    // Mock data fallback
    $rooms = getMockRooms();
}

// Hàm fallback nếu không có database
function getMockRooms() {
    return [
        [
            'room_id' => 'R001',
            'room_number' => '101',
            'floor_number' => 1,
            'floor_code' => 'A',
            'room_type' => 'Standard',
            'bed_type' => 'Double Bed',
            'bed_count' => 1,
            'max_guests' => 2,
            'base_price' => 500000,
            'room_size' => 25,
            'view_type' => 'City View',
            'balcony' => 0,
            'smoking_allowed' => 0,
            'status' => 'available',
            'created_at' => '2024-01-01 10:00:00'
        ],
        [
            'room_id' => 'R002',
            'room_number' => '102',
            'floor_number' => 1,
            'floor_code' => 'A',
            'room_type' => 'Standard',
            'bed_type' => 'Twin Beds',
            'bed_count' => 2,
            'max_guests' => 2,
            'base_price' => 550000,
            'room_size' => 28,
            'view_type' => 'Garden View',
            'balcony' => 1,
            'smoking_allowed' => 0,
            'status' => 'available',
            'created_at' => '2024-01-01 10:00:00'
        ]
    ];
}

// Hàm helper
function formatCurrency($amount) {
    return number_format($amount, 0, ',', '.') . ' ₫';
}

function getStatusInfo($status) {
    $statusMap = [
        'available' => ['Còn trống', 'success', '#28a745'],
        'occupied' => ['Đã thuê', 'danger', '#dc3545'],
        'reserved' => ['Đã đặt', 'warning', '#ffc107'],
        'maintenance' => ['Bảo trì', 'secondary', '#6c757d'],
        'cleaning' => ['Đang dọn', 'info', '#17a2b8'],
        'out_of_order' => ['Hỏng', 'dark', '#212529']
    ];
    
    return $statusMap[$status] ?? [$status, 'info', '#17a2b8'];
}

function getRoomTypeColor($type) {
    $colors = [
        'Budget' => '#6c757d',
        'Standard' => '#0d6efd',
        'Superior' => '#198754',
        'Deluxe' => '#fd7e14',
        'Executive' => '#6f42c1',
        'Suite' => '#dc3545',
        'Presidential' => '#d63384',
        'Family' => '#20c997',
        'Honeymoon' => '#ff6b6b',
        'Business' => '#495057'
    ];
    return $colors[$type] ?? '#6c757d';
}

// Xử lý giá trị boolean từ database
function formatBoolean($value, $trueText = 'Có', $falseText = 'Không') {
    return $value == 1 ? $trueText : $falseText;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Phòng - Hotel HKT</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 20px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .header-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-left: 5px solid #0d6efd;
        }
        .room-card {
            transition: transform 0.2s, box-shadow 0.2s;
            border-radius: 12px;
            overflow: hidden;
            height: 100%;
            border: 1px solid #e9ecef;
        }
        .room-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        .status-badge {
            font-size: 0.8rem;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: 500;
        }
        .feature-icon {
            width: 32px;
            text-align: center;
            color: #6c757d;
        }
        .room-type-badge {
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        .database-info {
            background: #e7f3ff;
            border-left: 4px solid #0d6efd;
            padding: 12px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-size: 0.9rem;
        }
        .price-display {
            font-size: 1.5rem;
            font-weight: 700;
            color: #198754;
        }
        .book-button {
            min-width: 120px;
        }
        .feature-item {
            margin-bottom: 8px;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Database Info -->
        <div class="database-info">
            <i class="fas fa-database text-primary"></i>
            <strong>Database:</strong> hotel_huytking 
            <span class="badge bg-primary ms-2">
                <?php echo count($rooms); ?> phòng
            </span>
            <?php if (isset($pdo)): ?>
            <span class="badge bg-success ms-2">
                <i class="fas fa-check"></i> Đã kết nối
            </span>
            <?php endif; ?>
        </div>
        
        <!-- Header -->
        <div class="header-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h2 fw-bold text-primary mb-2">
                        <i class="fas fa-door-open me-2"></i> Quản lý Phòng
                    </h1>
                    <p class="text-muted mb-0">Quản lý tất cả phòng của khách sạn Hotel HKT</p>
                </div>
                <div>
                    <a href="index.php?page=home" class="btn btn-outline-primary me-2">
                        <i class="fas fa-home"></i> Trang chủ
                    </a>
                    <button class="btn btn-success" onclick="addNewRoom()">
                        <i class="fas fa-plus"></i> Thêm phòng mới
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Quick Stats -->
        <div class="row mb-4">
            <?php
            $available = array_filter($rooms, fn($r) => $r['status'] === 'available');
            $occupied = array_filter($rooms, fn($r) => $r['status'] === 'occupied');
            $reserved = array_filter($rooms, fn($r) => $r['status'] === 'reserved');
            $maintenance = array_filter($rooms, fn($r) => $r['status'] === 'maintenance');
            $totalRevenue = array_sum(array_column($rooms, 'base_price'));
            ?>
            <div class="col-md-3 mb-3">
                <div class="card border-success border-2 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Phòng trống</h6>
                                <h2 class="text-success mb-0"><?php echo count($available); ?></h2>
                                <small class="text-muted">
                                    <?php echo count($rooms) > 0 ? round(count($available) / count($rooms) * 100) : 0; ?>% tổng số
                                </small>
                            </div>
                            <div class="text-success">
                                <i class="fas fa-door-closed fa-2x opacity-75"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card border-danger border-2 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Phòng đã thuê</h6>
                                <h2 class="text-danger mb-0"><?php echo count($occupied); ?></h2>
                                <small class="text-muted">Đang sử dụng</small>
                            </div>
                            <div class="text-danger">
                                <i class="fas fa-bed fa-2x opacity-75"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card border-warning border-2 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Phòng đã đặt</h6>
                                <h2 class="text-warning mb-0"><?php echo count($reserved); ?></h2>
                                <small class="text-muted">Chờ check-in</small>
                            </div>
                            <div class="text-warning">
                                <i class="fas fa-calendar-check fa-2x opacity-75"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card border-primary border-2 h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Doanh thu/đêm</h6>
                                <h2 class="text-primary mb-0"><?php echo formatCurrency($totalRevenue); ?></h2>
                                <small class="text-muted">Theo giá niêm yết</small>
                            </div>
                            <div class="text-primary">
                                <i class="fas fa-money-bill-wave fa-2x opacity-75"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Rooms Grid -->
        <?php if (!empty($rooms)): ?>
        <div class="row g-4" id="roomsContainer">
            <?php foreach ($rooms as $room): 
                $statusInfo = getStatusInfo($room['status']);
                $typeColor = getRoomTypeColor($room['room_type']);
                
                // Xử lý giá trị
                $room_number = htmlspecialchars($room['room_number'] ?? 'N/A');
                $floor_number = htmlspecialchars($room['floor_number'] ?? '');
                $floor_code = htmlspecialchars($room['floor_code'] ?? '');
                $room_type = htmlspecialchars($room['room_type'] ?? '');
                $bed_type = htmlspecialchars($room['bed_type'] ?? '');
                $bed_count = $room['bed_count'] ?? 0;
                $max_guests = $room['max_guests'] ?? 0;
                $base_price = $room['base_price'] ?? 0;
                $room_size = $room['room_size'] ?? 0;
                $view_type = htmlspecialchars($room['view_type'] ?? '');
                $balcony = formatBoolean($room['balcony'] ?? 0);
                $smoking_allowed = formatBoolean($room['smoking_allowed'] ?? 0, 'Cho phép', 'Cấm');
                $created_at = $room['created_at'] ?? '';
                
                // Màu cho balcony và smoking
                $balcony_color = ($room['balcony'] ?? 0) == 1 ? 'text-success' : 'text-muted';
                $smoking_color = ($room['smoking_allowed'] ?? 0) == 1 ? 'text-warning' : 'text-success';
            ?>
            <div class="col-xl-4 col-lg-6 col-md-6">
                <div class="card room-card h-100" style="border-left: 5px solid <?php echo $statusInfo[2]; ?>">
                    <div class="card-body">
                        <!-- Room Header -->
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h4 class="card-title mb-0">
                                    <i class="fas fa-door-open text-primary"></i> 
                                    Phòng <?php echo $room_number; ?>
                                </h4>
                                <div class="d-flex align-items-center mt-1">
                                    <span class="room-type-badge me-2" 
                                          style="background: <?php echo $typeColor; ?>20; color: <?php echo $typeColor; ?>;">
                                        <?php echo $room_type; ?>
                                    </span>
                                    <?php if ($floor_number): ?>
                                    <small class="text-muted">
                                        <i class="fas fa-building me-1"></i>
                                        Tầng <?php echo $floor_number; ?>
                                        <?php if ($floor_code): ?>
                                        (<?php echo $floor_code; ?>)
                                        <?php endif; ?>
                                    </small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <span class="badge bg-<?php echo $statusInfo[1]; ?> status-badge">
                                <i class="fas fa-circle me-1" style="font-size: 0.6rem;"></i>
                                <?php echo $statusInfo[0]; ?>
                            </span>
                        </div>
                        
                        <!-- Room Info -->
                        <div class="mb-4">
                            <div class="row g-3">
                                <div class="col-6">
                                    <div class="feature-item">
                                        <div class="d-flex align-items-center">
                                            <div class="feature-icon">
                                                <i class="fas fa-bed"></i>
                                            </div>
                                            <div>
                                                <small class="text-muted d-block">Giường</small>
                                                <strong><?php echo $bed_type; ?></strong>
                                            </div>
                                        </div>
                                        <?php if ($bed_count > 0): ?>
                                        <small class="text-muted ms-4"><?php echo $bed_count; ?> giường</small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-6">
                                    <div class="feature-item">
                                        <div class="d-flex align-items-center">
                                            <div class="feature-icon">
                                                <i class="fas fa-users"></i>
                                            </div>
                                            <div>
                                                <small class="text-muted d-block">Sức chứa</small>
                                                <strong><?php echo $max_guests; ?> người</strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-6">
                                    <div class="feature-item">
                                        <div class="d-flex align-items-center">
                                            <div class="feature-icon">
                                                <i class="fas fa-expand-arrows-alt"></i>
                                            </div>
                                            <div>
                                                <small class="text-muted d-block">Diện tích</small>
                                                <strong><?php echo $room_size ? $room_size . ' m²' : 'N/A'; ?></strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-6">
                                    <div class="feature-item">
                                        <div class="d-flex align-items-center">
                                            <div class="feature-icon">
                                                <i class="fas fa-mountain"></i>
                                            </div>
                                            <div>
                                                <small class="text-muted d-block">View</small>
                                                <strong><?php echo $view_type ?: 'N/A'; ?></strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-6">
                                    <div class="feature-item">
                                        <div class="d-flex align-items-center">
                                            <div class="feature-icon">
                                                <i class="fas fa-umbrella-beach"></i>
                                            </div>
                                            <div>
                                                <small class="text-muted d-block">Ban công</small>
                                                <strong class="<?php echo $balcony_color; ?>">
                                                    <?php echo $balcony; ?>
                                                </strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-6">
                                    <div class="feature-item">
                                        <div class="d-flex align-items-center">
                                            <div class="feature-icon">
                                                <i class="fas fa-smoking"></i>
                                            </div>
                                            <div>
                                                <small class="text-muted d-block">Hút thuốc</small>
                                                <strong class="<?php echo $smoking_color; ?>">
                                                    <?php echo $smoking_allowed; ?>
                                                </strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Price & Actions -->
                        <div class="border-top pt-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <small class="text-muted d-block">Giá/đêm</small>
                                    <div class="price-display">
                                        <?php echo formatCurrency($base_price); ?>
                                    </div>
                                </div>
                                <div class="btn-group">
                                    <?php if ($room['status'] === 'available'): ?>
                                    <a href="index.php?page=bookings/create&room_id=<?php echo urlencode($room['room_number']); ?>" 
                                       class="btn btn-success book-button">
                                        <i class="fas fa-calendar-check me-1"></i> Đặt ngay
                                    </a>
                                    <?php else: ?>
                                    <button class="btn btn-outline-secondary book-button" disabled>
                                        <i class="fas fa-ban me-1"></i> Không khả dụng
                                    </button>
                                    <?php endif; ?>
                                    <button class="btn btn-outline-primary" 
                                            onclick="viewRoomDetail('<?php echo htmlspecialchars($room['room_id']); ?>')">
                                        <i class="fas fa-info-circle"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Footer -->
                    <?php if ($created_at): ?>
                    <div class="card-footer bg-light py-2">
                        <small class="text-muted">
                            <i class="far fa-clock me-1"></i> 
                            Tạo: <?php echo date('d/m/Y', strtotime($created_at)); ?>
                        </small>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <!-- Empty State -->
        <div class="text-center py-5">
            <div class="py-5">
                <i class="fas fa-door-closed fa-4x text-muted mb-4"></i>
                <h3 class="text-muted mb-3">Không có phòng nào trong database</h3>
                <p class="text-muted mb-4">Hãy thêm dữ liệu vào bảng rooms của database</p>
                <button class="btn btn-primary btn-lg" onclick="addSampleData()">
                    <i class="fas fa-database me-2"></i> Thêm dữ liệu mẫu
                </button>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Debug Section (tạm thời) -->
        <div class="mt-4 text-center">
            <div class="alert alert-info">
                <h6>Test Links:</h6>
                <div class="btn-group">
                    <a href="index.php?page=bookings/create&room_id=101" class="btn btn-sm btn-outline-primary">
                        Test: Đặt phòng 101
                    </a>
                    <a href="index.php?page=bookings/create&room_id=102" class="btn btn-sm btn-outline-primary">
                        Test: Đặt phòng 102
                    </a>
                    <a href="index.php?page=bookings/create&room_id=201" class="btn btn-sm btn-outline-primary">
                        Test: Đặt phòng 201
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script>
        // Debug info
        console.log('Rooms page loaded successfully');
        console.log('Total rooms: <?php echo count($rooms); ?>');
        
        function viewRoomDetail(roomId) {
            alert('Xem chi tiết phòng ID: ' + roomId);
            // window.location.href = 'index.php?page=rooms/detail&id=' + roomId;
        }
        
        function addNewRoom() {
            alert('Tính năng thêm phòng mới đang được phát triển');
            // window.open('index.php?page=rooms/create', '_blank');
        }
        
        function addSampleData() {
            if (confirm('Thêm dữ liệu mẫu vào database?')) {
                fetch('api/rooms.php?action=add_sample')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('✅ Đã thêm dữ liệu mẫu thành công!');
                            location.reload();
                        } else {
                            alert('❌ Lỗi: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('❌ Lỗi kết nối');
                    });
            }
        }
        
        // Kiểm tra tất cả link đặt phòng
        document.addEventListener('DOMContentLoaded', function() {
            const bookLinks = document.querySelectorAll('a[href*="bookings/create"]');
            console.log('Found', bookLinks.length, 'booking links');
            
            bookLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    console.log('Booking link clicked:', this.href);
                });
            });
        });
    </script>
</body>
</html>