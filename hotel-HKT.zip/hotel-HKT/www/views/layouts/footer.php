    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery (Optional, nếu cần) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Font Awesome -->
    <link href="/hotel-HKT/assets/css/bootstrap.min.css" rel="stylesheet">
    <script src="/hotel-HKT/assets/js/bootstrap.bundle.min.js"></script>
    
    <!-- Chart.js (nếu cần cho biểu đồ) -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- DataTables (nếu cần bảng nâng cao) -->
    <!--
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    -->
    
    <!-- SweetAlert2 (cho dialog đẹp) -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- Moment.js (xử lý date/time) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/locale/vi.min.js"></script>
    
    <!-- Main JavaScript -->
    <script src="/hotel-HKT/assets/js/main.js"></script>
    
    <!-- Page Specific JS -->
    <?php
    // Load JavaScript file tương ứng với page hiện tại
    $current_page = $_GET['page'] ?? 'home';
    $page_js_file = "assets/js/{$current_page}.js";
    
    if (file_exists($page_js_file)) {
        echo '<script src="/hotel-HKT/' . $page_js_file . '"></script>';
    }
    ?>
    
    <!-- Custom Scripts -->
    <script>
        // Set Vietnamese locale for dates
        moment.locale('vi');
        
        // Global utility functions
        function formatPrice(price) {
            if (price === null || price === '' || isNaN(price)) {
                return '0 VND';
            }
            return new Intl.NumberFormat('vi-VN').format(parseFloat(price)) + ' VND';
        }
        
        function formatDate(dateString, format = 'DD/MM/YYYY') {
            if (!dateString) return '';
            return moment(dateString).format(format);
        }
        
        function formatDateTime(dateTimeString, format = 'DD/MM/YYYY HH:mm') {
            if (!dateTimeString) return '';
            return moment(dateTimeString).format(format);
        }
        
        // Show toast notification
        function showToast(message, type = 'info') {
            const toast = document.createElement('div');
            toast.className = `toast align-items-center text-white bg-${type} border-0`;
            toast.setAttribute('role', 'alert');
            toast.setAttribute('aria-live', 'assertive');
            toast.setAttribute('aria-atomic', 'true');
            
            toast.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">
                        ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            `;
            
            const toastContainer = document.getElementById('toastContainer') || createToastContainer();
            toastContainer.appendChild(toast);
            
            const bsToast = new bootstrap.Toast(toast, {
                autohide: true,
                delay: 3000
            });
            
            bsToast.show();
            
            // Remove toast after hiding
            toast.addEventListener('hidden.bs.toast', function () {
                toast.remove();
            });
        }
        
        function createToastContainer() {
            const container = document.createElement('div');
            container.id = 'toastContainer';
            container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            container.style.zIndex = '9999';
            document.body.appendChild(container);
            return container;
        }
        
        // Confirm dialog với SweetAlert2
        function confirmDialog(title, text, confirmButtonText = 'Xác nhận', cancelButtonText = 'Hủy') {
            return Swal.fire({
                title: title,
                text: text,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: confirmButtonText,
                cancelButtonText: cancelButtonText,
                reverseButtons: true
            });
        }
        
        // Toggle loading state
        function setLoading(element, isLoading) {
            if (isLoading) {
                const originalText = element.innerHTML;
                element.setAttribute('data-original-text', originalText);
                element.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...';
                element.disabled = true;
            } else {
                const originalText = element.getAttribute('data-original-text');
                if (originalText) {
                    element.innerHTML = originalText;
                }
                element.disabled = false;
            }
        }
        
        // Validate email
        function isValidEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
        
        // Validate phone
        function isValidPhone(phone) {
            const re = /^(0|\+84)[3|5|7|8|9][0-9]{8}$/;
            return re.test(phone);
        }
        
        // Copy to clipboard
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                showToast('Đã sao chép vào clipboard', 'success');
            }).catch(err => {
                console.error('Failed to copy: ', err);
                showToast('Sao chép thất bại', 'error');
            });
        }
        
        // Debounce function
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
        
        // Initialize tooltips on page load
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Bootstrap tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
            
            // Initialize Bootstrap popovers
            var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
            var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
                return new bootstrap.Popover(popoverTriggerEl);
            });
            
            // Auto-dismiss alerts after 5 seconds
            setTimeout(() => {
                const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
                alerts.forEach(alert => {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                });
            }, 5000);
            
            // Add active class to current nav item
            const currentPage = '<?php echo $current_page; ?>';
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                const href = link.getAttribute('href');
                if (href && href.includes(`page=${currentPage}`)) {
                    link.classList.add('active');
                } else if (currentPage === 'home' && (href === 'index.php' || href === '/' || href === '?page=home')) {
                    link.classList.add('active');
                }
            });
            
            // Prevent form resubmission on page refresh
            if (window.history.replaceState) {
                window.history.replaceState(null, null, window.location.href);
            }
        });
        
        // Handle AJAX errors globally
        window.addEventListener('unhandledrejection', function(event) {
            console.error('Unhandled promise rejection:', event.reason);
            showToast('Có lỗi xảy ra. Vui lòng thử lại.', 'error');
        });
    </script>
    
    <!-- Footer Content -->
    <footer class="footer mt-auto py-3 bg-light border-top">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <span class="text-muted">
                        &copy; <?php echo date('Y'); ?> Hotel Huytking. All rights reserved.
                    </span>
                </div>
                <div class="col-md-6 text-end">
                    <span class="text-muted">
                        Version 1.0.0 | 
                        <a href="?page=about" class="text-decoration-none">About</a> | 
                        <a href="?page=privacy" class="text-decoration-none">Privacy</a> | 
                        <a href="?page=terms" class="text-decoration-none">Terms</a>
                    </span>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Loading Overlay -->
    <div id="globalLoading" class="loading-overlay" style="display: none;">
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    
    <style>
        /* Loading overlay styles */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
        
        .loading-overlay .spinner-border {
            width: 3rem;
            height: 3rem;
        }
        
        /* Toast styles */
        .toast-container {
            z-index: 9999;
        }
        
        /* Footer styles */
        .footer {
            margin-top: auto;
        }
        
        /* Print styles */
        @media print {
            .no-print,
            .navbar,
            .footer,
            .btn,
            .action-buttons {
                display: none !important;
            }
            
            .container {
                width: 100% !important;
                max-width: 100% !important;
            }
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 10px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 5px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
    </style>
    
    <!-- Google Analytics (Optional) -->
    <!--
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-XXXXX-Y"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'UA-XXXXX-Y');
    </script>
    -->
</body>
</html>