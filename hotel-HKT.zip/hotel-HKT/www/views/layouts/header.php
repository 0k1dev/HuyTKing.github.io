<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'Hotel Management'; ?></title>
    
    <link href="/hotel-HKT/assets/css/bootstrap.min.css" rel="stylesheet">
    <script src="/hotel-HKT/assets/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom CSS -->
    <style>
        body {
            padding-top: 20px;
            background-color: #f8f9fa;
        }
        .navbar-brand {
            font-weight: bold;
        }
        .card {
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .room-card .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand" href="?page=home">
                <i class="fas fa-hotel"></i> Hotel Huytking
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="?page=home"><i class="fas fa-home"></i> Trang chủ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="?page=rooms"><i class="fas fa-bed"></i> Phòng</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="?page=bookings"><i class="fas fa-calendar-check"></i> Đặt phòng</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="?page=payments"><i class="fas fa-money-bill-wave"></i> Thanh toán</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="?page=guests"><i class="fas fa-users"></i> Khách hàng</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>