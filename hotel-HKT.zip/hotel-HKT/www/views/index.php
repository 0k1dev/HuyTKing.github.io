<?php
// views/index.php - Trang chủ đơn giản
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Huytking - Trang chủ</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
        }
        .menu {
            display: flex;
            gap: 15px;
            margin: 20px 0;
            flex-wrap: wrap;
        }
        .menu a {
            display: inline-block;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .menu a:hover {
            background: #0056b3;
        }
        .status {
            padding: 20px;
            background: #28a745;
            color: white;
            border-radius: 5px;
            margin: 20px 0;
        }
        .debug {
            background: #f8f9fa;
            padding: 15px;
            border-left: 4px solid #dc3545;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🏨 Hotel Huytking Management System</h1>
        
        <div class="status">
            ✅ <strong>Trang chủ đang hoạt động!</strong>
            <p>Chào mừng bạn đến với hệ thống quản lý khách sạn Hotel Huytking</p>
        </div>
        
        <!-- Comment toàn bộ -->
<!-- 
<div class="debug">
    <strong>Thông tin kỹ thuật:</strong><br>
    PHP Version: <?php echo phpversion(); ?><br>
    Current Directory: <?php echo __DIR__; ?><br>
    Request URI: <?php echo $_SERVER['REQUEST_URI']; ?>
</div> 
-->

        <h2>📋 Menu hệ thống</h2>
        <div class="menu">
            <a href="<?php echo BASE_URL; ?>">Trang chủ</a>
            <a href="<?php echo BASE_URL; ?>/?page=rooms">Quản lý phòng</a>
            <a href="<?php echo BASE_URL; ?>/?page=bookings">Quản lý đặt phòng</a>
            <a href="<?php echo BASE_URL; ?>/?page=payments/qr">Tạo mã QR</a>
            <a href="<?php echo BASE_URL; ?>/?page=payments/history">Lịch sử thanh toán</a>
            <a href="<?php echo BASE_URL; ?>/api/rooms.php?action=get_rooms">API Rooms</a>
        </div>
        <!--
        <h2>🚀 Quick Start</h2>
        <p>Để bắt đầu sử dụng hệ thống:</p>
        <ol>
            <li>Truy cập <strong>Quản lý phòng</strong> để xem danh sách phòng</li>
            <li>Truy cập <strong>Tạo mã QR</strong> để tạo mã thanh toán</li>
            <li>Truy cập <strong>Lịch sử thanh toán</strong> để xem giao dịch</li>
        </ol>
        
        <h2>🔧 Kiểm tra hệ thống</h2>
        <ul>
            <li>✅ Front controller đang chạy</li>
            <li>✅ Routing hoạt động</li>
            <li>✅ Có thể truy cập trang chủ</li>
            <li>📊 Cần tạo database để có dữ liệu thật</li>
        </ul>
    -->
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
            <p><strong>Version:</strong> 6.0 | <strong>Hotel:</strong> Huytking | <strong>Developer:</strong> HuyTKing</p>
        </div>
    </div>
</body>
</html>