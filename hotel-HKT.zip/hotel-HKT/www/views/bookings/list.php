<?php
// views/bookings/list.php
// HOÀN TOÀN MỚI - XÓA FILE CŨ VÀ TẠO FILE NÀY

// ============================================
// PHẦN 1: XỬ LÝ KẾT NỐI DATABASE - SỬA ĐƯỜNG DẪN
// ============================================

// CÁCH ĐƠN GIẢN NHẤT: Dùng DOCUMENT_ROOT
$configFile = $_SERVER['DOCUMENT_ROOT'] . '/hotel-HKT/config/database.php';

// Debug: Xem đường dẫn
// echo "DEBUG PATH INFO:\n";
// echo "__DIR__: " . __DIR__ . "\n";
// echo "DOCUMENT_ROOT: " . $_SERVER['DOCUMENT_ROOT'] . "\n";
// echo "Config file path: " . $configFile . "\n";
// echo "File exists: " . ($configExists ? 'YES' : 'NO') . "\n";

// Kiểm tra file tồn tại
if (!file_exists($configFile)) {
    // Thử đường dẫn khác
    $configFile2 = __DIR__ . '/../../config/database.php';
    echo 'Trying alternative path: ' . $configFile2 . '<br>';
    echo 'Exists: ' . (file_exists($configFile2) ? 'YES' : 'NO') . '<br>';
    
    if (file_exists($configFile2)) {
        $configFile = $configFile2;
    } else {
        // Thử đường dẫn thứ 3
        $configFile3 = 'C:/xampp/htdocs/hotel-HKT/config/database.php';
        echo 'Trying third path: ' . $configFile3 . '<br>';
        echo 'Exists: ' . (file_exists($configFile3) ? 'YES' : 'NO') . '<br>';
        
        if (file_exists($configFile3)) {
            $configFile = $configFile3;
        }
    }
}

echo '</div>';

// Include file config
if (file_exists($configFile)) {
    require_once $configFile;
    
    if (isset($pdo) && $pdo !== null) {
        echo '<div style="background:#d4edda; padding:10px; margin:10px;">
              ✅ Kết nối database thành công!
              </div>';
    } else {
        echo '<div style="background:#f8d7da; padding:10px; margin:10px;">
              ❌ Biến $pdo không tồn tại sau khi require
              </div>';
        $pdo = null;
    }
} else {
    echo '<div style="background:#f8d7da; padding:15px; margin:10px;">
          ❌ KHÔNG TÌM THẤY FILE database.php<br>
          Tìm kiếm tại: ' . $configFile . '
          </div>';
    
    // THỬ KẾT NỐI TRỰC TIẾP TRONG FILE
    echo '<div style="background:#fff3cd; padding:15px; margin:10px;">
          <strong>Thử kết nối trực tiếp...</strong>
          </div>';
    
    try {
        $host = '127.0.0.1';
        $dbname = 'hotel_huytking';
        $username = 'root';
        $password = '';
        
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        echo '<div style="background:#d4edda; padding:10px; margin:10px;">
              ✅ Kết nối trực tiếp thành công!
              </div>';
              
    } catch (PDOException $e) {
        echo '<div style="background:#f8d7da; padding:15px; margin:10px;">
              ❌ Lỗi kết nối trực tiếp: ' . $e->getMessage() . '
              </div>';
        $pdo = null;
    }
}

// ============================================
// PHẦN 2: LẤY DỮ LIỆU TỪ DATABASE
// ============================================

$bookings = [];

if ($pdo !== null) {
    try {
        // Lấy tất cả bookings từ database
        $query = "SELECT * FROM bookings ORDER BY created_at DESC";
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo '<div style="background:#cce5ff; padding:10px; margin:10px;">
              📊 Tìm thấy: ' . count($bookings) . ' bookings trong hệ thống
              </div>';
        
    } catch (PDOException $e) {
        echo '<div style="background:#f8d7da; padding:10px; margin:10px;">
              ❌ Lỗi khi lấy dữ liệu: ' . $e->getMessage() . '
              </div>';
    }
} else {
    echo '<div style="background:#f8d7da; padding:10px; margin:10px;">
          ❌ Không thể lấy dữ liệu vì không có kết nối database
          </div>';
}

// ============================================
// PHẦN 3: HÀM HELPER ĐỂ XỬ LÝ AN TOÀN
// ============================================

/**
 * Hàm hiển thị an toàn, tránh lỗi null
 * @param mixed $value Giá trị cần hiển thị
 * @param string $default Giá trị mặc định nếu null/trống
 * @return string
 */
function safeDisplay($value, $default = '') {
    if ($value === null || $value === '') {
        return htmlspecialchars($default);
    }
    return htmlspecialchars($value);
}

/**
 * Hàm format ngày
 * @param string $date Chuỗi ngày
 * @param string $format Định dạng
 * @return string
 */
function formatDateDisplay($date, $format = 'd/m/Y') {
    if (empty($date) || $date === '0000-00-00' || $date === null) {
        return '<span class="text-muted">Chưa có</span>';
    }
    
    try {
        $dateTime = new DateTime($date);
        return $dateTime->format($format);
    } catch (Exception $e) {
        return '<span class="text-muted">Ngày lỗi</span>';
    }
}

// ============================================
// PHẦN 4: HIỂN THỊ GIAO DIỆN
// ============================================
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Đặt phòng - Hotel HKT</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
        .status-badge { font-size: 0.8em; }
        .table-hover tbody tr:hover { background-color: rgba(0,123,255,0.1); }
    </style>
</head>
<body>
    <div class="header py-4 mb-4">
        <div class="container">
            <h1><i class="fas fa-calendar-check"></i> Quản lý Đặt phòng</h1>
            <p class="lead mb-0">Hotel HuyTKing - Quản lý đặt phòng trực tuyến</p>
        </div>
    </div>

    <div class="container">
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-list"></i> Danh sách đặt phòng</h5>
                        <a href="?page=bookings/create" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Đặt phòng mới
                        </a>
                    </div>
                    
                    <?php if (count($bookings) > 0): ?>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th width="50">#ID</th>
                                        <th>Khách hàng</th>
                                        <th>Phòng</th>
                                        <th>Ngày nhận</th>
                                        <th>Ngày trả</th>
                                        <th>Trạng thái</th>
                                        <th width="120">Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($bookings as $booking): ?>
                                    <tr>
                                        <td><strong>#<?php echo $booking['booking_id'] ?? 'N/A'; ?></strong></td>
                                        <td>
                                            <div><strong><?php echo safeDisplay($booking['customer_name'], 'Không có tên'); ?></strong></div>
                                            <small class="text-muted">
                                                <i class="fas fa-envelope"></i> <?php echo safeDisplay($booking['customer_email'], 'Chưa có email'); ?><br>
                                                <i class="fas fa-phone"></i> <?php echo safeDisplay($booking['customer_phone'], 'Chưa có SĐT'); ?>
                                            </small>
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary"><?php echo safeDisplay($booking['room_id'], 'N/A'); ?></span>
                                        </td>
                                        <td>
                                            <i class="fas fa-calendar-day text-primary"></i> 
                                            <?php echo formatDateDisplay($booking['check_in_date']); ?>
                                        </td>
                                        <td>
                                            <i class="fas fa-calendar-check text-success"></i> 
                                            <?php echo formatDateDisplay($booking['check_out_date']); ?>
                                        </td>
                                        <td>
                                            <?php
                                            $status = $booking['status'] ?? 'unknown';
                                            $statusConfig = [
                                                'confirmed' => ['label' => 'Đã xác nhận', 'class' => 'warning'],
                                                'checked_in' => ['label' => 'Đã nhận phòng', 'class' => 'success'],
                                                'checked_out' => ['label' => 'Đã trả phòng', 'class' => 'info'],
                                                'cancelled' => ['label' => 'Đã hủy', 'class' => 'danger']
                                            ];
                                            
                                            $config = $statusConfig[$status] ?? ['label' => 'Không xác định', 'class' => 'secondary'];
                                            ?>
                                            <span class="badge bg-<?php echo $config['class']; ?>">
                                                <?php echo $config['label']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                    <!-- NÚT CHÍNH -->
                                                <a href="?page=payments/qr&booking_id=<?php echo $booking['booking_id']; ?>" 
                                                    class="btn btn-outline-success" title="Thanh toán QR">
                                                    <i class="fas fa-qrcode"></i>
                                                </a>
                                                    
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="card-body text-center py-5">
                        <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">Không có đặt phòng nào</h4>
                        <p class="text-muted">Bạn chưa có đặt phòng nào trong hệ thống</p>
                        <a href="?page=bookings/create" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Tạo đặt phòng đầu tiên
                        </a>
                    </div>
                    <?php endif; ?>
                    
                    <div class="card-footer bg-white">
                        <div class="row">
                            <div class="col-md-6">
                                <small class="text-muted">
                                    <i class="fas fa-info-circle"></i> Tổng cộng: <?php echo count($bookings); ?> đặt phòng
                                </small>
                            </div>
                            <div class="col-md-6 text-end">
                                <a href="?page=home" class="btn btn-outline-secondary btn-sm">
                                    <i class="fas fa-home"></i> Về trang chủ
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Thêm hiệu ứng cho table
        document.addEventListener('DOMContentLoaded', function() {
            const rows = document.querySelectorAll('tbody tr');
            rows.forEach(row => {
                row.addEventListener('click', function() {
                    rows.forEach(r => r.classList.remove('table-active'));
                    this.classList.add('table-active');
                });
            });
        });
    </script>
</body>
</html>