<?php
// views/bookings/checkin.php

// Kiểm tra session đã start chưa
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kết nối database
$configFile = $_SERVER['DOCUMENT_ROOT'] . '/hotel-HKT/config/database.php';
if (!file_exists($configFile)) {
    $configFile = __DIR__ . '/../../config/database.php';
}
require_once $configFile;

$booking_id = $_GET['booking_id'] ?? null;
$error = null;
$booking_info = null;
$room_info = null;

// ============================================
// XỬ LÝ CHECK-IN
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkin'])) {
    $booking_id = $_POST['booking_id'] ?? null;
    
    if ($booking_id) {
        try {
            // Bắt đầu transaction
            $pdo->beginTransaction();
            
            // 1. Cập nhật trạng thái booking thành 'checked_in' và thời gian check-in
            $update_booking = $pdo->prepare("
                UPDATE bookings 
                SET status = 'checked_in', 
                    check_in = NOW() 
                WHERE booking_id = ?
            ");
            $update_booking->execute([$booking_id]);
            
            // 2. Lấy room_id từ booking
            $get_room = $pdo->prepare("SELECT room_id FROM bookings WHERE booking_id = ?");
            $get_room->execute([$booking_id]);
            $room_data = $get_room->fetch();
            
            if ($room_data) {
                // 3. Cập nhật trạng thái phòng thành 'occupied'
                $update_room = $pdo->prepare("
                    UPDATE rooms 
                    SET status = 'occupied' 
                    WHERE room_id = ?
                ");
                $update_room->execute([$room_data['room_id']]);
            }
            
            $pdo->commit();
            
            $_SESSION['success'] = "✅ Check-in thành công! Khách hàng đã nhận phòng.";
            header("Location: index.php?page=bookings");
            exit;
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "❌ Lỗi khi check-in: " . $e->getMessage();
        }
    }
}

// ============================================
// LẤY THÔNG TIN BOOKING & PHÒNG
// ============================================
if ($booking_id) {
    try {
        // Lấy thông tin booking và phòng
        $stmt = $pdo->prepare("
            SELECT b.*, r.room_number, r.room_type, r.bed_type, r.floor_number, r.base_price
            FROM bookings b 
            LEFT JOIN rooms r ON b.room_id = r.room_id 
            WHERE b.booking_id = ?
        ");
        $stmt->execute([$booking_id]);
        $booking_info = $stmt->fetch();
        
        if (!$booking_info) {
            $error = "Không tìm thấy thông tin đặt phòng #$booking_id";
        } elseif ($booking_info['status'] !== 'confirmed') {
            $error = "Booking #$booking_id không ở trạng thái 'Đã xác nhận'. Trạng thái hiện tại: " . 
                    ($booking_info['status'] === 'checked_in' ? 'Đã check-in' : 'Đã check-out');
        }
    } catch (PDOException $e) {
        $error = "Lỗi database: " . $e->getMessage();
    }
} else {
    $error = "Không có booking_id được cung cấp";
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check-in Khách Hàng - Hotel HKT</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding-top: 30px;
        }
        
        .checkin-container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .checkin-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(50, 50, 93, 0.1), 0 5px 15px rgba(0, 0, 0, 0.07);
            overflow: hidden;
        }
        
        .checkin-header {
            background: linear-gradient(135deg, #0d6efd 0%, #0dcaf0 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .checkin-body {
            padding: 40px;
        }
        
        .info-section {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #e9ecef;
        }
        
        .info-row:last-child {
            border-bottom: none;
        }
        
        .info-label {
            font-weight: 600;
            color: #495057;
        }
        
        .info-value {
            color: #0d6efd;
            font-weight: 600;
        }
        
        .room-card {
            background: linear-gradient(135deg, #20c997 0%, #198754 100%);
            color: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .confirmation-box {
            background: #fff3cd;
            border-left: 5px solid #ffc107;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        
        .btn-checkin {
            background: linear-gradient(135deg, #198754 0%, #20c997 100%);
            color: white;
            border: none;
            padding: 15px 50px;
            font-size: 1.2rem;
            font-weight: 600;
            border-radius: 10px;
            transition: all 0.3s;
        }
        
        .btn-checkin:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(25, 135, 84, 0.3);
        }
        
        .status-badge {
            font-size: 0.9rem;
            padding: 8px 20px;
            border-radius: 20px;
        }
        
        @media (max-width: 768px) {
            .checkin-body {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container checkin-container">
        <div class="checkin-card">
            <!-- Header -->
            <div class="checkin-header">
                <h1 class="mb-3"><i class="fas fa-sign-in-alt me-2"></i> Check-in Khách Hàng</h1>
                <p class="lead mb-0">Xác nhận khách hàng đã đến nhận phòng</p>
            </div>
            
            <!-- Body -->
            <div class="checkin-body">
                <?php if ($error): ?>
                    <!-- Hiển thị lỗi -->
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i> <?php echo $error; ?>
                    </div>
                    <div class="text-center mt-4">
                        <a href="index.php?page=bookings" class="btn btn-primary">
                            <i class="fas fa-arrow-left me-2"></i> Quay lại danh sách booking
                        </a>
                    </div>
                
                <?php elseif ($booking_info): ?>
                    <!-- THÔNG BÁO TRẠNG THÁI -->
                    <div class="alert alert-info mb-4">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-info-circle fa-2x me-3"></i>
                            <div>
                                <h5 class="mb-1">Xác nhận check-in cho Booking #<?php echo $booking_info['booking_id']; ?></h5>
                                <p class="mb-0">Trạng thái hiện tại: 
                                    <span class="badge bg-warning">Đã xác nhận</span>
                                    → Sau check-in: 
                                    <span class="badge bg-success">Đã nhận phòng</span>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- THÔNG TIN KHÁCH HÀNG -->
                    <div class="info-section">
                        <h4 class="mb-4"><i class="fas fa-user me-2 text-primary"></i> Thông Tin Khách Hàng</h4>
                        <div class="info-row">
                            <span class="info-label">Họ tên:</span>
                            <span class="info-value"><?php echo htmlspecialchars($booking_info['customer_name']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Số điện thoại:</span>
                            <span class="info-value"><?php echo htmlspecialchars($booking_info['customer_phone']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Email:</span>
                            <span class="info-value"><?php echo htmlspecialchars($booking_info['customer_email'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Ngày đặt:</span>
                            <span class="info-value"><?php echo date('d/m/Y H:i', strtotime($booking_info['created_at'])); ?></span>
                        </div>
                    </div>
                    
                    <!-- THÔNG TIN PHÒNG -->
                    <div class="room-card">
                        <h4 class="mb-4"><i class="fas fa-door-open me-2"></i> Thông Tin Phòng</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="info-row text-white">
                                    <span>Số phòng:</span>
                                    <strong><?php echo htmlspecialchars($booking_info['room_number']); ?></strong>
                                </div>
                                <div class="info-row text-white">
                                    <span>Loại phòng:</span>
                                    <strong><?php echo htmlspecialchars($booking_info['room_type']); ?></strong>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-row text-white">
                                    <span>Loại giường:</span>
                                    <strong><?php echo htmlspecialchars($booking_info['bed_type']); ?></strong>
                                </div>
                                <div class="info-row text-white">
                                    <span>Tầng:</span>
                                    <strong><?php echo htmlspecialchars($booking_info['floor_number']); ?></strong>
                                </div>
                            </div>
                        </div>
                        <div class="info-row text-white mt-3">
                            <span>Giá phòng/đêm:</span>
                            <strong class="h5"><?php echo number_format($booking_info['base_price'], 0, ',', '.'); ?> ₫</strong>
                        </div>
                    </div>
                    
                    <!-- THÔNG TIN THỜI GIAN -->
                    <div class="info-section">
                        <h4 class="mb-4"><i class="fas fa-calendar-alt me-2 text-success"></i> Thông Tin Thời Gian</h4>
                        <div class="info-row">
                            <span class="info-label">Ngày check-in (dự kiến):</span>
                            <span class="info-value"><?php echo date('d/m/Y', strtotime($booking_info['check_in_date'])); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Ngày check-out (dự kiến):</span>
                            <span class="info-value"><?php echo date('d/m/Y', strtotime($booking_info['check_out_date'])); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Số đêm:</span>
                            <?php 
                            $check_in = new DateTime($booking_info['check_in_date']);
                            $check_out = new DateTime($booking_info['check_out_date']);
                            $nights = $check_out->diff($check_in)->days;
                            ?>
                            <span class="info-value"><?php echo $nights; ?> đêm</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Tổng tiền (dự kiến):</span>
                            <span class="info-value h5 text-success"><?php echo number_format($booking_info['base_price'] * $nights, 0, ',', '.'); ?> ₫</span>
                        </div>
                    </div>
                    
                    <!-- XÁC NHẬN CHECK-IN -->
                    <div class="confirmation-box">
                        <h4 class="mb-3"><i class="fas fa-clipboard-check me-2 text-warning"></i> Xác Nhận Check-in</h4>
                        <p class="mb-3">Sau khi xác nhận check-in:</p>
                        <ul class="mb-4">
                            <li>Trạng thái booking sẽ chuyển từ <strong>"Đã xác nhận" → "Đã nhận phòng"</strong></li>
                            <li>Phòng <strong><?php echo htmlspecialchars($booking_info['room_number']); ?></strong> sẽ chuyển sang trạng thái <strong>"Đang sử dụng"</strong></li>
                            <li>Thời gian check-in thực tế sẽ được ghi nhận</li>
                            <li>Khách hàng có thể thanh toán và check-out sau này</li>
                        </ul>
                        
                        <form method="POST" action="" onsubmit="return confirmCheckin()">
                            <input type="hidden" name="booking_id" value="<?php echo $booking_info['booking_id']; ?>">
                            <div class="text-center">
                                <button type="submit" name="checkin" value="1" class="btn btn-checkin mb-3">
                                    <i class="fas fa-check-circle me-2"></i> Xác Nhận Check-in
                                </button>
                                <p class="text-muted">
                                    <small><i class="fas fa-exclamation-triangle me-1"></i> 
                                    Vui lòng kiểm tra thông tin khách hàng và CCCD/CMND trước khi check-in</small>
                                </p>
                            </div>
                        </form>
                    </div>
                    
                    <!-- NÚT ĐIỀU KHIỂN -->
                    <div class="text-center mt-4">
                        <a href="index.php?page=bookings" class="btn btn-outline-secondary me-3">
                            <i class="fas fa-arrow-left me-2"></i> Quay lại
                        </a>
                        <button class="btn btn-outline-primary" onclick="window.print()">
                            <i class="fas fa-print me-2"></i> In thông tin
                        </button>
                    </div>
                    
                <?php endif; ?>
            </div>
        </div>
        
        <!-- THÔNG BÁO HỖ TRỢ -->
        <div class="alert alert-light border mt-4">
            <div class="d-flex align-items-center">
                <i class="fas fa-headset fa-2x me-3 text-primary"></i>
                <div>
                    <h6 class="fw-bold mb-1">Hỗ trợ check-in</h6>
                    <p class="mb-0">Nếu gặp vấn đề trong quá trình check-in, vui lòng liên hệ quản lý 
                    <strong>1900 1234</strong> hoặc đến quầy lễ tân để được hỗ trợ.</p>
                </div>
            </div>
        </div>
    </div>

    <script>
    function confirmCheckin() {
        return confirm('⚠️ XÁC NHẬN CHECK-IN\n\nBạn có chắc chắn muốn check-in cho khách hàng này?\n\nSau khi xác nhận:\n• Booking sẽ chuyển sang trạng thái "Đã nhận phòng"\n• Phòng sẽ chuyển sang trạng thái "Đang sử dụng"\n• Khách hàng có thể thanh toán và check-out sau');
    }
    
    // Hiển thị thời gian thực
    function updateCurrentTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('vi-VN', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        const dateString = now.toLocaleDateString('vi-VN', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        const timeElement = document.getElementById('current-time');
        if (timeElement) {
            timeElement.innerHTML = `<i class="fas fa-clock me-2"></i> ${dateString} - ${timeString}`;
        }
    }
    
    // Tạo element hiển thị thời gian
    const timeDisplay = document.createElement('div');
    timeDisplay.className = 'alert alert-info text-center';
    timeDisplay.id = 'current-time';
    document.querySelector('.checkin-body').prepend(timeDisplay);
    
    updateCurrentTime();
    setInterval(updateCurrentTime, 1000);
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>