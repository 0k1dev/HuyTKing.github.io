<?php
// views/bookings/create.php

// Kiểm tra xem session đã được start chưa
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kết nối database
$base_path = __DIR__ . '/../../';
require_once $base_path . 'config/database.php';

// ============================================
// PHẦN 1: XỬ LÝ FORM SUBMIT
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Lấy dữ liệu từ form
        $room_id = $_POST['room_id'] ?? '';
        $room_number = $_POST['room_number'] ?? '';
        $guest_name = $_POST['guest_name'] ?? '';
        $guest_full_name = $_POST['guest_name'] ?? ''; // Dùng chung với guest_name
        $guest_email = $_POST['guest_email'] ?? '';
        $guest_phone = $_POST['guest_phone'] ?? '';
        $guest_address = $_POST['guest_address'] ?? '';
        $guest_id_card = $_POST['guest_id_card'] ?? '';
        $check_in_date = $_POST['check_in_date'] ?? '';
        $check_out_date = $_POST['check_out_date'] ?? '';
        $num_guests = $_POST['num_guests'] ?? 1;
        $special_requests = $_POST['special_requests'] ?? '';
        $total_price = $_POST['total_price'] ?? 0;
        $num_nights = $_POST['num_nights'] ?? 1;
        
       // VALIDATION DỮ LIỆU

// 1. Kiểm tra thông tin bắt buộc
if (empty($guest_name) || empty($guest_phone) || 
    empty($check_in_date) || empty($check_out_date)) {
    $_SESSION['error'] = "Vui lòng điền đầy đủ thông tin bắt buộc!";
    header("Location: index.php?page=bookings/create&room_id=" . urlencode($room_number));
    exit;
}

// 2. Kiểm tra tên chỉ chứa ký tự chữ và dấu cách (không có ký tự đặc biệt)
$guest_name = trim($guest_name); // Xóa khoảng trắng đầu cuối
if (!preg_match('/^[A-Za-zÀ-ỹ\s]+$/u', $guest_name)) {
    $_SESSION['error'] = "Tên chỉ được chứa ký tự chữ và dấu cách!";
    header("Location: index.php?page=bookings/create&room_id=" . urlencode($room_number));
    exit;
}

$guest_phone = preg_replace('/\D/', '', $guest_phone); // Xóa tất cả ký tự không phải số
if (!preg_match('/^0[0-9]{9}$/', $guest_phone)) {
    $_SESSION['error'] = "Số điện thoại không hợp lệ! Phải là 10 số và bắt đầu bằng 0";
    header("Location: index.php?page=bookings/create&room_id=" . urlencode($room_number));
    exit;
}


if (!empty($guest_id_card)) {
    $guest_id_card = preg_replace('/\D/', '', $guest_id_card); // Xóa tất cả ký tự không phải số
    if (strlen($guest_id_card) > 12) {
        $_SESSION['error'] = "CCCD/CMND không hợp lệ! Tối đa 12 số";
        header("Location: index.php?page=bookings/create&room_id=" . urlencode($room_number));
        exit;
    }
}
// 3. Kiểm tra ngày hợp lệ
if (strtotime($check_out_date) <= strtotime($check_in_date)) {
    $_SESSION['error'] = "Ngày trả phòng phải sau ngày nhận phòng!";
    header("Location: index.php?page=bookings/create&room_id=" . urlencode($room_number));
    exit;
}
$guest_phone = formatPhoneNumber($guest_phone);
        
        // Kiểm tra phòng còn trống không
        $check_stmt = $pdo->prepare("SELECT * FROM rooms WHERE room_number = ? AND status = 'available'");
        $check_stmt->execute([$room_number]);
        $room_check = $check_stmt->fetch();
        
        if (!$room_check) {
            $_SESSION['error'] = "Phòng $room_number không còn khả dụng!";
            header("Location: index.php?page=rooms");
            exit;
        }
        
        // ============================================
        // BƯỚC 1: LƯU THÔNG TIN GUEST
        // ============================================
        
        // Kiểm tra xem guest đã tồn tại chưa (theo số điện thoại)
        $check_guest_sql = "SELECT guest_id FROM guests WHERE phone = ? OR id_card = ?";
        $check_guest_stmt = $pdo->prepare($check_guest_sql);
        $check_guest_stmt->execute([$guest_phone, $guest_id_card]);
        $existing_guest = $check_guest_stmt->fetch();
        
        $guest_id = null;
        
        if ($existing_guest) {
            // Guest đã tồn tại, sử dụng guest_id hiện có
            $guest_id = $existing_guest['guest_id'];
            
            // Cập nhật thông tin guest mới nhất
            $update_guest_sql = "UPDATE guests SET 
                                name = :name,
                                full_name = :full_name,
                                email = :email,
                                address = :address,
                                id_card = :id_card
                                WHERE guest_id = :guest_id";
            
            $update_stmt = $pdo->prepare($update_guest_sql);
            $update_stmt->execute([
                ':name' => $guest_name,
                ':full_name' => $guest_full_name,
                ':email' => $guest_email,
                ':address' => $guest_address,
                ':id_card' => $guest_id_card,
                ':guest_id' => $guest_id
            ]);
            
        } else {
            // Guest mới, thêm vào bảng guests
            $guest_sql = "INSERT INTO guests (
                name,
                full_name,
                email,
                phone,
                address,
                id_card,
                created_at
            ) VALUES (
                :name,
                :full_name,
                :email,
                :phone,
                :address,
                :id_card,
                NOW()
            )";
            
            $guest_stmt = $pdo->prepare($guest_sql);
            $guest_stmt->execute([
                ':name' => $guest_name,
                ':full_name' => $guest_full_name,
                ':email' => $guest_email,
                ':phone' => $guest_phone,
                ':address' => $guest_address,
                ':id_card' => $guest_id_card
            ]);
            
            $guest_id = $pdo->lastInsertId();
        }
        
        // ============================================
        // BƯỚC 2: LƯU THÔNG TIN BOOKING
        // ============================================
        
        $booking_sql = "INSERT INTO bookings (
            guest_id,
            room_id,
            customer_name,
            customer_email,
            customer_phone,
            check_in_date,
            check_out_date,
            status,
            created_at
        ) VALUES (
            :guest_id,
            :room_id,
            :customer_name,
            :customer_email,
            :customer_phone,
            :check_in_date,
            :check_out_date,
            :status,
            NOW()
        )";
        
        $booking_stmt = $pdo->prepare($booking_sql);
        $result = $booking_stmt->execute([
            ':guest_id' => $guest_id,
            ':room_id' => $room_id,
            ':customer_name' => $guest_name,
            ':customer_email' => $guest_email,
            ':customer_phone' => $guest_phone,
            ':check_in_date' => $check_in_date,
            ':check_out_date' => $check_out_date,
            ':status' => 'confirmed'
        ]);
        
        if ($result) {
            $booking_id = $pdo->lastInsertId();
            
            // Cập nhật trạng thái phòng thành 'occupied'
            $update_room_sql = "UPDATE rooms SET status = 'occupied' WHERE room_id = ?";
            $update_stmt = $pdo->prepare($update_room_sql);
            $update_stmt->execute([$room_id]);
            
            // Lưu thông tin chi tiết booking (nếu có bảng booking_details)
            // Nếu không có bảng này, có thể bỏ qua hoặc tạo bảng
            try {
                $detail_sql = "INSERT INTO booking_details (
                    booking_id,
                    num_guests,
                    num_nights,
                    total_price,
                    special_requests
                ) VALUES (?, ?, ?, ?, ?)";
                
                $detail_stmt = $pdo->prepare($detail_sql);
                $detail_stmt->execute([
                    $booking_id,
                    $num_guests,
                    $num_nights,
                    $total_price,
                    $special_requests
                ]);
            } catch (PDOException $e) {
                // Bảng booking_details có thể không tồn tại, không sao
                // Hoặc tạo bảng booking_details nếu cần
                // CREATE TABLE booking_details (
                //     detail_id INT AUTO_INCREMENT PRIMARY KEY,
                //     booking_id INT NOT NULL,
                //     num_guests INT DEFAULT 1,
                //     num_nights INT DEFAULT 1,
                //     total_price DECIMAL(10,2) DEFAULT 0,
                //     special_requests TEXT,
                //     FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
                // );
            }
            
            $_SESSION['success'] = "✅ Đặt phòng thành công! Mã đặt phòng: #$booking_id";
            header("Location: index.php?page=bookings");
            exit;
        } else {
            $_SESSION['error'] = "❌ Có lỗi xảy ra khi lưu đặt phòng!";
            header("Location: index.php?page=bookings/create&room_id=" . urlencode($room_number));
            exit;
        }
        
    } catch (PDOException $e) {
        $_SESSION['error'] = "❌ Lỗi database: " . $e->getMessage();
        header("Location: index.php?page=bookings/create&room_id=" . urlencode($room_number));
        exit;
    }
}

// ============================================
// PHẦN 2: HIỂN THỊ FORM (chỉ khi không phải POST)
// ============================================
$room_number = $_GET['room_id'] ?? '';
$room = null;

// Kiểm tra nếu không có room_number
if (empty($room_number)) {
    $_SESSION['error'] = "Vui lòng chọn phòng từ danh sách";
    header("Location: index.php?page=rooms");
    exit;
}

try {
    // Lấy thông tin phòng bằng room_number
    $stmt = $pdo->prepare("SELECT * FROM rooms WHERE room_number = ? AND status = 'available'");
    $stmt->execute([$room_number]);
    $room = $stmt->fetch();
    
    if (!$room) {
        $_SESSION['error'] = "Phòng $room_number không khả dụng hoặc không tồn tại";
        header("Location: index.php?page=rooms");
        exit;
    }
} catch (PDOException $e) {
    die("Lỗi database: " . $e->getMessage());
}

// Format tiền
function formatCurrency($amount) {
    return number_format($amount, 0, ',', '.') . ' ₫';
}

// Tính toán số đêm mặc định
$check_in = date('Y-m-d');
$check_out = date('Y-m-d', strtotime('+1 day'));
$num_nights = 1;
$total_price = $room['base_price'] * $num_nights;

// Hàm format số điện thoại
function formatPhoneNumber($phone) {
    $phone = preg_replace('/\D/', '', $phone); // Xóa tất cả ký tự không phải số
    
    if (strlen($phone) == 10) {
        // Format: 0912 345 678
        return substr($phone, 0, 4) . ' ' . substr($phone, 4, 3) . ' ' . substr($phone, 7, 3);
    } elseif (strlen($phone) == 11) {
        // Format: 091 2345 6789
        return substr($phone, 0, 3) . ' ' . substr($phone, 3, 4) . ' ' . substr($phone, 7, 4);
    }
    
    return $phone;
}

// Hiển thị thông báo lỗi/success nếu có
if (isset($_SESSION['error'])) {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert" style="margin: 20px;">
            <i class="fas fa-exclamation-triangle me-2"></i>' . $_SESSION['error'] . '
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
    unset($_SESSION['error']);
}

if (isset($_SESSION['success'])) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert" style="margin: 20px;">
            <i class="fas fa-check-circle me-2"></i>' . $_SESSION['success'] . '
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
    unset($_SESSION['success']);
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đặt Phòng Mới - Phòng <?php echo htmlspecialchars($room['room_number']); ?> | Hotel HKT</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #0d6efd;
            --success-color: #198754;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
        }
        
        body {
            background-color: #f8f9fa;
            padding-top: 20px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .booking-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }
        
        .header-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            border-left: 6px solid var(--primary-color);
        }
        
        .room-info-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border: 1px solid #e9ecef;
        }
        
        .form-section-card {
            background: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .price-summary-card {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 12px;
            padding: 25px;
            border: 2px solid #dee2e6;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }
        
        .section-title {
            color: var(--primary-color);
            border-bottom: 2px solid #e9ecef;
            padding-bottom: 10px;
            margin-bottom: 25px;
            font-weight: 600;
        }
        
        .required-star {
            color: var(--danger-color);
            font-weight: bold;
        }
        
        .feature-icon {
            width: 40px;
            height: 40px;
            background: var(--primary-color);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
        }
        
        .room-feature {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .total-price {
            font-size: 2rem;
            font-weight: 700;
            color: var(--success-color);
        }
        
        .btn-success {
            background: linear-gradient(135deg, var(--success-color), #157347);
            border: none;
            padding: 12px 40px;
            font-size: 1.1rem;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(25, 135, 84, 0.3);
        }
        
        .status-badge {
            font-size: 0.85rem;
            padding: 6px 20px;
            border-radius: 20px;
        }
        
        @media (max-width: 768px) {
            .booking-container {
                padding: 0 15px;
            }
            
            .header-card, .room-info-card, .form-section-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid booking-container">
        <!-- Header -->
        <div class="header-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 fw-bold text-primary mb-2">
                        <i class="fas fa-calendar-plus me-2"></i>Đặt Phòng Mới
                    </h1>
                    <p class="text-muted mb-0">
                        <i class="fas fa-door-open me-2"></i>
                        Phòng: <strong class="text-primary"><?php echo htmlspecialchars($room['room_number']); ?></strong> | 
                        Loại: <span class="badge bg-info"><?php echo htmlspecialchars($room['room_type']); ?></span>
                    </p>
                </div>
                <div>
                    <a href="index.php?page=rooms" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left me-2"></i>Quay lại
                    </a>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- Cột trái: Thông tin phòng & Form -->
            <div class="col-lg-8">
                <!-- Thông tin phòng chi tiết -->
                <div class="room-info-card">
                    <h4 class="section-title">
                        <i class="fas fa-info-circle me-2"></i>Thông Tin Phòng
                    </h4>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="room-feature">
                                <div class="feature-icon">
                                    <i class="fas fa-bed"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Loại giường</small>
                                    <strong><?php echo htmlspecialchars($room['bed_type']); ?></strong>
                                    <small class="text-muted d-block">
                                        <?php echo $room['bed_count']; ?> giường | 
                                        Tối đa <?php echo $room['max_guests']; ?> người
                                    </small>
                                </div>
                            </div>
                            
                            <div class="room-feature">
                                <div class="feature-icon">
                                    <i class="fas fa-expand-arrows-alt"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Diện tích</small>
                                    <strong><?php echo htmlspecialchars($room['room_size'] ?? 'N/A'); ?> m²</strong>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="room-feature">
                                <div class="feature-icon">
                                    <i class="fas fa-mountain"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">View</small>
                                    <strong><?php echo htmlspecialchars($room['view_type']); ?></strong>
                                </div>
                            </div>
                            
                            <div class="room-feature">
                                <div class="feature-icon">
                                    <i class="fas fa-building"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Vị trí</small>
                                    <strong>
                                        Tầng <?php echo htmlspecialchars($room['floor_number']); ?> 
                                        (<?php echo htmlspecialchars($room['floor_code']); ?>)
                                    </strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-6">
                            <div class="room-feature">
                                <div class="feature-icon" style="background: <?php echo $room['balcony'] ? 'var(--success-color)' : '#6c757d'; ?>">
                                    <i class="fas fa-umbrella-beach"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Ban công</small>
                                    <strong><?php echo $room['balcony'] ? 'Có' : 'Không'; ?></strong>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-6">
                            <div class="room-feature">
                                <div class="feature-icon" style="background: <?php echo $room['smoking_allowed'] ? 'var(--warning-color)' : 'var(--danger-color)'; ?>">
                                    <i class="fas fa-smoking"></i>
                                </div>
                                <div>
                                    <small class="text-muted d-block">Hút thuốc</small>
                                    <strong><?php echo $room['smoking_allowed'] ? 'Cho phép' : 'Cấm'; ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Form đặt phòng -->
                <div class="form-section-card">
                    <form id="bookingForm" method="POST" action="">
                        <input type="hidden" name="room_id" value="<?php echo htmlspecialchars($room['room_id']); ?>">
                        <input type="hidden" name="room_number" value="<?php echo htmlspecialchars($room['room_number']); ?>">
                        <input type="hidden" name="base_price" value="<?php echo $room['base_price']; ?>">
                        <input type="hidden" name="num_nights" id="num_nights_input" value="<?php echo $num_nights; ?>">
                        <input type="hidden" name="total_price" id="total_price_input" value="<?php echo $total_price; ?>">
                        
                        <!-- Thông tin khách hàng -->
                        <div class="mb-5">
                            <h4 class="section-title">
                                <i class="fas fa-user me-2"></i>Thông Tin Khách Hàng
                            </h4>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">
                                        Họ và tên <span class="required-star">*</span>
                                    </label>
                                    <input type="text" class="form-control form-control-lg" 
                                           name="guest_name" required 
                                           placeholder="Nguyễn Văn A"
                                           value="<?php echo isset($_POST['guest_name']) ? htmlspecialchars($_POST['guest_name']) : ''; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">
                                        Số điện thoại <span class="required-star">*</span>
                                    </label>
                                    <input type="tel" class="form-control form-control-lg" 
                                            name="guest_phone" required 
                                            pattern="^0[0-9]{9,10}$"
                                            title="Số điện thoại 10số, bắt đầu bằng 0 (VD: 0912345678)"
                                            placeholder="0912345678"
                                            value="<?php echo isset($_POST['guest_phone']) ? htmlspecialchars($_POST['guest_phone']) : ''; ?>">
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">
                                        Email
                                    </label>
                                    <input type="email" class="form-control form-control-lg" 
                                           name="guest_email"
                                           placeholder="example@gmail.com"
                                           value="<?php echo isset($_POST['guest_email']) ? htmlspecialchars($_POST['guest_email']) : ''; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">
                                        CCCD/CMND
                                    </label>
                                    <input type="text" class="form-control form-control-lg" 
                                           name="guest_id_card"
                                           placeholder="012345678901"
                                           value="<?php echo isset($_POST['guest_id_card']) ? htmlspecialchars($_POST['guest_id_card']) : ''; ?>">
                                </div>
                                
                                <div class="col-12 mb-3">
                                    <label class="form-label fw-semibold">
                                        Địa chỉ
                                    </label>
                                    <textarea class="form-control" name="guest_address" rows="2"
                                              placeholder="Số nhà, đường, phường/xã, quận/huyện, tỉnh/thành phố"><?php echo isset($_POST['guest_address']) ? htmlspecialchars($_POST['guest_address']) : ''; ?></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Thông tin đặt phòng -->
                        <div class="mb-5">
                            <h4 class="section-title">
                                <i class="fas fa-calendar-alt me-2"></i>Thông Tin Đặt Phòng
                            </h4>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">
                                        Ngày nhận phòng <span class="required-star">*</span>
                                    </label>
                                    <input type="date" class="form-control form-control-lg" 
                                           name="check_in_date" id="check_in_date"
                                           value="<?php echo isset($_POST['check_in_date']) ? $_POST['check_in_date'] : $check_in; ?>" 
                                           min="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">
                                        Ngày trả phòng <span class="required-star">*</span>
                                    </label>
                                    <input type="date" class="form-control form-control-lg" 
                                           name="check_out_date" id="check_out_date"
                                           value="<?php echo isset($_POST['check_out_date']) ? $_POST['check_out_date'] : $check_out; ?>" 
                                           min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" required>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">
                                        Số khách <span class="required-star">*</span>
                                    </label>
                                    <select class="form-control form-control-lg" name="num_guests" required>
                                        <?php 
                                        $selected_guests = $_POST['num_guests'] ?? min(2, $room['max_guests']);
                                        for($i = 1; $i <= $room['max_guests']; $i++): 
                                        ?>
                                        <option value="<?php echo $i; ?>" <?php echo $i == $selected_guests ? 'selected' : ''; ?>>
                                            <?php echo $i; ?> người
                                        </option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">
                                        Số đêm
                                    </label>
                                    <div class="input-group">
                                        <input type="text" class="form-control form-control-lg" 
                                               id="nights_count" readonly 
                                               value="<?php echo $num_nights; ?> đêm">
                                        <span class="input-group-text bg-primary text-white">
                                            <i class="fas fa-moon"></i>
                                        </span>
                                    </div>
                                </div>
                                
                                <div class="col-12 mb-3">
                                    <label class="form-label fw-semibold">
                                        <i class="fas fa-star me-1"></i>Yêu cầu đặc biệt
                                    </label>
                                    <textarea class="form-control" name="special_requests" rows="3"
                                              placeholder="Vui lòng nhập yêu cầu đặc biệt (nếu có) về giường, thức ăn, dịch vụ..."><?php echo isset($_POST['special_requests']) ? htmlspecialchars($_POST['special_requests']) : ''; ?></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Nút submit -->
                        <div class="d-flex justify-content-between align-items-center pt-4 border-top">
                            <div>
                                <a href="index.php?page=rooms" class="btn btn-outline-secondary px-4">
                                    <i class="fas fa-times me-2"></i>Hủy bỏ
                                </a>
                            </div>
                            <div>
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-check-circle me-2"></i>Xác Nhận Đặt Phòng
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Cột phải: Tóm tắt & Thanh toán -->
            <div class="col-lg-4">
                <!-- Tóm tắt đơn hàng -->
                <div class="price-summary-card sticky-top" style="top: 20px;">
                    <h4 class="section-title text-center mb-4">
                        <i class="fas fa-file-invoice-dollar me-2"></i>TÓM TẮT ĐƠN HÀNG
                    </h4>
                    
                    <div class="mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h6 class="fw-bold mb-1">Phòng <?php echo htmlspecialchars($room['room_number']); ?></h6>
                                <small class="text-muted"><?php echo htmlspecialchars($room['room_type']); ?></small>
                            </div>
                            <span class="badge bg-success status-badge">
                                <i class="fas fa-check me-1"></i>Còn trống
                            </span>
                        </div>
                        
                        <div class="border-bottom pb-3 mb-3">
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">Ngày nhận phòng:</span>
                                <strong id="display_check_in"><?php echo date('d/m/Y', strtotime($check_in)); ?></strong>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">Ngày trả phòng:</span>
                                <strong id="display_check_out"><?php echo date('d/m/Y', strtotime($check_out)); ?></strong>
                            </div>
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Số đêm:</span>
                                <strong id="display_nights"><?php echo $num_nights; ?></strong>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <h6 class="fw-bold mb-3">
                            <i class="fas fa-money-bill-wave me-2"></i>CHI TIẾT THANH TOÁN
                        </h6>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span>Đơn giá/đêm:</span>
                            <span class="fw-bold" id="display_price_per_night">
                                <?php echo formatCurrency($room['base_price']); ?>
                            </span>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span>Số đêm:</span>
                            <span class="fw-bold" id="display_nights_count"><?php echo $num_nights; ?></span>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-3">
                            <span>Tổng tiền phòng:</span>
                            <span class="fw-bold text-primary" id="display_room_total">
                                <?php echo formatCurrency($total_price); ?>
                            </span>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-2 text-muted">
                            <small>Phí dịch vụ:</small>
                            <small>0 ₫</small>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-2 text-muted">
                            <small>Thuế VAT:</small>
                            <small>0 ₫</small>
                        </div>
                        
                        <hr class="my-3">
                        
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="fw-bold mb-0">TỔNG CỘNG:</h5>
                            <h3 class="total-price mb-0" id="display_total_price">
                                <?php echo formatCurrency($total_price); ?>
                            </h3>
                        </div>
                        
                        <small class="text-muted d-block mt-2 text-center">
                            <i class="fas fa-info-circle me-1"></i>
                            Giá đã bao gồm VAT và phí dịch vụ
                        </small>
                    </div>
                    
                    <div class="alert alert-info mt-4">
                        <div class="d-flex">
                            <i class="fas fa-shield-alt fa-2x me-3 text-primary"></i>
                            <div>
                                <h6 class="fw-bold mb-1">Đảm bảo giá tốt nhất</h6>
                                <small class="d-block mb-1">• Giá không đổi khi đặt</small>
                                <small class="d-block mb-1">• Hủy miễn phí trước 24h</small>
                                <small class="d-block">• Không tính phí đặt chỗ</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // DOM Elements
        const checkInInput = document.getElementById('check_in_date');
        const checkOutInput = document.getElementById('check_out_date');
        const nightsCount = document.getElementById('nights_count');
        const displayCheckIn = document.getElementById('display_check_in');
        const displayCheckOut = document.getElementById('display_check_out');
        const displayNights = document.getElementById('display_nights');
        const displayNightsCount = document.getElementById('display_nights_count');
        const displayPricePerNight = document.getElementById('display_price_per_night');
        const displayRoomTotal = document.getElementById('display_room_total');
        const displayTotalPrice = document.getElementById('display_total_price');
        const numNightsInput = document.getElementById('num_nights_input');
        const totalPriceInput = document.getElementById('total_price_input');
        
        const pricePerNight = <?php echo $room['base_price']; ?>;
        const form = document.getElementById('bookingForm');
        
        // Format tiền
        function formatCurrency(amount) {
            return new Intl.NumberFormat('vi-VN').format(amount) + ' ₫';
        }
        
        // Format ngày
        function formatDate(dateStr) {
            const date = new Date(dateStr);
            return date.toLocaleDateString('vi-VN', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric'
            });
        }
        
        // Tính số đêm
        function calculateNights() {
            const checkIn = new Date(checkInInput.value);
            const checkOut = new Date(checkOutInput.value);
            
            if (checkIn && checkOut && checkOut > checkIn) {
                const diffTime = checkOut.getTime() - checkIn.getTime();
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                
                // Cập nhật hiển thị
                nightsCount.value = diffDays + ' đêm';
                displayNights.textContent = diffDays;
                displayNightsCount.textContent = diffDays;
                
                // Tính tổng tiền
                const total = pricePerNight * diffDays;
                displayRoomTotal.textContent = formatCurrency(total);
                displayTotalPrice.textContent = formatCurrency(total);
                
                // Cập nhật hidden inputs
                numNightsInput.value = diffDays;
                totalPriceInput.value = total;
                
                // Cập nhật ngày hiển thị
                displayCheckIn.textContent = formatDate(checkInInput.value);
                displayCheckOut.textContent = formatDate(checkOutInput.value);
                
                return diffDays;
            } else {
                // Giá trị mặc định
                nightsCount.value = '1 đêm';
                displayNights.textContent = '1';
                displayNightsCount.textContent = '1';
                displayRoomTotal.textContent = formatCurrency(pricePerNight);
                displayTotalPrice.textContent = formatCurrency(pricePerNight);
                displayCheckIn.textContent = formatDate(checkInInput.value);
                displayCheckOut.textContent = formatDate(checkOutInput.value);
                
                numNightsInput.value = 1;
                totalPriceInput.value = pricePerNight;
                
                return 1;
            }
        }
        
        // Xử lý thay đổi ngày check-in
        checkInInput.addEventListener('change', function() {
            const checkInDate = new Date(this.value);
            const nextDay = new Date(checkInDate);
            nextDay.setDate(nextDay.getDate() + 1);
            
            // Định dạng YYYY-MM-DD
            const nextDayStr = nextDay.toISOString().split('T')[0];
            
            // Cập nhật min cho check-out
            checkOutInput.min = nextDayStr;
            
            // Nếu check-out hiện tại < ngày mới, cập nhật
            if (new Date(checkOutInput.value) < nextDay) {
                checkOutInput.value = nextDayStr;
            }
            
            calculateNights();
        });
        
        // Xử lý thay đổi ngày check-out
        checkOutInput.addEventListener('change', function() {
            const checkInDate = new Date(checkInInput.value);
            const checkOutDate = new Date(this.value);
            
            // Kiểm tra nếu check-out <= check-in
            if (checkOutDate <= checkInDate) {
                alert('Ngày trả phòng phải sau ngày nhận phòng!');
                const nextDay = new Date(checkInDate);
                nextDay.setDate(nextDay.getDate() + 1);
                this.value = nextDay.toISOString().split('T')[0];
            }
            
            calculateNights();
        });
        
        // Xử lý submit form
        form.addEventListener('submit', function(e) {
            // Hiển thị loading
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Đang xử lý...';
            submitBtn.disabled = true;
            
            // Form sẽ được submit bình thường
        });
        
        // Tính toán ban đầu
        calculateNights();
        
        // Cập nhật giá trị hiển thị ban đầu
        displayPricePerNight.textContent = formatCurrency(pricePerNight);
    });
    </script>
</body>
</html>