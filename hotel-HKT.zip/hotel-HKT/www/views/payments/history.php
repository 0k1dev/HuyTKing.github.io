<?php
// views/payments/history.php

// Kiểm tra session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Đường dẫn config
require_once __DIR__ . '/../../config/database.php';

// Xử lý tìm kiếm và phân trang
$search = $_GET['search'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

// Kiểm tra bảng payments tồn tại, nếu không thì tạo
try {
    $pdo->query("SELECT 1 FROM payments LIMIT 1");
} catch (PDOException $e) {
    // Bảng chưa tồn tại, tạo bảng
    $create_table = "
        CREATE TABLE IF NOT EXISTS payments (
            payment_id INT AUTO_INCREMENT PRIMARY KEY,
            booking_id INT NOT NULL,
            payment_method VARCHAR(50) DEFAULT 'qr_code',
            amount DECIMAL(10,2) NOT NULL,
            payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status VARCHAR(20) DEFAULT 'completed',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ";
    $pdo->exec($create_table);
}

// Lấy tổng số bản ghi
$count_sql = "SELECT COUNT(*) as total FROM payments WHERE 1=1";
$count_params = [];

if ($search) {
    $count_sql .= " AND (booking_id LIKE ? OR payment_method LIKE ?)";
    $count_params = ["%$search%", "%$search%"];
}

$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($count_params);
$total_records = $count_stmt->fetch()['total'];
$total_pages = ceil($total_records / $limit);

// Lấy dữ liệu thanh toán
$sql = "
    SELECT 
        p.*,
        b.customer_name,
        b.customer_phone,
        r.room_number,
        r.room_type
    FROM payments p
    LEFT JOIN bookings b ON p.booking_id = b.booking_id
    LEFT JOIN rooms r ON b.room_id = r.room_id
    WHERE 1=1
";

$params = [];

if ($search) {
    $sql .= " AND (p.booking_id LIKE ? OR b.customer_name LIKE ? OR p.payment_method LIKE ?)";
    $params = ["%$search%", "%$search%", "%$search%"];
}

$sql .= " ORDER BY p.payment_date DESC";

// SỬA LỖI: Không dùng tham số hóa cho LIMIT và OFFSET, nối trực tiếp
$sql .= " LIMIT $limit OFFSET $offset";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$payments = $stmt->fetchAll();

// Tính tổng số tiền
$total_sql = "SELECT SUM(amount) as total_amount FROM payments";
$total_stmt = $pdo->query($total_sql);
$total_amount = $total_stmt->fetch()['total_amount'] ?? 0;

// Lấy thống kê theo phương thức thanh toán
$method_stats_sql = "
    SELECT 
        payment_method,
        COUNT(*) as count,
        SUM(amount) as total
    FROM payments 
    GROUP BY payment_method
    ORDER BY total DESC
";
$method_stats = $pdo->query($method_stats_sql)->fetchAll();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lịch Sử Thanh Toán - Hotel HKT</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px 0;
        }
        
        .history-container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .history-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(50, 50, 93, 0.1), 0 5px 15px rgba(0, 0, 0, 0.07);
            overflow: hidden;
        }
        
        .history-header {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .history-body {
            padding: 30px;
        }
        
        .total-box {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 30px;
            text-align: center;
            box-shadow: 0 10px 20px rgba(40, 167, 69, 0.2);
        }
        
        .stat-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s;
            margin-bottom: 20px;
            height: 100%;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .payment-row:hover {
            background-color: #f8f9fa !important;
            cursor: pointer;
        }
        
        .status-badge {
            font-size: 0.8rem;
            padding: 6px 12px;
            border-radius: 20px;
        }
        
        .method-badge {
            font-size: 0.8rem;
            padding: 6px 12px;
            border-radius: 20px;
            background: #6f42c1;
            color: white;
        }
        
        @media (max-width: 768px) {
            .history-body {
                padding: 15px;
            }
        }
        
        .search-box {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            border: 1px solid #dee2e6;
        }
        
        .pagination .page-item.active .page-link {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            border-color: #6a11cb;
            color: white;
        }
        
        .table th {
            background: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
            font-weight: 600;
        }
        
        .stats-section {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .method-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;
        }
        
        .qr-icon { background: #28a745; color: white; }
        .cash-icon { background: #17a2b8; color: white; }
        .card-icon { background: #ffc107; color: black; }
        .transfer-icon { background: #6f42c1; color: white; }
    </style>
</head>
<body>
    <div class="container history-container">
        <div class="history-card">
            <!-- Header -->
            <div class="history-header">
                <h1 class="mb-3"><i class="fas fa-history me-2"></i> Lịch Sử Thanh Toán</h1>
                <p class="lead mb-0">Theo dõi và quản lý tất cả giao dịch thanh toán</p>
            </div>
            
            <!-- Body -->
            <div class="history-body">
                <!-- Thông báo session -->
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <!-- Tổng quan -->
                <div class="total-box">
                    <div class="row align-items-center">
                        <div class="col-md-4 text-center">
                            <h2><i class="fas fa-chart-line me-2"></i> Tổng quan</h2>
                        </div>
                        <div class="col-md-4 text-center">
                            <h3 class="mb-1"><?php echo $total_records; ?></h3>
                            <p class="mb-0">Giao dịch</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <h2 class="mb-1"><?php echo number_format($total_amount, 0, ',', '.'); ?> ₫</h2>
                            <p class="mb-0">Tổng doanh thu</p>
                        </div>
                    </div>
                </div>
                
                <!-- Thống kê phương thức thanh toán -->
                <?php if (!empty($method_stats)): ?>
                <div class="stats-section">
                    <h4 class="mb-3"><i class="fas fa-chart-pie me-2"></i> Thống kê theo phương thức</h4>
                    <div class="row">
                        <?php foreach ($method_stats as $stat): 
                            $method_name = [
                                'qr_code' => 'QR Code',
                                'cash' => 'Tiền mặt',
                                'credit_card' => 'Thẻ tín dụng',
                                'bank_transfer' => 'Chuyển khoản'
                            ][$stat['payment_method']] ?? $stat['payment_method'];
                            
                            $icon_class = [
                                'qr_code' => 'qr-icon',
                                'cash' => 'cash-icon',
                                'credit_card' => 'card-icon',
                                'bank_transfer' => 'transfer-icon'
                            ][$stat['payment_method']] ?? '';
                            
                            $percentage = $total_records > 0 ? round(($stat['count'] / $total_records) * 100, 1) : 0;
                        ?>
                        <div class="col-md-3 col-sm-6 mb-3">
                            <div class="stat-card">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="method-icon <?php echo $icon_class; ?>">
                                            <i class="fas fa-<?php 
                                                echo $stat['payment_method'] === 'qr_code' ? 'qrcode' : 
                                                     ($stat['payment_method'] === 'cash' ? 'money-bill' : 
                                                     ($stat['payment_method'] === 'credit_card' ? 'credit-card' : 'university')); 
                                            ?>"></i>
                                        </div>
                                        <div>
                                            <h5 class="card-title mb-0"><?php echo $method_name; ?></h5>
                                            <small class="text-muted"><?php echo $stat['count']; ?> giao dịch</small>
                                        </div>
                                    </div>
                                    <div class="progress mb-2" style="height: 8px;">
                                        <div class="progress-bar" role="progressbar" 
                                             style="width: <?php echo $percentage; ?>%; background-color: inherit;" 
                                             aria-valuenow="<?php echo $percentage; ?>" 
                                             aria-valuemin="0" 
                                             aria-valuemax="100"></div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <span class="text-muted"><?php echo $percentage; ?>%</span>
                                        <span class="fw-bold text-primary"><?php echo number_format($stat['total'], 0, ',', '.'); ?> ₫</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Tìm kiếm -->
                <div class="search-box">
                    <h4 class="mb-3"><i class="fas fa-search me-2"></i> Tìm kiếm giao dịch</h4>
                    <form method="GET" action="" class="row g-3">
                        <div class="col-md-9">
                            <div class="input-group input-group-lg">
                                <span class="input-group-text bg-primary text-white">
                                    <i class="fas fa-search"></i>
                                </span>
                                <input type="text" class="form-control" name="search" 
                                       placeholder="Tìm theo mã booking, tên khách, phương thức..." 
                                       value="<?php echo htmlspecialchars($search); ?>">
                                <input type="hidden" name="page" value="payments/history">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-search me-2"></i> Tìm kiếm
                                </button>
                            </div>
                        </div>
                    </form>
                    <?php if ($search): ?>
                    <div class="mt-3">
                        <a href="index.php?page=payments/history" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-times me-1"></i> Xóa bộ lọc
                        </a>
                        <span class="ms-2">
                            <i class="fas fa-info-circle text-primary me-1"></i>
                            Tìm thấy <strong><?php echo $total_records; ?></strong> kết quả cho "<strong><?php echo htmlspecialchars($search); ?></strong>"
                        </span>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Danh sách thanh toán -->
                <?php if (empty($payments)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-receipt fa-4x text-muted mb-4"></i>
                        <h3 class="text-muted mb-3"><?php echo $search ? 'Không tìm thấy kết quả' : 'Chưa có giao dịch nào'; ?></h3>
                        <p class="text-muted mb-4">
                            <?php if ($search): ?>
                                Không tìm thấy giao dịch phù hợp với từ khóa "<?php echo htmlspecialchars($search); ?>"
                            <?php else: ?>
                                Hệ thống chưa ghi nhận giao dịch thanh toán nào.
                            <?php endif; ?>
                        </p>
                        <?php if (!$search): ?>
                            <a href="index.php?page=bookings" class="btn btn-primary btn-lg">
                                <i class="fas fa-calendar-check me-2"></i> Đến trang Booking để tạo giao dịch
                            </a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <!-- Thông tin kết quả -->
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4><i class="fas fa-list me-2"></i> Danh sách giao dịch</h4>
                            <p class="text-muted mb-0">
                                Hiển thị <strong><?php echo count($payments); ?></strong> giao dịch 
                                (từ <?php echo $offset + 1; ?> đến <?php echo min($offset + $limit, $total_records); ?>)
                            </p>
                        </div>
                        <div class="text-end">
                            <div class="btn-group">
                                <button class="btn btn-outline-primary" onclick="exportToExcel()">
                                    <i class="fas fa-file-excel me-2"></i> Excel
                                </button>
                                <button class="btn btn-outline-secondary" onclick="window.print()">
                                    <i class="fas fa-print me-2"></i> In
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Bảng danh sách -->
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th width="80">#</th>
                                    <th width="120">Booking ID</th>
                                    <th>Khách hàng</th>
                                    <th width="100">Phòng</th>
                                    <th width="120">Phương thức</th>
                                    <th width="150">Số tiền</th>
                                    <th width="150">Ngày GD</th>
                                    <th width="120">Trạng thái</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $counter = $offset + 1; ?>
                                <?php foreach ($payments as $payment): ?>
                                <tr class="payment-row" onclick="viewPaymentDetails(<?php echo $payment['payment_id']; ?>)">
                                    <td>
                                        <span class="badge bg-secondary"><?php echo $counter++; ?></span>
                                    </td>
                                    <td>
                                        <a href="index.php?page=payments/qr&booking_id=<?php echo $payment['booking_id']; ?>" 
                                           class="text-decoration-none fw-bold" onclick="event.stopPropagation()">
                                            #<?php echo $payment['booking_id']; ?>
                                        </a>
                                    </td>
                                    <td>
                                        <div class="fw-bold"><?php echo htmlspecialchars($payment['customer_name'] ?? 'N/A'); ?></div>
                                        <small class="text-muted"><?php echo htmlspecialchars($payment['customer_phone'] ?? ''); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-info"><?php echo htmlspecialchars($payment['room_number'] ?? 'N/A'); ?></span>
                                        <small class="d-block text-muted"><?php echo htmlspecialchars($payment['room_type'] ?? ''); ?></small>
                                    </td>
                                    <td>
                                        <?php 
                                        $method_icons = [
                                            'qr_code' => ['qrcode', 'success'],
                                            'cash' => ['money-bill', 'warning'],
                                            'credit_card' => ['credit-card', 'danger'],
                                            'bank_transfer' => ['university', 'primary']
                                        ];
                                        $method_icon = $method_icons[$payment['payment_method']] ?? ['question-circle', 'secondary'];
                                        ?>
                                        <span class="badge bg-<?php echo $method_icon[1]; ?>">
                                            <i class="fas fa-<?php echo $method_icon[0]; ?> me-1"></i>
                                            <?php 
                                            $method_text = [
                                                'qr_code' => 'QR',
                                                'cash' => 'Tiền mặt',
                                                'credit_card' => 'Thẻ',
                                                'bank_transfer' => 'CK'
                                            ][$payment['payment_method']] ?? $payment['payment_method'];
                                            echo $method_text;
                                            ?>
                                        </span>
                                    </td>
                                    <td class="fw-bold text-success">
                                        <?php echo number_format($payment['amount'], 0, ',', '.'); ?> ₫
                                    </td>
                                    <td>
                                        <div><?php echo date('d/m/Y', strtotime($payment['payment_date'])); ?></div>
                                        <small class="text-muted"><?php echo date('H:i:s', strtotime($payment['payment_date'])); ?></small>
                                    </td>
                                    <td>
                                        <?php 
                                        $status_config = [
                                            'completed' => ['success', 'check-circle', 'Thành công'],
                                            'pending' => ['warning', 'clock', 'Chờ xử lý'],
                                            'failed' => ['danger', 'times-circle', 'Thất bại']
                                        ];
                                        $status = $status_config[$payment['status']] ?? ['secondary', 'question-circle', $payment['status']];
                                        ?>
                                        <span class="badge bg-<?php echo $status[0]; ?>">
                                            <i class="fas fa-<?php echo $status[1]; ?> me-1"></i>
                                            <?php echo $status[2]; ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Phân trang -->
                    <?php if ($total_pages > 1): ?>
                    <nav aria-label="Page navigation" class="mt-4">
                        <ul class="pagination justify-content-center">
                            <!-- Nút đầu trang -->
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="index.php?page=payments/history&search=<?php echo urlencode($search); ?>&page=1">
                                        <i class="fas fa-angle-double-left"></i>
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="index.php?page=payments/history&search=<?php echo urlencode($search); ?>&page=<?php echo $page-1; ?>">
                                        <i class="fas fa-chevron-left"></i>
                                    </a>
                                </li>
                            <?php else: ?>
                                <li class="page-item disabled">
                                    <span class="page-link"><i class="fas fa-chevron-left"></i></span>
                                </li>
                            <?php endif; ?>
                            
                            <!-- Các trang số -->
                            <?php 
                            $start_page = max(1, $page - 2);
                            $end_page = min($total_pages, $page + 2);
                            
                            if ($start_page > 1) {
                                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                            }
                            
                            for ($i = $start_page; $i <= $end_page; $i++): 
                            ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="index.php?page=payments/history&search=<?php echo urlencode($search); ?>&page=<?php echo $i; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($end_page < $total_pages) {
                                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                            } ?>
                            
                            <!-- Nút cuối trang -->
                            <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="index.php?page=payments/history&search=<?php echo urlencode($search); ?>&page=<?php echo $page+1; ?>">
                                        <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="index.php?page=payments/history&search=<?php echo urlencode($search); ?>&page=<?php echo $total_pages; ?>">
                                        <i class="fas fa-angle-double-right"></i>
                                    </a>
                                </li>
                            <?php else: ?>
                                <li class="page-item disabled">
                                    <span class="page-link"><i class="fas fa-chevron-right"></i></span>
                                </li>
                            <?php endif; ?>
                        </ul>
                        <div class="text-center text-muted mt-2">
                            Trang <?php echo $page; ?> / <?php echo $total_pages; ?> 
                            (<?php echo $total_records; ?> giao dịch)
                        </div>
                    </nav>
                    <?php endif; ?>
                    
                    <!-- Tổng kết -->
                    <div class="alert alert-light mt-4">
                        <div class="row text-center">
                            <div class="col-md-4">
                                <h5 class="text-primary mb-1"><?php echo $total_records; ?></h5>
                                <small class="text-muted">Tổng giao dịch</small>
                            </div>
                            <div class="col-md-4">
                                <h5 class="text-success mb-1"><?php echo number_format($total_amount, 0, ',', '.'); ?> ₫</h5>
                                <small class="text-muted">Tổng doanh thu</small>
                            </div>
                            <div class="col-md-4">
                                <h5 class="text-info mb-1">
                                    <?php 
                                    $avg_amount = $total_records > 0 ? round($total_amount / $total_records, 0) : 0;
                                    echo number_format($avg_amount, 0, ',', '.'); ?> ₫
                                </h5>
                                <small class="text-muted">Trung bình/giao dịch</small>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- Nút điều khiển -->
                <div class="text-center mt-4 pt-3 border-top">
                    <a href="index.php?page=bookings" class="btn btn-primary me-2">
                        <i class="fas fa-list me-2"></i> Danh sách booking
                    </a>
                    <a href="index.php?page=payments/qr" class="btn btn-success me-2">
                        <i class="fas fa-qrcode me-2"></i> Thanh toán QR
                    </a>
                    <a href="index.php?page=home" class="btn btn-outline-secondary">
                        <i class="fas fa-home me-2"></i> Trang chủ
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Xem chi tiết giao dịch
    function viewPaymentDetails(paymentId) {
        // Có thể phát triển chức năng xem chi tiết modal
        console.log('Xem chi tiết giao dịch #' + paymentId);
        // window.location.href = 'index.php?page=payments/detail&id=' + paymentId;
    }
    
    // Xuất Excel
    function exportToExcel() {
        alert('Chức năng xuất Excel sẽ được triển khai sau.\nHiện tại vui lòng sử dụng chức năng In (Ctrl+P) để xuất PDF.');
    }
    
    // Tự động refresh dữ liệu mỗi 2 phút
    setTimeout(function() {
        window.location.reload();
    }, 120000);
    
    // Highlight dòng khi click
    document.addEventListener('DOMContentLoaded', function() {
        const rows = document.querySelectorAll('.payment-row');
        rows.forEach(row => {
            row.addEventListener('click', function(e) {
                if (!e.target.closest('a')) {
                    rows.forEach(r => r.classList.remove('table-active'));
                    this.classList.add('table-active');
                }
            });
        });
    });
    </script>
</body>
</html>