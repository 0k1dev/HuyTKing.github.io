<?php
// views/payments/index.php - Trang chính thanh toán
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Thanh toán - Hotel Huytking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; padding-top: 30px; }
        .dashboard-card { 
            background: white; 
            padding: 30px; 
            border-radius: 15px; 
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            text-align: center;
            height: 100%;
            transition: transform 0.3s;
        }
        .dashboard-card:hover {
            transform: translateY(-5px);
        }
        .card-icon {
            font-size: 3rem;
            margin-bottom: 15px;
            color: #0d6efd;
        }
        .card-title {
            font-size: 1.2rem;
            color: #666;
            margin-bottom: 10px;
        }
        .card-desc {
            color: #999;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="text-center mb-5">
            <h1 class="display-5 fw-bold text-primary">
                <i class="fas fa-credit-card"></i> Quản lý Thanh toán
            </h1>
            <p class="lead text-muted">Quản lý tất cả giao dịch thanh toán của khách sạn</p>
        </div>
        
        <!-- Dashboard Cards -->
        <div class="row g-4">
            <div class="col-md-4">
                <a href="<?php echo BASE_URL; ?>/?page=payments/qr" class="text-decoration-none">
                    <div class="dashboard-card">
                        <div class="card-icon">
                            <i class="fas fa-qrcode"></i>
                        </div>
                        <h3 class="fw-bold">Tạo mã QR</h3>
                        <p class="card-desc">
                            Tạo mã QR thanh toán nhanh cho khách hàng
                        </p>
                        <div class="mt-3">
                            <span class="badge bg-primary">Nhấn để bắt đầu</span>
                        </div>
                    </div>
                </a>
            </div>
            
            <div class="col-md-4">
                <a href="<?php echo BASE_URL; ?>/?page=payments/history" class="text-decoration-none">
                    <div class="dashboard-card">
                        <div class="card-icon">
                            <i class="fas fa-history"></i>
                        </div>
                        <h3 class="fw-bold">Lịch sử thanh toán</h3>
                        <p class="card-desc">
                            Xem và quản lý tất cả giao dịch đã thực hiện
                        </p>
                        <div class="mt-3">
                            <span class="badge bg-success">Xem báo cáo</span>
                        </div>
                    </div>
                </a>
            </div>
            
            <div class="col-md-4">
                <a href="<?php echo BASE_URL; ?>/?page=payments/qr" class="text-decoration-none">
                    <div class="dashboard-card">
                        <div class="card-icon">
                            <i class="fas fa-file-invoice-dollar"></i>
                        </div>
                        <h3 class="fw-bold">Hóa đơn</h3>
                        <p class="card-desc">
                            Tạo và in hóa đơn thanh toán cho khách hàng
                        </p>
                        <div class="mt-3">
                            <span class="badge bg-warning">Tính năng sắp ra mắt</span>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="row mt-5">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-bolt"></i> Thao tác nhanh</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex flex-wrap gap-3">
                            <a href="<?php echo BASE_URL; ?>/?page=home" class="btn btn-outline-primary">
                                <i class="fas fa-home"></i> Trang chủ
                            </a>
                            <a href="<?php echo BASE_URL; ?>/?page=rooms" class="btn btn-outline-secondary">
                                <i class="fas fa-door-open"></i> Quản lý phòng
                            </a>
                            <a href="<?php echo BASE_URL; ?>/?page=bookings" class="btn btn-outline-info">
                                <i class="fas fa-calendar-alt"></i> Đặt phòng
                            </a>
                            <a href="<?php echo BASE_URL; ?>/?page=guests" class="btn btn-outline-success">
                                <i class="fas fa-users"></i> Khách hàng
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
</body>
</html>