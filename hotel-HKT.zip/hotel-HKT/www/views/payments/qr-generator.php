<?php
// views/payments/qr-generator.php

// Kiểm tra session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Đơn giản hóa đường dẫn config
require_once __DIR__ . '/../../config/database.php';

// ============================================
// XỬ LÝ CHECK-IN TRƯỚC KHI THANH TOÁN
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkin'])) {
    $booking_id = $_POST['booking_id'] ?? null;
    
    if ($booking_id) {
        try {
            $pdo->beginTransaction();
            
            // 1. Kiểm tra booking tồn tại và chưa check-in
            $check_stmt = $pdo->prepare("
                SELECT b.*, r.status as room_status 
                FROM bookings b 
                JOIN rooms r ON b.room_id = r.room_id 
                WHERE b.booking_id = ? 
                AND b.status IN ('confirmed', 'pending')
            ");
            $check_stmt->execute([$booking_id]);
            $booking = $check_stmt->fetch();
            
            if (!$booking) {
                throw new Exception("Booking không tồn tại hoặc không thể check-in (ID: $booking_id)");
            }
            
            // Kiểm tra trạng thái booking
            if ($booking['status'] === 'checked_in') {
                throw new Exception("Booking đã được check-in rồi");
            }
            
            if ($booking['status'] === 'checked_out') {
                throw new Exception("Booking đã check-out, không thể check-in lại");
            }
            
            // Kiểm tra phòng có khả dụng không
            $check_room_stmt = $pdo->prepare("
                SELECT COUNT(*) as occupied_count 
                FROM bookings 
                WHERE room_id = ? 
                AND status = 'checked_in' 
                AND booking_id != ?
            ");
            $check_room_stmt->execute([$booking['room_id'], $booking_id]);
            $room_check = $check_room_stmt->fetch();
            
            if ($room_check['occupied_count'] > 0) {
                throw new Exception("Phòng đang có khách ở. Vui lòng kiểm tra lại.");
            }
            
            // 2. Cập nhật trạng thái booking
            $update_booking = $pdo->prepare("
                UPDATE bookings 
                SET status = 'checked_in'
                WHERE booking_id = ?
            ");
            $update_booking->execute([$booking_id]);
            
            // 3. Cập nhật trạng thái phòng
            $update_room = $pdo->prepare("
                UPDATE rooms 
                SET status = 'occupied' 
                WHERE room_id = ?
            ");
            $update_room->execute([$booking['room_id']]);
            
            $pdo->commit();
            
            $_SESSION['success'] = "✅ Check-in thành công! Khách đã nhận phòng.";
            header("Location: index.php?page=payments/qr&booking_id=" . $booking_id);
            exit;
            
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $_SESSION['error'] = "❌ Lỗi check-in: " . $e->getMessage();
            header("Location: index.php?page=payments/qr&booking_id=" . $booking_id);
            exit;
        }
    }
}

// ============================================
// XỬ LÝ CHECK-OUT KHI THANH TOÁN
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    $booking_id = $_POST['booking_id'] ?? null;
    
    if ($booking_id) {
        try {
            $pdo->beginTransaction();
            
            // 1. Kiểm tra booking đã check-in chưa
            $check_stmt = $pdo->prepare("
                SELECT b.* 
                FROM bookings b 
                WHERE b.booking_id = ? 
                AND b.status = 'checked_in'
            ");
            $check_stmt->execute([$booking_id]);
            $booking = $check_stmt->fetch();
            
            if (!$booking) {
                throw new Exception("Booking chưa check-in hoặc không tồn tại");
            }
            
            // 2. Cập nhật trạng thái booking
            $update_booking = $pdo->prepare("
                UPDATE bookings 
                SET status = 'checked_out'
                WHERE booking_id = ?
            ");
            $update_booking->execute([$booking_id]);
            
            // 3. Lấy room_id
            $get_room = $pdo->prepare("SELECT room_id FROM bookings WHERE booking_id = ?");
            $get_room->execute([$booking_id]);
            $room_data = $get_room->fetch();
            
            if ($room_data) {
                // 4. Cập nhật phòng
                $update_room = $pdo->prepare("
                    UPDATE rooms 
                    SET status = 'available'
                    WHERE room_id = ?
                ");
                $update_room->execute([$room_data['room_id']]);
            }
            
            // 5. Tính toán số tiền và số đêm
            $get_amount = $pdo->prepare("
                SELECT 
                    r.base_price,
                    DATEDIFF(
                        COALESCE(DATE(b.check_out_date), CURDATE()), 
                        COALESCE(DATE(b.check_in_date), CURDATE())
                    ) as nights,
                    r.base_price * DATEDIFF(
                        COALESCE(DATE(b.check_out_date), CURDATE()), 
                        COALESCE(DATE(b.check_in_date), CURDATE())
                    ) as total
                FROM bookings b 
                JOIN rooms r ON b.room_id = r.room_id 
                WHERE b.booking_id = ?
            ");
            $get_amount->execute([$booking_id]);
            $amount_data = $get_amount->fetch();
            
            $nights = $amount_data['nights'] ?? 1;
            if ($nights <= 0) $nights = 1;
            
            $total_amount = $amount_data['total'] ?? $amount_data['base_price'] ?? 0;
            
            // 6. Kiểm tra và tạo bảng payments nếu chưa có (SỬA: KHÔNG có total_nights)
            $table_check = $pdo->query("
                CREATE TABLE IF NOT EXISTS payments (
                    payment_id INT AUTO_INCREMENT PRIMARY KEY,
                    booking_id INT NOT NULL,
                    payment_method VARCHAR(50) DEFAULT 'qr_code',
                    amount DECIMAL(10,2) NOT NULL,
                    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    status VARCHAR(20) DEFAULT 'completed',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");
            
            // 7. Lưu thanh toán (SỬA: KHÔNG có total_nights)
            $payment_stmt = $pdo->prepare("
                INSERT INTO payments (
                    booking_id,
                    payment_method,
                    amount,
                    status
                ) VALUES (?, 'qr_code', ?, 'completed')
            ");
            $payment_stmt->execute([
                $booking_id,
                $total_amount
            ]);
            
            $pdo->commit();
            
            $_SESSION['success'] = "✅ Thanh toán thành công & đã check-out! Phòng đã được giải phóng.";
            header("Location: index.php?page=bookings");
            exit;
            
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $_SESSION['error'] = "❌ Lỗi khi check-out: " . $e->getMessage();
            header("Location: index.php?page=payments/qr&booking_id=" . $booking_id);
            exit;
        }
    }
}

// ============================================
// LẤY THÔNG TIN BOOKING
// ============================================
$booking_id = $_GET['booking_id'] ?? $_SESSION['booking_id'] ?? null;
$booking_info = null;
$error = null;

if ($booking_id) {
    try {
        $stmt = $pdo->prepare("
            SELECT 
                b.*,
                r.room_number,
                r.room_type,
                r.base_price,
                r.room_id,
                r.status as room_status,
                DATEDIFF(
                    COALESCE(DATE(b.check_out_date), CURDATE()), 
                    COALESCE(DATE(b.check_in_date), CURDATE())
                ) as total_nights,
                r.base_price * DATEDIFF(
                    COALESCE(DATE(b.check_out_date), CURDATE()), 
                    COALESCE(DATE(b.check_in_date), CURDATE())
                ) as total_amount,
                CASE 
                    WHEN b.status = 'confirmed' OR b.status = 'pending' THEN 'Chờ check-in'
                    WHEN b.status = 'checked_in' THEN 'Đang ở'
                    WHEN b.status = 'checked_out' THEN 'Đã trả phòng'
                    ELSE b.status
                END as status_text,
                DATE(b.check_in_date) as check_in,
                DATE(b.check_out_date) as check_out
            FROM bookings b 
            LEFT JOIN rooms r ON b.room_id = r.room_id 
            WHERE b.booking_id = ?
        ");
        $stmt->execute([$booking_id]);
        $booking_info = $stmt->fetch();
        
        if (!$booking_info) {
            $error = "Không tìm thấy thông tin đặt phòng #$booking_id";
        }
    } catch (PDOException $e) {
        $error = "Lỗi database: " . $e->getMessage();
    }
}

// ============================================
// THÔNG TIN NGÂN HÀNG
// ============================================
$bank_config = [
    'bank_name' => 'ACBANK',
    'account_number' => '43146717',
    'account_name' => 'ĐINH TẤN HUY',
    'bank_code' => 'ACB',
    'template' => 'compact2'
];

// Tạo QR code
$qr_image_url = null;
if ($booking_info && $booking_info['status'] === 'checked_in') {
    $amount = $booking_info['total_amount'] ?? $booking_info['base_price'] ?? 0;
    $description = "HKT-HOTEL Booking #{$booking_id} - {$booking_info['customer_name']}";
    $qr_image_url = "https://img.vietqr.io/image/{$bank_config['bank_code']}-{$bank_config['account_number']}-{$bank_config['template']}.jpg?amount={$amount}&addInfo=" . urlencode($description) . "&accountName=" . urlencode($bank_config['account_name']);
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh Toán & Check-out - Hotel HKT</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px 0;
        }
        .payment-container { max-width: 1000px; margin: 0 auto; }
        .payment-card { background: white; border-radius: 20px; box-shadow: 0 15px 35px rgba(50, 50, 93, 0.1), 0 5px 15px rgba(0, 0, 0, 0.07); }
        .payment-header { background: linear-gradient(135deg, #28a745 0%, #20c997 100%); color: white; padding: 30px; text-align: center; }
        .payment-body { padding: 40px; }
        
        .checkin-box {
            background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin: 30px 0;
            text-align: center;
        }
        .btn-checkin {
            background: linear-gradient(135deg, #ffc107 0%, #e0a800 100%);
            color: white;
            border: none;
            padding: 15px 50px;
            font-size: 1.2rem;
            font-weight: 600;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .btn-checkin:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(255, 193, 7, 0.3);
        }
        
        .checkout-box {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin: 30px 0;
            text-align: center;
        }
        .btn-checkout {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
            border: none;
            padding: 15px 50px;
            font-size: 1.2rem;
            font-weight: 600;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .btn-checkout:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(220, 53, 69, 0.3);
        }
        
        .alert-success-custom {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            border: 2px solid #28a745;
            color: #155724;
            border-radius: 10px;
            padding: 20px;
        }
        
        .qr-section {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            border: 2px solid #0d6efd;
        }
        
        @media (max-width: 768px) {
            .payment-body { padding: 20px; }
        }
        
        .status-badge {
            font-size: 0.9rem;
            padding: 8px 20px;
            border-radius: 20px;
        }
        
        .info-card {
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        .info-card .card-header {
            background: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container payment-container">
        <!-- Hiển thị thông báo session -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="payment-card">
            <!-- Header -->
            <div class="payment-header">
                <h1 class="mb-3"><i class="fas fa-credit-card me-2"></i> Quản lý Check-in/Check-out</h1>
                <p class="lead mb-0">Xử lý nhận phòng, thanh toán và trả phòng</p>
            </div>
            
            <!-- Body -->
            <div class="payment-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i> <?php echo $error; ?>
                    </div>
                    <div class="text-center mt-4">
                        <a href="index.php?page=bookings" class="btn btn-primary">
                            <i class="fas fa-arrow-left me-2"></i> Quay lại danh sách
                        </a>
                    </div>
                
                <?php elseif ($booking_info): ?>
                    <!-- THÔNG TIN BOOKING -->
                    <div class="alert alert-info">
                        <div class="d-flex justify-content-between align-items-center flex-wrap">
                            <div>
                                <h5 class="mb-1">Booking #<?php echo $booking_info['booking_id']; ?></h5>
                                <p class="mb-1">
                                    <strong><?php echo htmlspecialchars($booking_info['customer_name']); ?></strong> | 
                                    <i class="fas fa-phone me-1"></i><?php echo htmlspecialchars($booking_info['customer_phone']); ?>
                                </p>
                                <p class="mb-0">
                                    Phòng: <strong><?php echo htmlspecialchars($booking_info['room_number']); ?></strong> | 
                                    Loại: <strong><?php echo htmlspecialchars($booking_info['room_type']); ?></strong>
                                </p>
                            </div>
                            <div class="text-end">
                                <div class="h4 text-primary mb-1">
                                    <?php echo number_format($booking_info['total_amount'] ?? $booking_info['base_price'] ?? 0, 0, ',', '.'); ?> ₫
                                </div>
                                <div>
                                    <span class="status-badge bg-<?php 
                                        echo $booking_info['status'] === 'checked_in' ? 'success' : 
                                             (in_array($booking_info['status'], ['confirmed', 'pending']) ? 'warning' : 'secondary'); 
                                    ?>">
                                        <?php echo $booking_info['status_text']; ?>
                                    </span>
                                    <?php if (isset($booking_info['total_nights']) && $booking_info['total_nights'] > 0): ?>
                                        <span class="badge bg-info ms-1"><?php echo $booking_info['total_nights']; ?> đêm</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- TRẠNG THÁI: CHỜ CHECK-IN -->
                    <?php if (in_array($booking_info['status'], ['confirmed', 'pending'])): ?>
                        <div class="checkin-box">
                            <h4 class="mb-3"><i class="fas fa-door-open me-2"></i> Check-in Khách Hàng</h4>
                            <p class="mb-4">Khách hàng đã đến nhận phòng? Nhấn nút bên dưới để xác nhận check-in:</p>
                            
                            <div class="row mb-4">
                                <div class="col-md-6 text-start">
                                    <h6>Thông tin check-in:</h6>
                                    <ul class="mb-0">
                                        <li>Phòng: <strong><?php echo $booking_info['room_number']; ?></strong></li>
                                        <li>Check-in: <strong><?php echo date('d/m/Y', strtotime($booking_info['check_in'])); ?></strong></li>
                                        <li>Số đêm: <strong><?php echo $booking_info['total_nights']; ?> đêm</strong></li>
                                    </ul>
                                </div>
                                <div class="col-md-6 text-start">
                                    <h6>Chi phí:</h6>
                                    <ul class="mb-0">
                                        <li>Giá/đêm: <strong><?php echo number_format($booking_info['base_price'], 0, ',', '.'); ?> ₫</strong></li>
                                        <li>Tổng cộng: <strong class="text-warning"><?php echo number_format($booking_info['total_amount'], 0, ',', '.'); ?> ₫</strong></li>
                                    </ul>
                                </div>
                            </div>
                            
                            <form method="POST" action="" onsubmit="return confirmCheckin()">
                                <input type="hidden" name="booking_id" value="<?php echo $booking_info['booking_id']; ?>">
                                <button type="submit" name="checkin" value="1" class="btn btn-checkin">
                                    <i class="fas fa-sign-in-alt me-2"></i> Xác Nhận Check-in Ngay
                                </button>
                            </form>
                        </div>
                    
                    <!-- TRẠNG THÁI: ĐÃ CHECK-IN -->
                    <?php elseif ($booking_info['status'] === 'checked_in'): ?>
                        
                        <!-- QR CODE THANH TOÁN -->
                        <?php if ($qr_image_url): ?>
                        <div class="qr-section">
                            <h4 class="mb-4 text-center"><i class="fas fa-qrcode me-2 text-primary"></i> Thanh Toán Qua QR Code</h4>
                            
                            <div class="row align-items-center">
                                <div class="col-md-6 text-center">
                                    <img src="<?php echo $qr_image_url; ?>" 
                                         alt="QR Code Thanh Toán" 
                                         class="img-fluid rounded"
                                         style="max-width: 280px;">
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="alert alert-info">
                                        <h6><i class="fas fa-university me-2"></i> Thông tin chuyển khoản:</h6>
                                        <table class="table table-sm table-borderless mb-0">
                                            <tr>
                                                <td width="120"><small>Ngân hàng:</small></td>
                                                <td><strong><?php echo $bank_config['bank_name']; ?></strong></td>
                                            </tr>
                                            <tr>
                                                <td><small>Số TK:</small></td>
                                                <td><strong><?php echo $bank_config['account_number']; ?></strong></td>
                                            </tr>
                                            <tr>
                                                <td><small>Chủ TK:</small></td>
                                                <td><strong><?php echo $bank_config['account_name']; ?></strong></td>
                                            </tr>
                                            <tr>
                                                <td><small>Nội dung:</small></td>
                                                <td><strong>HKT<?php echo $booking_info['booking_id']; ?></strong></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <!-- CHECK-OUT FORM -->
                        <div class="checkout-box">
                            <h4 class="mb-3"><i class="fas fa-door-closed me-2"></i> Xác Nhận Thanh Toán & Check-out</h4>
                            <p class="mb-4">Sau khi khách đã thanh toán, nhấn nút bên dưới để hoàn tất check-out:</p>
                            
                            <form method="POST" action="" onsubmit="return confirmCheckout()">
                                <input type="hidden" name="booking_id" value="<?php echo $booking_info['booking_id']; ?>">
                                <button type="submit" name="checkout" value="1" class="btn btn-checkout">
                                    <i class="fas fa-check-circle me-2"></i> Xác Nhận Đã Thanh Toán & Check-out
                                </button>
                            </form>
                        </div>
                    
                    <!-- TRẠNG THÁI: ĐÃ CHECK-OUT -->
                    <?php elseif ($booking_info['status'] === 'checked_out'): ?>
                        <div class="alert-success-custom">
                            <div class="text-center py-4">
                                <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                                <h4>Đã hoàn tất thanh toán và check-out</h4>
                                <p class="mb-2">Booking #<?php echo $booking_info['booking_id']; ?> đã được xử lý xong.</p>
                                <p class="mb-0">
                                    Phòng <strong><?php echo $booking_info['room_number']; ?></strong> đã sẵn sàng cho đặt phòng mới.
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <!-- THÔNG TIN CHI TIẾT -->
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <div class="card info-card h-100">
                                <div class="card-header">
                                    <h6 class="mb-0"><i class="fas fa-user me-2"></i> Thông tin khách hàng</h6>
                                </div>
                                <div class="card-body">
                                    <p class="mb-2">
                                        <strong>Tên:</strong><br>
                                        <?php echo htmlspecialchars($booking_info['customer_name']); ?>
                                    </p>
                                    <p class="mb-2">
                                        <strong>SĐT:</strong><br>
                                        <?php echo htmlspecialchars($booking_info['customer_phone']); ?>
                                    </p>
                                    <p class="mb-2">
                                        <strong>Email:</strong><br>
                                        <?php echo htmlspecialchars($booking_info['customer_email'] ?? 'N/A'); ?>
                                    </p>
                                    <?php if (isset($booking_info['created_at'])): ?>
                                    <p class="mb-0">
                                        <strong>Ngày đặt:</strong><br>
                                        <?php echo date('d/m/Y H:i', strtotime($booking_info['created_at'])); ?>
                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card info-card h-100">
                                <div class="card-header">
                                    <h6 class="mb-0"><i class="fas fa-calendar-alt me-2"></i> Thông tin lưu trú</h6>
                                </div>
                                <div class="card-body">
                                    <p class="mb-2">
                                        <strong>Check-in:</strong><br>
                                        <?php echo date('d/m/Y', strtotime($booking_info['check_in'])); ?>
                                    </p>
                                    <p class="mb-2">
                                        <strong>Check-out:</strong><br>
                                        <?php echo date('d/m/Y', strtotime($booking_info['check_out'])); ?>
                                    </p>
                                    <p class="mb-2">
                                        <strong>Phòng:</strong><br>
                                        <?php echo htmlspecialchars($booking_info['room_number']); ?>
                                    </p>
                                    <p class="mb-0">
                                        <strong>Loại phòng:</strong><br>
                                        <?php echo htmlspecialchars($booking_info['room_type']); ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- NÚT ĐIỀU KHIỂN -->
                    <div class="text-center mt-4 pt-3 border-top">
                        <a href="index.php?page=bookings" class="btn btn-primary me-2 mb-2">
                            <i class="fas fa-list me-2"></i> Danh sách booking
                        </a>
                        <?php if ($booking_info['status'] === 'checked_in'): ?>
                            <button class="btn btn-outline-warning me-2 mb-2" onclick="window.print()">
                                <i class="fas fa-print me-2"></i> In QR thanh toán
                            </button>
                        <?php endif; ?>
                        <a href="index.php?page=payments/history" class="btn btn-outline-success me-2 mb-2">
                            <i class="fas fa-history me-2"></i> Lịch sử thanh toán
                        </a>
                    </div>
                    
                <?php else: ?>
                    <!-- KHÔNG CÓ BOOKING -->
                    <div class="text-center py-5">
                        <i class="fas fa-search fa-3x text-muted mb-4"></i>
                        <h3 class="text-muted mb-3">Chưa chọn đơn đặt phòng</h3>
                        <p class="text-muted mb-4">Vui lòng chọn booking từ danh sách để xử lý check-in/check-out</p>
                        <a href="index.php?page=bookings" class="btn btn-primary">
                            <i class="fas fa-calendar-check me-2"></i> Đến trang quản lý booking
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
    function confirmCheckin() {
        return confirm('⚠️ XÁC NHẬN CHECK-IN\n\nBạn có chắc chắn khách hàng đã đến và muốn check-in?\n\nBooking #<?php echo $booking_info['booking_id'] ?? ''; ?>\nPhòng: <?php echo $booking_info['room_number'] ?? ''; ?>\nKhách: <?php echo $booking_info['customer_name'] ?? ''; ?>');
    }
    
    function confirmCheckout() {
        return confirm('⚠️ XÁC NHẬN CHECK-OUT\n\nBạn có chắc chắn khách hàng đã thanh toán và muốn check-out?\n\nBooking #<?php echo $booking_info['booking_id'] ?? ''; ?>\nTổng tiền: <?php echo number_format($booking_info['total_amount'] ?? 0, 0, ",", "."); ?> ₫\n\nSau khi xác nhận:\n• Booking chuyển "Đã trả phòng"\n• Phòng được giải phóng\n• Ghi nhận thanh toán');
    }
    
    // Tự động refresh sau 60 giây nếu đang ở trạng thái checked_in
    <?php if ($booking_info && $booking_info['status'] === 'checked_in'): ?>
    setTimeout(function() {
        window.location.reload();
    }, 60000);
    <?php endif; ?>
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>