<?php
// views/guests/list.php - Quản lý khách hàng
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Khách hàng - Hotel Huytking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1 class="mb-4">
            <i class="fas fa-users"></i> Quản lý Khách hàng
        </h1>
        
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i> Trang quản lý khách hàng sẽ hiển thị ở đây
        </div>
        
        <a href="<?php echo BASE_URL; ?>/?page=home" class="btn btn-primary">
            <i class="fas fa-home"></i> Trở về trang chủ
        </a>
    </div>
</body>
</html><?php
// views/guests/list.php - Quản lý khách hàng
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Khách hàng - Hotel Huytking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1 class="mb-4">
            <i class="fas fa-users"></i> Quản lý Khách hàng
        </h1>
        
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i> Trang quản lý khách hàng sẽ hiển thị ở đây
        </div>
        
        <a href="<?php echo BASE_URL; ?>/?page=home" class="btn btn-primary">
            <i class="fas fa-home"></i> Trở về trang chủ
        </a>
    </div>
</body>
</html>