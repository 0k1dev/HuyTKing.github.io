<?php
// config/config.php

// Đặt session settings TRƯỚC khi start session
// ini_set('session.cookie_httponly', 1);
// ini_set('session.use_only_cookies', 1);
// ini_set('session.cookie_secure', 0); // Set to 1 for HTTPS

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database configuration
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'hotel_huytking');  // Đổi thành database của bạn
define('DB_USER', 'root');
define('DB_PASS', '');

// Application settings
define('APP_NAME', 'Hotel HKT Management');
define('APP_VERSION', '1.0.0');
define('TIMEZONE', 'Asia/Ho_Chi_Minh');
if (!defined('BASE_URL')) {
    define('BASE_URL', 'http://127.0.0.1/hotel-HKT/');}

// Payment settings
define('VIETQR_API_KEY', 'your_api_key_here');
define('VIETQR_API_URL', 'https://api.vietqr.io/v2/generate');

// Set timezone
date_default_timezone_set(TIMEZONE);

// Simple autoload
spl_autoload_register(function ($class) {
    $directories = ['models/', 'controllers/', 'config/'];
    
    foreach ($directories as $directory) {
        $file = __DIR__ . '/../' . $directory . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// Include database connection
require_once 'database.php';
?>