<?php
// hotel-HKT/config/database.php

$host = '127.0.0.1';
$dbname = 'hotel_huytking';  // Tên database của bạn
$username = 'root';          // Mặc định XAMPP
$password = '';              // Mặc định XAMPP (để trống)

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Test connection
    // echo "<div style='background:#d4edda; padding:10px; margin:10px; border-radius:5px;'>
    //       <i class='fas fa-check-circle'></i> ✅ Kết nối database thành công!
    //       </div>";
    
} catch (PDOException $e) {
    // Nếu lỗi, tạo biến $pdo để tránh lỗi undefined
    $pdo = null;
    
    // Hiển thị lỗi chi tiết
    $error_message = "❌ Lỗi kết nối database: " . $e->getMessage();
    $error_message .= "<br><strong>Thông tin kết nối:</strong>";
    $error_message .= "<br>- Host: $host";
    $error_message .= "<br>- Database: $dbname";
    $error_message .= "<br>- Username: $username";
    
    // Chỉ hiển thị lỗi nếu đang debug
    if (isset($debug_mode) && $debug_mode) {
        echo "<div style='background:#f8d7da; padding:15px; margin:10px; border-radius:5px;'>
              $error_message
              <br><small>Chương trình sẽ dùng dữ liệu mẫu để tiếp tục.</small>
              </div>";
    }
}
?>