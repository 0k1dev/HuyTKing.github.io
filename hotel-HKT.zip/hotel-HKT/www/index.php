<?php
// hotel-HKT/index.php - Front Controller
session_start();

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Define base paths
define('BASE_URL', 'http://' . $_SERVER['HTTP_HOST'] . '/hotel-HKT');
define('BASE_PATH', __DIR__ . '/');

// Debug mode
$debug_mode = false;

if ($debug_mode) {
    echo '<div style="background:#f0f0f0; padding:10px; margin:10px; border:1px solid #ccc;">';
    echo '<strong>DEBUG INFO:</strong><br>';
    echo 'Request URI: ' . $_SERVER['REQUEST_URI'] . '<br>';
    echo 'GET params: ' . print_r($_GET, true) . '<br>';
}

// Load configuration
$config_file = 'config/config.php';
if (file_exists(BASE_PATH . $config_file)) {
    require_once BASE_PATH . $config_file;
    if ($debug_mode) echo 'Config loaded<br>';
}

// ===== FIXED ROUTING - XỬ LÝ QUERY STRING =====
$request = $_SERVER['REQUEST_URI'];

// Remove base path
$request = str_replace('/hotel-HKT', '', $request);

// Parse URL để lấy cả path và query
$parsed_url = parse_url($request);
$path = isset($parsed_url['path']) ? trim($parsed_url['path'], '/') : '';
$query = isset($parsed_url['query']) ? $parsed_url['query'] : '';

if ($debug_mode) {
    echo 'Path: ' . ($path ?: '(empty)') . '<br>';
    echo 'Query: ' . ($query ?: '(none)') . '<br>';
}

// Xử lý query string nếu có ?page=...
if ($query) {
    parse_str($query, $query_params);
    if (isset($query_params['page'])) {
        $path = $query_params['page']; // Ưu tiên ?page=...
        if ($debug_mode) echo 'Using page from query: ' . $path . '<br>';
    }
}

// Nếu vẫn không có path, mặc định là home
if (empty($path)) {
    $path = 'home';
    if ($debug_mode) echo 'Defaulting to: ' . $path . '<br>';
}

$request = $path; // Dùng path đã xử lý

// Route mapping
$routes = [
    '' => 'views/index.php',
    'home' => 'views/index.php',
    'rooms' => 'views/rooms/list.php',
    'rooms/detail' => 'views/rooms/detail.php',
    'bookings' => 'views/bookings/list.php',
    'bookings/create' => 'views/bookings/create.php',
    'bookings/checkin' => 'views/bookings/checkin.php',
    'payments/qr' => 'views/payments/qr-generator.php',
    'payments/history' => 'views/payments/history.php',
    'api/rooms' => 'api/rooms.php',
    'api/bookings' => 'api/bookings.php',
    'api/payments' => 'api/payments.php',
];

if ($debug_mode) {
    echo 'Final request: ' . $request . '<br>';
    echo 'Available routes: ' . implode(', ', array_keys($routes)) . '<br>';
}

// Check if route exists
if (isset($routes[$request])) {
    $file = $routes[$request];
    
    if ($debug_mode) {
        echo 'Route found: ' . $request . ' => ' . $file . '<br>';
        echo 'Full path: ' . BASE_PATH . $file . '<br>';
        echo 'File exists: ' . (file_exists(BASE_PATH . $file) ? 'YES' : 'NO') . '<br>';
    }
    
    // Check if it's an API request
    if (strpos($file, 'api/') === 0) {
        if (file_exists(BASE_PATH . $file)) {
            if ($debug_mode) echo 'Loading API: ' . $file . '<br>';
            require_once BASE_PATH . $file;
        } else {
            if ($debug_mode) echo 'API file not found<br>';
            http_response_code(404);
            echo "<h1>API Not Found</h1><p>File: $file</p>";
        }
    } else {
        // Regular view
        if (file_exists(BASE_PATH . $file)) {
            if ($debug_mode) echo 'Loading view: ' . $file . '<br>';
            require_once BASE_PATH . $file;
        } else {
            if ($debug_mode) echo 'View file not found<br>';
            http_response_code(404);
            echo "<h1>View Not Found</h1>";
            echo "<p>File: " . htmlspecialchars($file) . "</p>";
            echo "<p>Searching in: " . BASE_PATH . "</p>";
        }
    }
} else {
    if ($debug_mode) {
        echo 'Route not found in mapping<br>';
        echo 'Trying direct file access...<br>';
    }
    
    // Check if it's a direct file request
    $file_path = BASE_PATH . $request;
    if ($debug_mode) {
        echo 'Checking direct file: ' . $file_path . '<br>';
        echo 'File exists: ' . (file_exists($file_path) ? 'YES' : 'NO') . '<br>';
    }
    
    if (file_exists($file_path) && is_file($file_path)) {
        if ($debug_mode) echo 'Loading direct file<br>';
        require_once $file_path;
    } else {
        if ($debug_mode) echo 'File not found, showing 404<br>';
        
        // 404 Not Found
        http_response_code(404);
        
        // Check if 404 page exists
        $error_404 = 'views/errors/404.php';
        if (file_exists(BASE_PATH . $error_404)) {
            include BASE_PATH . $error_404;
        } else {
            echo "<h1>404 - Page Not Found</h1>";
            echo "<p>Requested page: " . htmlspecialchars($request) . "</p>";
            echo "<p>Available routes:</p><ul>";
            foreach ($routes as $route => $file) {
                echo "<li><a href='" . BASE_URL . "/?page=$route'>$route</a></li>";
            }
            echo "</ul>";
        }
    }
}

if ($debug_mode) {
    echo '</div>';
}
?>