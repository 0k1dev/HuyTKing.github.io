<?php
// api/payments.php

require_once '../config/database.php';
require_once '../models/Payment.php';
require_once '../models/Booking.php';

header('Content-Type: application/json');

// Xử lý CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

$database = new Database();
$conn = $database->getConnection();
$paymentModel = new Payment();
$bookingModel = new Booking();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// Xử lý request
switch ($method) {
    case 'GET':
        handleGetRequest($action);
        break;
        
    case 'POST':
        handlePostRequest($action);
        break;
        
    case 'PUT':
        handlePutRequest($action);
        break;
        
    case 'DELETE':
        handleDeleteRequest($action);
        break;
        
    default:
        echo jsonResponse(false, 'Method not allowed', null, 405);
}

// ====== FUNCTIONS ======

function handleGetRequest($action) {
    global $paymentModel, $bookingModel;
    
    switch ($action) {
        case 'get_all':
            $payments = $paymentModel->getAllPayments();
            echo jsonResponse(true, 'Payments retrieved', $payments);
            break;
            
        case 'get_with_details':
            $payments = $paymentModel->getPaymentsWithBookingInfo();
            echo jsonResponse(true, 'Payments with details retrieved', $payments);
            break;
            
        case 'get_by_id':
            $id = $_GET['id'] ?? 0;
            if ($id) {
                // Cần tạo method này trong Payment model
                $payment = getPaymentById($id);
                if ($payment) {
                    echo jsonResponse(true, 'Payment found', $payment);
                } else {
                    echo jsonResponse(false, 'Payment not found');
                }
            } else {
                echo jsonResponse(false, 'Payment ID is required');
            }
            break;
            
        case 'get_by_booking':
            $bookingId = $_GET['booking_id'] ?? 0;
            if ($bookingId) {
                $payments = getPaymentsByBookingId($bookingId);
                echo jsonResponse(true, 'Payments for booking retrieved', $payments);
            } else {
                echo jsonResponse(false, 'Booking ID is required');
            }
            break;
            
        case 'get_stats':
            $stats = [
                'total_payments' => 0,
                'total_amount' => 0,
                'by_method' => [],
                'by_status' => []
            ];
            
            // Lấy thống kê
            $allPayments = $paymentModel->getAllPayments();
            $stats['total_payments'] = count($allPayments);
            
            foreach ($allPayments as $payment) {
                $stats['total_amount'] += (float)($payment['amount'] ?? 0);
                
                // Thống kê theo phương thức
                $method = $payment['payment_method'] ?? 'Unknown';
                if (!isset($stats['by_method'][$method])) {
                    $stats['by_method'][$method] = 0;
                }
                $stats['by_method'][$method]++;
                
                // Thống kê theo trạng thái
                $status = $payment['status'] ?? 'Unknown';
                if (!isset($stats['by_status'][$status])) {
                    $stats['by_status'][$status] = 0;
                }
                $stats['by_status'][$status]++;
            }
            
            echo jsonResponse(true, 'Statistics retrieved', $stats);
            break;
            
        default:
            echo jsonResponse(false, 'Invalid action');
    }
}

function handlePostRequest($action) {
    global $conn;
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    switch ($action) {
        case 'create':
            if (validatePaymentData($data)) {
                $result = createPayment($data);
                if ($result) {
                    echo jsonResponse(true, 'Payment created successfully', ['payment_id' => $result]);
                } else {
                    echo jsonResponse(false, 'Failed to create payment');
                }
            } else {
                echo jsonResponse(false, 'Invalid payment data');
            }
            break;
            
        case 'process':
            // Xử lý thanh toán
            if (isset($data['booking_id']) && isset($data['amount'])) {
                $result = processPayment($data);
                echo jsonResponse($result['success'], $result['message'], $result['data'] ?? null);
            } else {
                echo jsonResponse(false, 'Missing required fields');
            }
            break;
            
        default:
            echo jsonResponse(false, 'Invalid action');
    }
}

function handlePutRequest($action) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $_GET['id'] ?? 0;
    
    switch ($action) {
        case 'update':
            if ($id && validatePaymentData($data, true)) {
                $result = updatePayment($id, $data);
                echo jsonResponse($result, $result ? 'Payment updated' : 'Update failed');
            } else {
                echo jsonResponse(false, 'Invalid data or ID');
            }
            break;
            
        case 'update_status':
            if ($id && isset($data['status'])) {
                $result = updatePaymentStatus($id, $data['status']);
                echo jsonResponse($result, $result ? 'Status updated' : 'Update failed');
            } else {
                echo jsonResponse(false, 'Missing status or ID');
            }
            break;
            
        default:
            echo jsonResponse(false, 'Invalid action');
    }
}

function handleDeleteRequest($action) {
    $id = $_GET['id'] ?? 0;
    
    switch ($action) {
        case 'delete':
            if ($id) {
                $result = deletePayment($id);
                echo jsonResponse($result, $result ? 'Payment deleted' : 'Delete failed');
            } else {
                echo jsonResponse(false, 'Payment ID is required');
            }
            break;
            
        default:
            echo jsonResponse(false, 'Invalid action');
    }
}

// ====== HELPER FUNCTIONS ======

function jsonResponse($success, $message, $data = null, $statusCode = 200) {
    http_response_code($statusCode);
    return json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}

function validatePaymentData($data, $isUpdate = false) {
    $required = ['booking_id', 'amount', 'payment_method'];
    
    if ($isUpdate) {
        // Khi update, không bắt buộc tất cả fields
        return true;
    }
    
    foreach ($required as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            return false;
        }
    }
    
    return true;
}

function getPaymentById($id) {
    global $conn;
    
    try {
        $query = "SELECT p.*, b.customer_name, b.customer_phone 
                  FROM payments p 
                  LEFT JOIN bookings b ON p.booking_id = b.booking_id 
                  WHERE p.payment_id = :id";
        
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting payment: " . $e->getMessage());
        return null;
    }
}

function getPaymentsByBookingId($bookingId) {
    global $conn;
    
    try {
        $query = "SELECT * FROM payments WHERE booking_id = :booking_id ORDER BY payment_date DESC";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':booking_id', $bookingId, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting payments by booking: " . $e->getMessage());
        return [];
    }
}

function createPayment($data) {
    global $conn;
    
    try {
        $query = "INSERT INTO payments (booking_id, amount, payment_method, payment_date, status) 
                  VALUES (:booking_id, :amount, :payment_method, NOW(), :status)";
        
        $stmt = $conn->prepare($query);
        
        $status = $data['status'] ?? 'pending';
        
        $stmt->bindParam(':booking_id', $data['booking_id'], PDO::PARAM_INT);
        $stmt->bindParam(':amount', $data['amount']);
        $stmt->bindParam(':payment_method', $data['payment_method']);
        $stmt->bindParam(':status', $status);
        
        if ($stmt->execute()) {
            return $conn->lastInsertId();
        }
        
        return false;
    } catch (PDOException $e) {
        error_log("Error creating payment: " . $e->getMessage());
        return false;
    }
}

function processPayment($data) {
    global $conn;
    
    try {
        // Bắt đầu transaction
        $conn->beginTransaction();
        
        // 1. Tạo payment record
        $paymentQuery = "INSERT INTO payments (booking_id, amount, payment_method, payment_date, status) 
                         VALUES (:booking_id, :amount, :payment_method, NOW(), 'completed')";
        
        $paymentStmt = $conn->prepare($paymentQuery);
        $paymentStmt->bindParam(':booking_id', $data['booking_id'], PDO::PARAM_INT);
        $paymentStmt->bindParam(':amount', $data['amount']);
        $paymentStmt->bindParam(':payment_method', $data['payment_method']);
        
        if (!$paymentStmt->execute()) {
            throw new Exception("Failed to create payment");
        }
        
        $paymentId = $conn->lastInsertId();
        
        // 2. Cập nhật trạng thái booking thành "paid" hoặc "confirmed"
        $bookingQuery = "UPDATE bookings SET status = 'confirmed' WHERE booking_id = :booking_id";
        $bookingStmt = $conn->prepare($bookingQuery);
        $bookingStmt->bindParam(':booking_id', $data['booking_id'], PDO::PARAM_INT);
        
        if (!$bookingStmt->execute()) {
            throw new Exception("Failed to update booking status");
        }
        
        // 3. Commit transaction
        $conn->commit();
        
        return [
            'success' => true,
            'message' => 'Payment processed successfully',
            'data' => ['payment_id' => $paymentId]
        ];
        
    } catch (Exception $e) {
        $conn->rollBack();
        error_log("Payment processing error: " . $e->getMessage());
        
        return [
            'success' => false,
            'message' => 'Payment processing failed: ' . $e->getMessage()
        ];
    }
}

function updatePayment($id, $data) {
    global $conn;
    
    try {
        $fields = [];
        $params = [':id' => $id];
        
        if (isset($data['amount'])) {
            $fields[] = 'amount = :amount';
            $params[':amount'] = $data['amount'];
        }
        
        if (isset($data['payment_method'])) {
            $fields[] = 'payment_method = :payment_method';
            $params[':payment_method'] = $data['payment_method'];
        }
        
        if (isset($data['status'])) {
            $fields[] = 'status = :status';
            $params[':status'] = $data['status'];
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $query = "UPDATE payments SET " . implode(', ', $fields) . " WHERE payment_id = :id";
        $stmt = $conn->prepare($query);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        return $stmt->execute();
        
    } catch (PDOException $e) {
        error_log("Error updating payment: " . $e->getMessage());
        return false;
    }
}

function updatePaymentStatus($id, $status) {
    global $conn;
    
    try {
        $query = "UPDATE payments SET status = :status WHERE payment_id = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        
        return $stmt->execute();
    } catch (PDOException $e) {
        error_log("Error updating payment status: " . $e->getMessage());
        return false;
    }
}

function deletePayment($id) {
    global $conn;
    
    try {
        $query = "DELETE FROM payments WHERE payment_id = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        
        return $stmt->execute();
    } catch (PDOException $e) {
        error_log("Error deleting payment: " . $e->getMessage());
        return false;
    }
}