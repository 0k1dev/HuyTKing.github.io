<?php
// api/get_rooms.php - SỬA LỖI
header('Content-Type: application/json; charset=utf-8');

// Bật error reporting nhưng không hiển thị
error_reporting(0);
ini_set('display_errors', 0);

try {
    // Kết nối database TRỰC TIẾP (không dùng config.php nếu có lỗi)
    $host = 'localhost';
    $dbname = 'hotel_huytking';
    $username = 'root';
    $password = '';
    
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    
    // Test kết nối
    $pdo->query("SELECT 1")->fetch();
    
    // Lấy tham số filter
    $floor = $_GET['floor'] ?? '';
    $type = $_GET['type'] ?? '';
    $status = $_GET['status'] ?? '';
    
    // Xây dựng query
    $sql = "SELECT * FROM rooms WHERE 1=1";
    $params = [];
    
    if (!empty($floor)) {
        $sql .= " AND (floor_code = ? OR floor_number = ?)";
        $params[] = $floor;
        $params[] = (int)$floor;
    }
    
    if (!empty($type)) {
        $sql .= " AND room_type LIKE ?";
        $params[] = "%$type%";
    }
    
    if (!empty($status)) {
        $sql .= " AND status = ?";
        $params[] = $status;
    }
    
    $sql .= " ORDER BY room_number";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rooms = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'data' => $rooms,
        'count' => count($rooms),
        'message' => 'Success'
    ], JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error',
        'error' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Server error',
        'error' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

exit;