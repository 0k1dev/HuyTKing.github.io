<?php
// 1. Tắt hiển thị lỗi HTML (Cực kỳ quan trọng để ngăn lỗi SyntaxError)
ini_set('display_errors', 0);
error_reporting(0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Khối Try/Catch bao bọc tất cả để xử lý lỗi Fatal/Exception
try {
    // PHẢI đảm bảo đường dẫn này đúng. Nếu sai, nó sẽ gây ra Fatal Error.
    require_once '../controllers/PaymentController.php';

    $paymentController = new PaymentController();
    $action = $_GET['action'] ?? '';
    $response = ['success' => false, 'message' => 'Invalid action']; // Khởi tạo response mặc định

    switch($action) {
        case 'list':
            $status = $_GET['status'] ?? null;
            $payments = $paymentController->getAllPayments($status);
            // Giả định $payments là một array/object.
            $response = ['success' => true, 'data' => $payments]; 
            break;
            
        case 'get':
            $paymentId = $_GET['payment_id'] ?? null;
            if (!$paymentId) {
                 $response = ['success' => false, 'message' => 'Thiếu ID thanh toán.'];
                 break;
            }
            // Giả định getPaymentById trả về object hoặc array có success và data/message
            $response = $paymentController->getPaymentById($paymentId); 
            break;
            
        case 'confirm':
            $paymentId = $_POST['payment_id'] ?? null;
            if (!$paymentId) {
                 $response = ['success' => false, 'message' => 'Thiếu ID thanh toán để xác nhận.'];
                 break;
            }
            $response = $paymentController->confirmPayment($paymentId);
            break;
            
        case 'create':
            $bookingId = $_POST['booking_id'] ?? null;
            $amount = $_POST['amount'] ?? null;
            
            // Xử lý kiểm tra dữ liệu đầu vào cơ bản
            if (!$bookingId || !$amount) {
                 $response = ['success' => false, 'message' => 'Thiếu dữ liệu bắt buộc (Booking ID hoặc Amount).'];
                 break;
            }

            $description = $_POST['description'] ?? '';
            $response = $paymentController->createPayment($bookingId, $amount, $description);
            break;
            
        default:
            // Đã được khởi tạo mặc định là 'Invalid action'
            break;
    }
    
    // Chỉ ECHO một lần duy nhất
    echo json_encode($response);

} catch (Throwable $e) {
    // Bắt mọi lỗi/exception (bao gồm cả Fatal Error trong PHP 7+)
    http_response_code(500);
    // Luôn trả về JSON lỗi, không bao giờ trả về HTML
    echo json_encode([
        'success' => false,
        'message' => 'Lỗi Server không mong muốn. Chi tiết được ghi log.',
        'error_detail' => $e->getMessage() // Chỉ nên dùng khi phát triển
    ]);
}
// KHÔNG CÓ THẺ ĐÓNG PHP