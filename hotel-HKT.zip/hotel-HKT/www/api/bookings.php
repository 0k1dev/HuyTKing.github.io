<?php
// api/bookings.php - Phiên bản test
header('Content-Type: application/json; charset=utf-8');

// Log for debugging
$log = [
    'timestamp' => date('Y-m-d H:i:s'),
    'method' => $_SERVER['REQUEST_METHOD'],
    'uri' => $_SERVER['REQUEST_URI'],
    'get' => $_GET,
    'post' => $_POST
];

error_log(print_r($log, true));

try {
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'list':
            echo json_encode([
                'success' => true,
                'message' => 'List action working',
                'data' => [
                    ['id' => 1, 'room' => '101', 'guest' => 'Test Guest 1'],
                    ['id' => 2, 'room' => '102', 'guest' => 'Test Guest 2']
                ]
            ]);
            break;
            
        case 'detail':
            $id = $_GET['id'] ?? 0;
            echo json_encode([
                'success' => true,
                'message' => "Detail for booking $id",
                'data' => ['id' => $id, 'status' => 'confirmed']
            ]);
            break;
            
        case 'checkin':
        case 'checkout':
        case 'cancel':
            // For POST requests
            $input = json_decode(file_get_contents('php://input'), true);
            echo json_encode([
                'success' => true,
                'message' => "$action action received",
                'received_data' => $input
            ]);
            break;
            
        default:
            echo json_encode([
                'success' => false,
                'message' => 'Invalid action: ' . $action,
                'available_actions' => ['list', 'detail', 'checkin', 'checkout', 'cancel'],
                'debug' => $log
            ]);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>