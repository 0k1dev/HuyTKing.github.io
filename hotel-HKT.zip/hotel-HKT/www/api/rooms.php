<?php
// api/rooms.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Xử lý CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// ===== FIX 1: KIỂM TRA DATABASE CONNECTION =====
$pdo = null;

try {
    // Kết nối database - THAY ĐỔI THÔNG SỐ NÀY CHO ĐÚNG
    $host = '127.0.0.1';
    $dbname = 'hotel_huytking';  // Tên database của bạn
    $username = 'root';     // Username XAMPP mặc định
    $password = '';         // Password XAMPP mặc định (để trống)
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    // Nếu kết nối thất bại, trả về lỗi
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed: ' . $e->getMessage(),
        'debug' => [
            'host' => $host,
            'dbname' => $dbname,
            'username' => $username
        ]
    ]);
    exit;
}

// ===== XỬ LÝ ACTION =====
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'get_rooms':
        getRooms($pdo);
        break;
    case 'detail':
        getRoomDetail($pdo);
        break;
    default:
        echo json_encode([
            'success' => false,
            'message' => 'Invalid action. Available actions: get_rooms, detail'
        ]);
        break;
}

// ===== HÀM LẤY DANH SÁCH PHÒNG =====
function getRooms($pdo) {
    // Lấy filter từ request
    $floor = $_GET['floor'] ?? '';
    $type = $_GET['type'] ?? '';
    $status = $_GET['status'] ?? '';
    
    // Xây dựng query
    $sql = "SELECT * FROM rooms WHERE 1=1";
    $params = [];
    
    if ($floor) {
        $sql .= " AND floor_code = ?";
        $params[] = $floor;
    }
    
    if ($type) {
        $sql .= " AND room_type = ?";
        $params[] = $type;
    }
    
    if ($status) {
        $sql .= " AND status = ?";
        $params[] = $status;
    }
    
    $sql .= " ORDER BY room_number";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rooms = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'count' => count($rooms),
            'data' => $rooms
        ]);
        
    } catch (PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Query error: ' . $e->getMessage(),
            'sql' => $sql,
            'params' => $params
        ]);
    }
}

// ===== HÀM LẤY CHI TIẾT PHÒNG =====
function getRoomDetail($pdo) {
    $id = $_GET['id'] ?? 0;
    
    if (!$id) {
        echo json_encode([
            'success' => false,
            'message' => 'Missing room ID'
        ]);
        return;
    }
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM rooms WHERE room_id = ?");
        $stmt->execute([$id]);
        $room = $stmt->fetch();
        
        if ($room) {
            echo json_encode([
                'success' => true,
                'data' => $room
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Room not found'
            ]);
        }
    } catch (PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}
?>