<?php
// models/Guest.php

class Guest {
    private $conn;
    private $table = 'guests';

    public function __construct() {
        require_once __DIR__ . '/../config/database.php';
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAllGuests() {
        try {
            $query = "SELECT * FROM " . $this->table . " ORDER BY created_at DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Guest Error: " . $e->getMessage());
            return [];
        }
    }

    public function getGuestById($id) {
        try {
            $query = "SELECT * FROM " . $this->table . " WHERE guest_id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Guest Error: " . $e->getMessage());
            return null;
        }
    }

    public function createGuest($data) {
        try {
            $query = "INSERT INTO " . $this->table . " 
                     (name, full_name, email, phone, address, id_card) 
                     VALUES (:name, :full_name, :email, :phone, :address, :id_card)";
            
            $stmt = $this->conn->prepare($query);
            return $stmt->execute($data);
        } catch(PDOException $e) {
            error_log("Guest Create Error: " . $e->getMessage());
            return false;
        }
    }
}