<?php
// models/Payment.php

class Payment {
    private $conn;
    private $table = 'payments';

    public function __construct() {
        require_once __DIR__ . '/../config/database.php';
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAllPayments() {
        try {
            $query = "SELECT * FROM " . $this->table . " ORDER BY payment_date DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Payment Error: " . $e->getMessage());
            return [];
        }
    }

    // Lấy thanh toán với thông tin booking
    public function getPaymentsWithBookingInfo() {
        try {
            $query = "SELECT 
                        p.*,
                        b.booking_id,
                        b.customer_name,
                        b.customer_phone,
                        r.room_number
                      FROM payments p
                      LEFT JOIN bookings b ON p.booking_id = b.booking_id
                      LEFT JOIN rooms r ON b.room_id = r.room_id
                      ORDER BY p.payment_date DESC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Payment Error: " . $e->getMessage());
            return [];
        }
    }
}