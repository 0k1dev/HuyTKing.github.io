<?php
// models/Booking.php

class Booking {
    private $conn;
    private $table = 'bookings';

    public function __construct() {
        require_once __DIR__ . '/../config/database.php';
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAllBookings() {
        try {
            $query = "SELECT * FROM " . $this->table . " ORDER BY created_at DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Booking Error: " . $e->getMessage());
            return [];
        }
    }

    // Lấy booking với thông tin chi tiết từ guests và rooms
    public function getBookingsWithDetails() {
        try {
            $query = "SELECT 
                        b.*,
                        g.full_name as guest_full_name,
                        g.email as guest_email,
                        g.phone as guest_phone,
                        r.room_number,
                        r.room_type,
                        r.base_price
                      FROM bookings b
                      LEFT JOIN guests g ON b.guest_id = g.guest_id
                      LEFT JOIN rooms r ON b.room_id = r.room_id
                      ORDER BY b.created_at DESC";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Booking Error: " . $e->getMessage());
            return [];
        }
    }

    public function getBookingById($id) {
        try {
            $query = "SELECT 
                        b.*,
                        g.full_name as guest_full_name,
                        g.email as guest_email,
                        g.phone as guest_phone,
                        g.address as guest_address,
                        g.id_card as guest_id_card,
                        r.room_number,
                        r.room_type,
                        r.base_price,
                        r.floor_number,
                        r.bed_type,
                        r.max_guests
                      FROM bookings b
                      LEFT JOIN guests g ON b.guest_id = g.guest_id
                      LEFT JOIN rooms r ON b.room_id = r.room_id
                      WHERE b.booking_id = :id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Booking Error: " . $e->getMessage());
            return null;
        }
    }

    public function createBooking($data) {
        try {
            $query = "INSERT INTO " . $this->table . " 
                     (guest_id, room_id, customer_name, customer_email, customer_phone, 
                      check_in_date, check_in, check_out_date, check_out, status) 
                     VALUES (:guest_id, :room_id, :customer_name, :customer_email, :customer_phone, 
                             :check_in_date, :check_in, :check_out_date, :check_out, :status)";
            
            $stmt = $this->conn->prepare($query);
            return $stmt->execute($data);
        } catch(PDOException $e) {
            error_log("Booking Create Error: " . $e->getMessage());
            return false;
        }
    }

    // Cập nhật trạng thái booking
    public function updateBookingStatus($id, $status) {
        try {
            $query = "UPDATE " . $this->table . " SET status = :status WHERE booking_id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':status', $status);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            return $stmt->execute();
        } catch(PDOException $e) {
            error_log("Booking Update Error: " . $e->getMessage());
            return false;
        }
    }

    // Thống kê booking
    public function getBookingStats() {
        try {
            $query = "SELECT 
                        COUNT(*) as total_bookings,
                        SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
                        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
                        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
                      FROM " . $this->table;
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Booking Stats Error: " . $e->getMessage());
            return null;
        }
    }
}