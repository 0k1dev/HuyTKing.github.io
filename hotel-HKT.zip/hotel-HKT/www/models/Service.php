<?php
// models/Service.php
class Service {
    private $conn;
    private $table = 'room_services';
    
    public function __construct() {
        $this->conn = Database::getInstance();
    }
    
    public function orderService($data) {
        $query = "INSERT INTO {$this->table} 
                  (room_id, guest_name, service_type, items, total_amount, status) 
                  VALUES (:room_id, :guest_name, :service_type, :items, :total_amount, 'pending')";
        
        $stmt = $this->conn->prepare($query);
        
        return $stmt->execute([
            ':room_id' => $data['room_id'],
            ':guest_name' => $data['guest_name'],
            ':service_type' => $data['service_type'],
            ':items' => json_encode($data['items']),
            ':total_amount' => $data['total_amount']
        ]);
    }
    
    public function getMenu() {
        $query = "SELECT * FROM services_menu WHERE is_available = 1 ORDER BY category_id, item_name";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function getServicesByRoom($room_id, $limit = 10) {
        $query = "SELECT * FROM {$this->table} 
                  WHERE room_id = :room_id 
                  ORDER BY created_at DESC LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':room_id', $room_id);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function updateStatus($service_id, $status) {
        $query = "UPDATE {$this->table} SET status = :status WHERE id = :service_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':service_id', $service_id);
        return $stmt->execute();
    }
    
    public function getPopularItems($limit = 5) {
        // This is a simplified version - in reality you'd need to parse JSON items
        $query = "SELECT service_type, COUNT(*) as order_count 
                  FROM {$this->table} 
                  WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                  GROUP BY service_type 
                  ORDER BY order_count DESC LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
?>