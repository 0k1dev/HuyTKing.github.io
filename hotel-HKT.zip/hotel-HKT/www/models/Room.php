<?php
// models/Room.php

class Room {
    private $conn;
    private $table = 'rooms';

    public function __construct() {
        require_once __DIR__ . '/../config/database.php';
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Lấy tất cả phòng
    public function getAllRooms() {
        try {
            $query = "SELECT * FROM " . $this->table . " ORDER BY room_number";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Debug: kiểm tra cấu trúc dữ liệu
            if (!empty($result)) {
                error_log("Room Model: Lấy được " . count($result) . " phòng");
                error_log("Cấu trúc dữ liệu mẫu: " . json_encode($result[0]));
            }
            
            return $result;
        } catch(PDOException $e) {
            error_log("Room Error: " . $e->getMessage());
            return [];
        }
    }

    // Lấy phòng theo ID
    public function getRoomById($id) {
        try {
            $query = "SELECT * FROM " . $this->table . " WHERE room_id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Room Error: " . $e->getMessage());
            return null;
        }
    }

    // Lấy phòng còn trống (cần kiểm tra trạng thái)
    public function getAvailableRooms() {
        try {
            // Nếu có cột status
            $query = "SELECT * FROM " . $this->table . " WHERE status = 'available' ORDER BY room_number";
            
            // Nếu không có cột status, lấy tất cả
            // $query = "SELECT * FROM " . $this->table . " ORDER BY room_number";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Room Error: " . $e->getMessage());
            return [];
        }
    }

    // Lấy phòng theo loại
    public function getRoomsByType($type) {
        try {
            $query = "SELECT * FROM " . $this->table . " WHERE room_type = :type ORDER BY room_number";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':type', $type);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Room Error: " . $e->getMessage());
            return [];
        }
    }

    // Tìm kiếm phòng
    public function searchRooms($roomNumber = '', $roomType = '', $minPrice = 0, $maxPrice = 10000000) {
        try {
            $query = "SELECT * FROM " . $this->table . " WHERE 1=1";
            $params = [];
            
            if (!empty($roomNumber)) {
                $query .= " AND room_number LIKE :roomNumber";
                $params[':roomNumber'] = "%$roomNumber%";
            }
            
            if (!empty($roomType)) {
                $query .= " AND room_type = :roomType";
                $params[':roomType'] = $roomType;
            }
            
            $query .= " AND base_price BETWEEN :minPrice AND :maxPrice";
            $params[':minPrice'] = $minPrice;
            $params[':maxPrice'] = $maxPrice;
            
            $query .= " ORDER BY room_number";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Room Error: " . $e->getMessage());
            return [];
        }
    }

    // Thống kê phòng
    public function getRoomStatistics() {
        try {
            $query = "SELECT 
                        COUNT(*) as total_rooms,
                        COUNT(DISTINCT room_type) as room_types,
                        SUM(max_guests) as total_capacity,
                        AVG(base_price) as avg_price,
                        MIN(base_price) as min_price,
                        MAX(base_price) as max_price
                      FROM " . $this->table;
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Room Error: " . $e->getMessage());
            return null;
        }
    }

    // Lấy các loại phòng duy nhất
    public function getUniqueRoomTypes() {
        try {
            $query = "SELECT DISTINCT room_type FROM " . $this->table . " ORDER BY room_type";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
        } catch(PDOException $e) {
            error_log("Room Error: " . $e->getMessage());
            return [];
        }
    }
}