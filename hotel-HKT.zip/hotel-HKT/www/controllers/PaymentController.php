<?php
// Sử dụng __DIR__ để đảm bảo đường dẫn tuyệt đối, giúp tránh lỗi Fatal Error 500
require_once __DIR__ . '/../config/database.php';

class PaymentController {
    private $conn;
    private $table = 'payments';
    private $connectionError = null; // Thêm thuộc tính để lưu trữ lỗi kết nối
    
    // Thông tin tài khoản ngân hàng ACB
    private $bankInfo = [
        'bin' => '970416',
        'account_number' => '43146717', // THAY BẰNG SỐ TÀI KHOẢN THẬT CỦA BẠN
        'account_name' => 'ĐINH TẤN HUY',
        'bank_name' => 'ACB'
    ];
    
    // Hàm khởi tạo an toàn
    public function __construct() {
        try {
            $database = new Database();
            $this->conn = $database->getConnection();

            // Nếu kết nối bị lỗi (getConnection trả về null hoặc false)
            if (!$this->conn) {
                $this->connectionError = "Lỗi: Không thể khởi tạo kết nối Database.";
            }
        } catch (Exception $e) {
            // Bắt lỗi khi khởi tạo Database hoặc kết nối thất bại
            $this->connectionError = "Lỗi kết nối CSDL: " . $e->getMessage();
        }
    }

    /**
     * Kiểm tra và trả về lỗi nếu kết nối thất bại
     * @return array|bool
     */
    private function isConnectionError() {
        if ($this->connectionError) {
            // Trả về response lỗi API thay vì để code chạy và crash
            return ['success' => false, 'message' => $this->connectionError];
        }
        return false;
    }

    // --- CÁC PHƯƠNG THỨC API ---

    // Tạo thanh toán mới với QR code
    public function createPayment($bookingId, $amount, $description = '') {
        $error = $this->isConnectionError();
        if ($error) return $error; // Kiểm tra lỗi kết nối

        try {
            // Kiểm tra booking có tồn tại không
            $checkBooking = "SELECT * FROM bookings WHERE booking_id = :booking_id";
            $stmt = $this->conn->prepare($checkBooking);
            $stmt->bindParam(':booking_id', $bookingId);
            $stmt->execute();
            
            if ($stmt->rowCount() == 0) {
                return ['success' => false, 'message' => 'Booking không tồn tại'];
            }
            
            // Tạo mô tả thanh toán
            if (empty($description)) {
                $description = "Thanh toan booking #" . $bookingId;
            }
            
            // Tạo URL QR code VietQR
            $qrUrl = $this->generateVietQR($amount, $description);
            
            // Lưu vào database
            $query = "INSERT INTO " . $this->table . " 
                     (booking_id, amount, payment_method, payment_status, qr_code_url, description, created_at) 
                     VALUES (:booking_id, :amount, 'bank_transfer', 'pending', :qr_url, :description, NOW())";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':booking_id', $bookingId);
            $stmt->bindParam(':amount', $amount);
            $stmt->bindParam(':qr_url', $qrUrl);
            $stmt->bindParam(':description', $description);
            
            if ($stmt->execute()) {
                $paymentId = $this->conn->lastInsertId();
                
                return [
                    'success' => true,
                    'payment_id' => $paymentId,
                    'qr_url' => $qrUrl,
                    'bank_info' => $this->bankInfo,
                    'amount' => $amount,
                    'description' => $description
                ];
            }
            
            return ['success' => false, 'message' => 'Không thể tạo thanh toán'];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Lỗi tạo thanh toán: ' . $e->getMessage()];
        }
    }
    
    // Sinh QR code bằng VietQR API
    private function generateVietQR($amount, $description) {
        $bin = $this->bankInfo['bin'];
        $accountNumber = $this->bankInfo['account_number'];
        $accountName = urlencode($this->bankInfo['account_name']);
        
        // Loại bỏ ký tự đặc biệt trong mô tả trước khi mã hóa URL
        $cleanDescription = preg_replace('/[^\p{L}\p{N}\s]/u', '', $description);
        $addInfo = urlencode($cleanDescription);
        
        // Template: compact2 (có logo ngân hàng)
        $template = 'compact2';
        
        $qrUrl = "https://img.vietqr.io/image/{$bin}-{$accountNumber}-{$template}.png";
        $qrUrl .= "?amount={$amount}";
        $qrUrl .= "&addInfo={$addInfo}";
        $qrUrl .= "&accountName={$accountName}";
        
        return $qrUrl;
    }
    
    // Lấy thông tin thanh toán theo booking ID (Không sử dụng trong API hiện tại, giữ nguyên)
    public function getPaymentByBookingId($bookingId) {
        $error = $this->isConnectionError();
        if ($error) return $error;

        $query = "SELECT * FROM " . $this->table . " 
                  WHERE booking_id = :booking_id 
                  ORDER BY created_at DESC 
                  LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':booking_id', $bookingId);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Lấy thông tin thanh toán theo payment ID
    public function getPaymentById($paymentId) {
        $error = $this->isConnectionError();
        if ($error) return $error;

        $query = "SELECT p.*, b.customer_name, b.check_in, b.check_out 
                  FROM " . $this->table . " p
                  LEFT JOIN bookings b ON p.booking_id = b.booking_id
                  WHERE p.payment_id = :payment_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':payment_id', $paymentId);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Lấy tất cả thanh toán
    public function getAllPayments($status = null) {
        $error = $this->isConnectionError();
        if ($error) return $error; // Kiểm tra lỗi kết nối

        try {
             $query = "SELECT p.*, b.customer_name, b.room_number 
                      FROM " . $this->table . " p
                      LEFT JOIN bookings b ON p.booking_id = b.booking_id";
            
            if ($status) {
                $query .= " WHERE p.payment_status = :status";
            }
            
            $query .= " ORDER BY p.created_at DESC";
            
            $stmt = $this->conn->prepare($query);
            
            if ($status) {
                $stmt->bindParam(':status', $status);
            }
            
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            // Bắt lỗi SQL và trả về JSON lỗi
            return ['success' => false, 'message' => 'Lỗi truy vấn danh sách: ' . $e->getMessage()];
        }
    }
    
    // Xác nhận thanh toán (manual - admin xác nhận)
    public function confirmPayment($paymentId, $transactionId = null) {
        $error = $this->isConnectionError();
        if ($error) return $error;

        try {
            $query = "UPDATE " . $this->table . " 
                      SET payment_status = 'completed', 
                          transaction_id = :transaction_id,
                          paid_at = NOW(),
                          updated_at = NOW()
                      WHERE payment_id = :payment_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':payment_id', $paymentId);
            // $transactionId có thể là null, PDO sẽ xử lý đúng
            $stmt->bindParam(':transaction_id', $transactionId); 
            
            if ($stmt->execute()) {
                // Cập nhật trạng thái booking
                $payment = $this->getPaymentById($paymentId);
                if ($payment) {
                    $updateBooking = "UPDATE bookings 
                                     SET booking_status = 'confirmed', 
                                         updated_at = NOW() 
                                     WHERE booking_id = :booking_id";
                    $stmtBooking = $this->conn->prepare($updateBooking);
                    $stmtBooking->bindParam(':booking_id', $payment['booking_id']);
                    $stmtBooking->execute();
                }
                
                return ['success' => true, 'message' => 'Xác nhận thanh toán thành công'];
            }
            
            return ['success' => false, 'message' => 'Không thể xác nhận thanh toán'];
            
        } catch (Exception $e) {
             return ['success' => false, 'message' => 'Lỗi xác nhận thanh toán: ' . $e->getMessage()];
        }
    }
    
    // Hủy thanh toán (giữ nguyên logic gốc)
    public function cancelPayment($paymentId, $reason = '') {
        $error = $this->isConnectionError();
        if ($error) return $error;

        $query = "UPDATE " . $this->table . " 
                  SET payment_status = 'cancelled', 
                      cancel_reason = :reason,
                      updated_at = NOW()
                  WHERE payment_id = :payment_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':payment_id', $paymentId);
        $stmt->bindParam(':reason', $reason);
        
        // Trả về kết quả thực thi, không bọc trong success/message
        return $stmt->execute(); 
    }
    
    // Lấy thống kê thanh toán (giữ nguyên logic gốc)
    public function getPaymentStats() {
        $error = $this->isConnectionError();
        if ($error) return $error;

        $query = "SELECT 
                      COUNT(*) as total_payments,
                      SUM(CASE WHEN payment_status = 'completed' THEN amount ELSE 0 END) as total_revenue,
                      SUM(CASE WHEN payment_status = 'pending' THEN amount ELSE 0 END) as pending_amount,
                      COUNT(CASE WHEN payment_status = 'pending' THEN 1 END) as pending_count
                    FROM " . $this->table;
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Lấy thông tin ngân hàng
    public function getBankInfo() {
        return $this->bankInfo;
    }
}
?>