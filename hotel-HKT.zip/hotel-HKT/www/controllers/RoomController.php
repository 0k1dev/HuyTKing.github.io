<?php
// controllers/RoomController.php
require_once 'models/Room.php';

class RoomController {
    private $roomModel;
    
    public function __construct($db) {
        $this->roomModel = new Room($db);
    }
    
    public function index() {
        $rooms = $this->roomModel->getAll();
        include 'views/rooms/list.php';
    }
    
    public function show($room_id) {
        $room = $this->roomModel->getDetail($room_id);
        include 'views/rooms/detail.php';
    }
    
    public function apiGetRooms() {
        header('Content-Type: application/json');
        
        $floor = isset($_GET['floor']) ? $_GET['floor'] : null;
        
        if ($floor) {
            $stmt = $this->roomModel->getByFloor($floor);
        } else {
            $stmt = $this->roomModel->getAll();
        }
        
        $rooms = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $rooms[] = $row;
        }
        
        echo json_encode([
            'success' => true,
            'data' => $rooms,
            'count' => count($rooms)
        ]);
    }
}
?>