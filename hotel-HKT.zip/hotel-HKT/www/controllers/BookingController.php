<?php
// controllers/booking_controller.php
session_start();
require_once(__DIR__ . '/../config/database.php');

function createBooking() {
    global $pdo;
    
    // Validate CSRF token nếu cần
    
    // Lấy dữ liệu từ form
    $room_id = $_POST['room_id'] ?? '';
    $guest_name = $_POST['guest_name'] ?? '';
    $guest_phone = $_POST['guest_phone'] ?? '';
    $guest_email = $_POST['guest_email'] ?? '';
    $guest_id_card = $_POST['guest_id_card'] ?? '';
    $guest_address = $_POST['guest_address'] ?? '';
    $check_in_date = $_POST['check_in_date'] ?? '';
    $check_out_date = $_POST['check_out_date'] ?? '';
    $num_guests = $_POST['num_guests'] ?? 1;
    $num_nights = $_POST['num_nights'] ?? 1;
    $total_price = $_POST['total_price'] ?? 0;
    $special_requests = $_POST['special_requests'] ?? '';
    
    // Validate dữ liệu
    if (empty($guest_name) || empty($guest_phone) || empty($room_id)) {
        $_SESSION['error'] = "Vui lòng điền đầy đủ thông tin bắt buộc";
        header("Location: index.php?page=rooms");
        exit;
    }
    
    try {
        // Kiểm tra phòng còn trống không
        $stmt = $pdo->prepare("SELECT * FROM rooms WHERE room_id = ? AND status = 'available'");
        $stmt->execute([$room_id]);
        $room = $stmt->fetch();
        
        if (!$room) {
            $_SESSION['error'] = "Phòng không còn khả dụng";
            header("Location: index.php?page=rooms");
            exit;
        }
        
        // Tạo mã booking
        $booking_code = 'BK' . date('YmdHis') . rand(100, 999);
        
        // Tạo booking trong database
        $sql = "INSERT INTO bookings (
            booking_code, room_id, customer_name, customer_phone, 
            customer_email, customer_cccd, customer_address,
            check_in, check_out, num_guests, num_nights, 
            total_price, notes, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $booking_code,
            $room_id,
            $guest_name,
            $guest_phone,
            $guest_email,
            $guest_id_card,
            $guest_address,
            $check_in_date,
            $check_out_date,
            $num_guests,
            $num_nights,
            $total_price,
            $special_requests
        ]);
        
        // Cập nhật trạng thái phòng
        $updateStmt = $pdo->prepare("UPDATE rooms SET status = 'reserved' WHERE room_id = ?");
        $updateStmt->execute([$room_id]);
        
        // Thành công
        $_SESSION['success'] = "Đặt phòng thành công! Mã booking: " . $booking_code;
        $_SESSION['booking_code'] = $booking_code;
        
        // Chuyển đến trang xác nhận hoặc danh sách booking
        header("Location: index.php?page=bookings");
        exit;
        
    } catch (PDOException $e) {
        $_SESSION['error'] = "Lỗi database: " . $e->getMessage();
        header("Location: index.php?page=rooms");
        exit;
    }
}
?>